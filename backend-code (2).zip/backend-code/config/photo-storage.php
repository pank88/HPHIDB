<?php

declare(strict_types=1);

return [
    /*
    |--------------------------------------------------------------------------
    | Photo Storage Configuration
    |--------------------------------------------------------------------------
    */

    // Storage disk for local photo storage
    'disk' => env('PHOTO_STORAGE_DISK', 'local'),

    // Storage path within the disk
    'path' => 'profiles/photos',

    // Encryption settings
    'encryption' => [
        'enabled' => env('PHOTO_ENCRYPTION_ENABLED', true),
        'cipher' => 'AES-256-CBC',
    ],

    // Photo upload limits
    'upload' => [
        'max_size_mb' => 2,
        'min_width_px' => 200,
        'min_height_px' => 200,
        'allowed_formats' => ['jpg', 'jpeg', 'png'],
        'max_per_profile' => 6,
    ],

    // Rate limiting
    'rate_limit' => [
        'uploads_per_day' => 10,
        'downloads_per_hour' => 100,
    ],

    // Signed URL settings
    'signed_url' => [
        'expiry_minutes' => 15,
    ],

    // Thumbnail settings
    'thumbnails' => [
        'enabled' => true,
        'width' => 300,
        'height' => 300,
        'quality' => 80,
    ],
];
