<?php

return [
    'max_photos' => 6,
    'max_vendor_images' => 15,
    'interest_expiry_days' => 30,
    'rerequest_after_reject_days' => 90,
    'max_interests_per_day' => 10,
    'exclude_same_gotra' => env('MAT_EXCLUDE_SAME_GOTRA', false),
    'reverify_on_key_edit' => true,
    'reapprove_on_key_edit' => false,
    'suggestion_threshold' => 40,
    'suggestion_cache_hours' => 24,
];
