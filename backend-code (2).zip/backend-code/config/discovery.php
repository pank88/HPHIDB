<?php

declare(strict_types=1);

return [
    /*
    |--------------------------------------------------------------------------
    | Discovery and Suggestions Configuration
    |--------------------------------------------------------------------------
    */

    // Cache TTL for daily suggestions (in seconds)
    'suggestions_cache_ttl' => env('SUGGESTIONS_CACHE_TTL', 86400), // 24 hours

    // Cache TTL for filter options (in seconds)
    'filters_cache_ttl' => env('FILTERS_CACHE_TTL', 604800), // 7 days

    // Cache TTL for popular profiles (in seconds)
    'popular_cache_ttl' => env('POPULAR_CACHE_TTL', 3600), // 1 hour

    // Number of profiles per page in search results
    'search_page_size' => env('SEARCH_PAGE_SIZE', 20),

    // Number of suggestions to generate per user daily
    'suggestions_per_user' => env('SUGGESTIONS_PER_USER', 10),

    // Compatibility scoring weights (in percentage points out of 100)
    'scoring' => [
        'age' => 12,
        'location' => 12,
        'religion' => 10,
        'caste' => 10,
        'gotra' => 5,
        'height' => 8,
        'complexion' => 5,
        'food_type' => 5,
        'education' => 6,
        'occupation' => 5,
        'hobbies' => 8,
        'completeness' => 5,
        'photos' => 6,
        'recency' => 5,
        'profile_status' => 3,
        // Total should = 100 points
    ],
];
