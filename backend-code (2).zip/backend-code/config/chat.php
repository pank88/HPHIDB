<?php

declare(strict_types=1);

return [
    'message_max_length' => 5000,
    'typing_timeout' => 3000,              // ms before auto stop typing
    'media_max_size' => 10 * 1024 * 1024,  // 10MB
    'messages_per_page' => 50,
    'conversations_per_page' => 20,
    'edit_window_minutes' => 60,           // Can edit within 1 hour
    'delete_window_minutes' => 1440,       // Can delete within 24 hours
];
