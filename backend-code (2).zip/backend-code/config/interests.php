<?php

declare(strict_types=1);

return [
    /*
    |--------------------------------------------------------------------------
    | Interest Request Configuration
    |--------------------------------------------------------------------------
    |
    | Configuration for interest request feature in the matrimonial platform.
    |
    */

    // Interest expiry in days
    'interest_ttl_days' => env('INTEREST_TTL_DAYS', 30),

    // Maximum interests per day per user
    'interest_send_limit' => env('INTEREST_SEND_LIMIT', 20),

    // Pagination size for interest search
    'interest_search_page_size' => env('INTEREST_SEARCH_PAGE_SIZE', 20),

    // Notification channels
    'notification_channels' => ['app', 'sms', 'email'],

    // Block duration (null = permanent)
    'block_duration' => null,
];
