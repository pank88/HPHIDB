<?php

declare(strict_types=1);

use App\Http\Controllers\Api\V1\ConversationController;
use App\Http\Controllers\Api\V1\MessageController;
use Illuminate\Support\Facades\Route;

Route::middleware('auth:sanctum')->group(function () {
    // Conversation routes
    Route::prefix('conversations')->group(function () {
        Route::get('/', [ConversationController::class, 'getConversations'])->name('conversations.index');
        Route::get('/{conversation}', [ConversationController::class, 'showConversation'])->name('conversations.show');
        Route::get('/{conversation}/messages', [ConversationController::class, 'getConversationMessages'])->name('conversations.messages');
        Route::put('/{conversation}/read', [ConversationController::class, 'markConversationAsRead'])->name('conversations.read');
        Route::delete('/{conversation}', [ConversationController::class, 'deleteConversation'])->name('conversations.delete');
    });

    // Message routes
    Route::prefix('messages')->group(function () {
        Route::post('/upload', [MessageController::class, 'uploadMedia'])->middleware('throttle:30,60')->name('messages.upload');
        Route::post('/', [MessageController::class, 'sendMessage'])->middleware('throttle:60,1')->name('messages.send');
        Route::put('/{message}', [MessageController::class, 'updateMessage'])->name('messages.update');
        Route::delete('/{message}', [MessageController::class, 'deleteMessage'])->name('messages.delete');
        Route::post('/{message}/read', [MessageController::class, 'markMessageAsRead'])->name('messages.read');
    });

    // Typing indicator routes
    Route::prefix('conversations/{conversation}/typing')->group(function () {
        Route::post('/', [MessageController::class, 'startTyping'])->name('messages.typing');
        Route::post('/stop', [MessageController::class, 'stopTyping'])->name('messages.stopped-typing');
    });
});
