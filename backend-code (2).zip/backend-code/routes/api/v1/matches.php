<?php

declare(strict_types=1);

use App\Http\Controllers\Api\V1\MatchController;
use Illuminate\Support\Facades\Route;

Route::middleware('auth:sanctum')->group(function () {
    // Get user's matches
    Route::get('/matches', [MatchController::class, 'getMatches'])
        ->name('matches.index');

    // Get specific match
    Route::get('/matches/{match}', [MatchController::class, 'showMatch'])
        ->name('matches.show');

    // Get matched profile
    Route::get('/matches/{match}/profile', [MatchController::class, 'getMatchedProfile'])
        ->name('matches.profile');

    // Block match
    Route::put('/matches/{match}/block', [MatchController::class, 'blockMatch'])
        ->name('matches.block');

    // Unblock match
    Route::put('/matches/{match}/unblock', [MatchController::class, 'unblockMatch'])
        ->name('matches.unblock');

    // Send message / Start conversation
    Route::post('/matches/{match}/message', [MatchController::class, 'startConversation'])
        ->name('matches.message');
});
