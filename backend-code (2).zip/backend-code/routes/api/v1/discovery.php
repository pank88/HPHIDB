<?php

declare(strict_types=1);

use App\Http\Controllers\Api\V1\DiscoveryController;
use App\Http\Controllers\Api\V1\SuggestionController;
use Illuminate\Support\Facades\Route;

// Discovery and Search routes
Route::prefix('discover')->group(function () {
    Route::post('search', [DiscoveryController::class, 'search'])
        ->middleware('throttle:100,60')
        ->name('discover.search');

    Route::get('filters', [DiscoveryController::class, 'filters'])
        ->name('discover.filters');

    Route::get('popular', [DiscoveryController::class, 'popular'])
        ->middleware('auth:sanctum')
        ->name('discover.popular');
});

// Suggestions routes
Route::prefix('suggestions')->middleware('auth:sanctum')->group(function () {
    Route::get('/', [SuggestionController::class, 'index'])
        ->name('suggestions.index');

    Route::get('{profileId}/breakdown', [SuggestionController::class, 'breakdown'])
        ->name('suggestions.breakdown');

    // 3/day limit enforced in the controller with a proper JSON envelope
    Route::post('refresh', [SuggestionController::class, 'refresh'])
        ->name('suggestions.refresh');
});
