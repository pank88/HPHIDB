<?php

declare(strict_types=1);

use App\Http\Controllers\Api\V1\InterestController;
use Illuminate\Support\Facades\Route;

Route::middleware('auth:sanctum')->group(function () {
    // Send interest
    Route::post('/interests', [InterestController::class, 'sendInterest'])
        ->middleware('throttle:20,1440')
        ->name('interests.send');

    // Get received interests
    Route::get('/interests/received', [InterestController::class, 'getReceivedInterests'])
        ->name('interests.received');

    // Get sent interests
    Route::get('/interests/sent', [InterestController::class, 'getSentInterests'])
        ->name('interests.sent');

    // Get pending interests (summary)
    Route::get('/interests/pending', [InterestController::class, 'getPendingInterests'])
        ->name('interests.pending');

    // Accept interest
    Route::put('/interests/{interest}/accept', [InterestController::class, 'acceptInterest'])
        ->name('interests.accept');

    // Reject interest
    Route::put('/interests/{interest}/reject', [InterestController::class, 'rejectInterest'])
        ->name('interests.reject');

    // Block interest
    Route::put('/interests/{interest}/block', [InterestController::class, 'blockInterest'])
        ->name('interests.block');

    // Delete interest
    Route::delete('/interests/{interest}', [InterestController::class, 'deleteInterest'])
        ->name('interests.delete');
});
