<?php

use App\Http\Controllers\Api\V1\Auth\ForgotPasswordController;
use App\Http\Controllers\Api\V1\Auth\LoginController;
use App\Http\Controllers\Api\V1\Auth\LogoutController;
use App\Http\Controllers\Api\V1\Auth\RegisterController;
use App\Http\Controllers\Api\V1\Auth\ResendOTPController;
use App\Http\Controllers\Api\V1\Auth\ResetPasswordController;
use App\Http\Controllers\Api\V1\Auth\VerifyOTPController;
use Illuminate\Support\Facades\Route;

Route::prefix('auth')->group(function () {
    // Public routes (no authentication required)
    Route::post('register', [RegisterController::class, 'register'])->middleware('throttle:10,1');
    // 8/10min: allows the 3 wrong-OTP attempts the business rule permits,
    // plus the eventual correct attempt, without the IP-level limiter
    // tripping before OtpService's own lockout does.
    Route::post('verify-otp', [VerifyOTPController::class, 'verify'])->middleware('throttle:8,10');
    Route::post('resend-otp', [ResendOTPController::class, 'resend'])->middleware('throttle:3,10');
    Route::post('login', [LoginController::class, 'login'])->middleware('throttle:5,1');
    Route::post('forgot-password', [ForgotPasswordController::class, 'sendResetLink'])->middleware('throttle:5,1');
    Route::post('reset-password', [ResetPasswordController::class, 'reset'])->middleware('throttle:5,1');

    // Protected routes (authentication required)
    Route::middleware('auth:sanctum')->group(function () {
        Route::post('logout', [LogoutController::class, 'logout']);
    });
});
