<?php

declare(strict_types=1);

use App\Http\Controllers\Api\V1\AccountController;
use App\Http\Controllers\Api\V1\User\EducationController;
use App\Http\Controllers\Api\V1\User\HobbyController;
use App\Http\Controllers\Api\V1\User\PhotoController;
use App\Http\Controllers\Api\V1\User\PreferenceController;
use App\Http\Controllers\Api\V1\User\ProfileController;
use Illuminate\Support\Facades\Route;

Route::middleware('auth:sanctum')->group(function () {
    // Account settings — role-agnostic (users and vendors both have accounts)
    Route::put('/account/password', [AccountController::class, 'updatePassword'])->name('account.password')->middleware('throttle:5,1');
    Route::put('/account/email', [AccountController::class, 'updateEmail'])->name('account.email')->middleware('throttle:5,1');
    Route::put('/account/mobile', [AccountController::class, 'updateMobile'])->name('account.mobile')->middleware('throttle:5,1');

    // Profile endpoints
    Route::post('/profile', [ProfileController::class, 'store'])->name('profile.store');
    Route::get('/profile', [ProfileController::class, 'show'])->name('profile.show');
    Route::put('/profile', [ProfileController::class, 'update'])->name('profile.update');

    // Education endpoints
    Route::get('/profile/educations', [EducationController::class, 'index'])->name('educations.index');
    Route::post('/profile/educations', [EducationController::class, 'store'])->name('educations.store');
    Route::put('/profile/educations/{education}', [EducationController::class, 'update'])->name('educations.update');
    Route::delete('/profile/educations/{education}', [EducationController::class, 'destroy'])->name('educations.destroy');
    Route::put('/profile/educations/{education}/highest', [EducationController::class, 'setHighest'])->name('educations.set-highest');

    // Photo endpoints
    Route::post('/profile/photos', [PhotoController::class, 'store'])->middleware('throttle:10,1440')->name('photos.store');
    Route::put('/profile/photos/{photo}/primary', [PhotoController::class, 'setPrimary'])->name('photos.set-primary');
    Route::delete('/profile/photos/{photo}', [PhotoController::class, 'destroy'])->name('photos.destroy');

    // Preference endpoints
    Route::get('/profile/preferences', [PreferenceController::class, 'show'])->name('preferences.show');
    Route::put('/profile/preferences', [PreferenceController::class, 'update'])->name('preferences.update');

    // Hobby endpoints
    Route::put('/profile/hobbies', [HobbyController::class, 'update'])->name('hobbies.update');
});
