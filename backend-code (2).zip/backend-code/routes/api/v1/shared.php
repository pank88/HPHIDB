<?php

declare(strict_types=1);

use App\Http\Controllers\Api\V1\MasterController;
use App\Http\Controllers\Api\V1\PhotoViewController;
use Illuminate\Support\Facades\Route;

// Public routes - no authentication required
Route::group(['prefix' => 'masters'], function () {
    Route::get('/coded-lists', [MasterController::class, 'getCodedLists'])->name('masters.coded-lists');
    Route::get('/coded-lists/all', [MasterController::class, 'getCodedLists'])->name('masters.coded-lists.all');
    Route::get('/{type}', [MasterController::class, 'getMaster'])->name('masters.get');
    Route::get('/', [MasterController::class, 'getAllMasters'])->name('masters.all');
});

// Photo view endpoints (public with signed URLs)
Route::get('/photos/view/{photoId}/{token}', [PhotoViewController::class, 'view'])->name('photos.view');
Route::get('/photos/thumb/{photoId}/{token}', [PhotoViewController::class, 'thumb'])->name('photos.thumb');
