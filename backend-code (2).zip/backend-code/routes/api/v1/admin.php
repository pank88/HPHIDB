<?php

declare(strict_types=1);

use App\Http\Controllers\Api\V1\Admin\AuditLogController;
use App\Http\Controllers\Api\V1\Admin\DashboardController;
use App\Http\Controllers\Api\V1\Admin\MasterDataController;
use App\Http\Controllers\Api\V1\Admin\ProfileModerationController;
use App\Http\Controllers\Api\V1\Admin\ReportController;
use App\Http\Controllers\Api\V1\Admin\UserModerationController;
use App\Http\Controllers\Api\V1\Admin\VendorModerationController;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth:sanctum', 'admin'])->prefix('admin')->group(function () {
    // Dashboard
    Route::get('/dashboard/stats', [DashboardController::class, 'stats'])->name('admin.dashboard.stats');
    Route::get('/dashboard/activity', [DashboardController::class, 'activity'])->name('admin.dashboard.activity');

    // User moderation
    Route::get('/users', [UserModerationController::class, 'index'])->name('admin.users.index');
    Route::get('/users/{id}', [UserModerationController::class, 'show'])->whereNumber('id')->name('admin.users.show');
    Route::put('/users/{id}/activate', [UserModerationController::class, 'activate'])->whereNumber('id')->name('admin.users.activate');
    Route::put('/users/{id}/suspend', [UserModerationController::class, 'suspend'])->whereNumber('id')->name('admin.users.suspend');
    Route::delete('/users/{id}', [UserModerationController::class, 'destroy'])->whereNumber('id')->name('admin.users.destroy');

    // Profile moderation
    Route::get('/profiles/pending', [ProfileModerationController::class, 'pending'])->name('admin.profiles.pending');
    Route::put('/profiles/{id}/approve', [ProfileModerationController::class, 'approve'])->whereNumber('id')->name('admin.profiles.approve');
    Route::put('/profiles/{id}/reject', [ProfileModerationController::class, 'reject'])->whereNumber('id')->name('admin.profiles.reject');
    Route::get('/photos/pending', [ProfileModerationController::class, 'pendingPhotos'])->name('admin.photos.pending');
    Route::put('/photos/{id}/approve', [ProfileModerationController::class, 'approvePhoto'])->whereNumber('id')->name('admin.photos.approve');
    Route::put('/photos/{id}/reject', [ProfileModerationController::class, 'rejectPhoto'])->whereNumber('id')->name('admin.photos.reject');

    // Vendor moderation
    Route::get('/vendors', [VendorModerationController::class, 'index'])->name('admin.vendors.index');
    Route::put('/vendors/{id}/verify', [VendorModerationController::class, 'verify'])->whereNumber('id')->name('admin.vendors.verify');
    Route::put('/vendors/{id}/suspend', [VendorModerationController::class, 'suspend'])->whereNumber('id')->name('admin.vendors.suspend');
    Route::get('/testimonials/pending', [VendorModerationController::class, 'pendingTestimonials'])->name('admin.testimonials.pending');
    Route::put('/testimonials/{id}/approve', [VendorModerationController::class, 'approveTestimonial'])->whereNumber('id')->name('admin.testimonials.approve');
    Route::put('/testimonials/{id}/reject', [VendorModerationController::class, 'rejectTestimonial'])->whereNumber('id')->name('admin.testimonials.reject');

    // Master data management
    Route::get('/masters/{type}', [MasterDataController::class, 'index'])->name('admin.masters.index');
    Route::post('/masters/{type}', [MasterDataController::class, 'store'])->name('admin.masters.store');
    Route::put('/masters/{type}/{id}', [MasterDataController::class, 'update'])->whereNumber('id')->name('admin.masters.update');
    Route::delete('/masters/{type}/{id}', [MasterDataController::class, 'destroy'])->whereNumber('id')->name('admin.masters.destroy');

    // Audit logs
    Route::get('/audit-logs', [AuditLogController::class, 'index'])->name('admin.audit-logs.index');
    Route::get('/audit-logs/{id}', [AuditLogController::class, 'show'])->whereNumber('id')->name('admin.audit-logs.show');

    // Reports
    Route::get('/reports/users', [ReportController::class, 'users'])->name('admin.reports.users');
    Route::get('/reports/bookings', [ReportController::class, 'bookings'])->name('admin.reports.bookings');
    Route::get('/reports/engagement', [ReportController::class, 'engagement'])->name('admin.reports.engagement');
});
