<?php

use App\Http\Controllers\Api\V1\BookingController;
use App\Http\Controllers\Api\V1\ReviewController;
use App\Http\Controllers\Api\V1\Vendor\VendorImageSelfController;
use App\Http\Controllers\Api\V1\Vendor\VendorProfileSelfController;
use App\Http\Controllers\Api\V1\Vendor\VendorServiceSelfController;
use App\Http\Controllers\Api\V1\Vendor\VendorTestimonialSelfController;
use App\Http\Controllers\Api\V1\VendorController;
use Illuminate\Support\Facades\Route;

Route::prefix('bookings')->group(function () {
    Route::post('/', [BookingController::class, 'store'])->middleware('throttle:50,1440')->name('bookings.store');
    Route::get('/', [BookingController::class, 'index'])->name('bookings.index');
    Route::get('/{booking}', [BookingController::class, 'show'])->name('bookings.show');
    Route::put('/{booking}/accept-quote', [BookingController::class, 'confirmBooking'])->name('bookings.confirm');
    Route::put('/{booking}/respond-inquiry', [BookingController::class, 'respondToInquiry'])->name('bookings.respond');
    Route::put('/{booking}/complete', [BookingController::class, 'completeBooking'])->name('bookings.complete');
    Route::put('/{booking}/cancel', [BookingController::class, 'cancelBooking'])->name('bookings.cancel');
});

Route::prefix('reviews')->group(function () {
    Route::post('/', [ReviewController::class, 'store'])->middleware('throttle:50,1440')->name('reviews.store');
    Route::put('/{review}/respond', [ReviewController::class, 'respondToReview'])->name('reviews.respond');
    Route::put('/{review}/helpful', [ReviewController::class, 'markHelpful'])->name('reviews.helpful');
});

Route::get('/vendors/{vendor}/reviews', [ReviewController::class, 'getVendorReviews'])->name('vendors.reviews');

Route::prefix('vendors')->group(function () {
    Route::get('/', [VendorController::class, 'index'])->name('vendors.index');
    Route::get('/{vendor}', [VendorController::class, 'show'])->name('vendors.show');
    Route::get('/{vendor}/services', [VendorController::class, 'getServices'])->name('vendors.services');
    Route::get('/{vendor}/availability/{date}', [VendorController::class, 'getAvailableSlots'])->name('vendors.availability');
});

// Vendor's self-service area — managing their own business listing,
// services/packages, and (via /bookings + /reviews above, now
// vendor-scope-aware) the bookings and reviews their business receives.
Route::prefix('vendor')->group(function () {
    Route::get('/profile', [VendorProfileSelfController::class, 'show'])->name('vendor.profile.show');
    Route::put('/profile', [VendorProfileSelfController::class, 'update'])->name('vendor.profile.update');
    Route::post('/profile/logo', [VendorProfileSelfController::class, 'updateLogo'])
        ->middleware('throttle:10,60')
        ->name('vendor.profile.logo');

    Route::get('/services', [VendorServiceSelfController::class, 'index'])->name('vendor.services.index');
    Route::post('/services', [VendorServiceSelfController::class, 'store'])->name('vendor.services.store');
    Route::put('/services/{vendorService}', [VendorServiceSelfController::class, 'update'])->name('vendor.services.update');
    Route::delete('/services/{vendorService}', [VendorServiceSelfController::class, 'destroy'])->name('vendor.services.destroy');

    Route::get('/images', [VendorImageSelfController::class, 'index'])->name('vendor.images.index');
    Route::post('/images', [VendorImageSelfController::class, 'store'])->middleware('throttle:20,60')->name('vendor.images.store');
    Route::delete('/images/{vendorImage}', [VendorImageSelfController::class, 'destroy'])->name('vendor.images.destroy');

    Route::get('/testimonials', [VendorTestimonialSelfController::class, 'index'])->name('vendor.testimonials.index');
    Route::post('/testimonials', [VendorTestimonialSelfController::class, 'store'])->middleware('throttle:20,60')->name('vendor.testimonials.store');
    Route::post('/testimonials/{vendorTestimonial}', [VendorTestimonialSelfController::class, 'update'])->middleware('throttle:20,60')->name('vendor.testimonials.update');
    Route::delete('/testimonials/{vendorTestimonial}', [VendorTestimonialSelfController::class, 'destroy'])->name('vendor.testimonials.destroy');
});
