<?php

use Illuminate\Support\Facades\Route;

// API v1 routes
Route::prefix('v1')->group(function () {
    require __DIR__.'/api/v1/auth.php';
    require __DIR__.'/api/v1/shared.php';
    require __DIR__.'/api/v1/discovery.php';
    require __DIR__.'/api/v1/user.php';
    require __DIR__.'/api/v1/interests.php';
    require __DIR__.'/api/v1/matches.php';
    require __DIR__.'/api/v1/messages.php';
    require __DIR__.'/api/v1/services.php';
    require __DIR__.'/api/v1/admin.php';
});
