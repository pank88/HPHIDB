<?php

declare(strict_types=1);

namespace App\Exceptions;

use Exception;
use Illuminate\Http\JsonResponse;

class ReviewException extends Exception
{
    public function render(): JsonResponse
    {
        return response()->json([
            'success' => false,
            'message' => $this->getMessage(),
        ], $this->getCode() ?: 422);
    }

    public static function userNotBooker(): self
    {
        return new self('User did not book this service', 403);
    }

    public static function bookingNotCompleted(): self
    {
        return new self('Booking is not completed', 422);
    }

    public static function alreadyReviewed(): self
    {
        return new self('This booking has already been reviewed', 422);
    }

    public static function vendorMismatch(): self
    {
        return new self('Vendor does not own this review', 403);
    }
}
