<?php

declare(strict_types=1);

namespace App\Exceptions;

use Exception;

class BookingException extends Exception
{
    public static function vendorMismatch(): self
    {
        return new self('Vendor does not own this booking', 403);
    }

    public static function invalidStatus(string $currentStatus): self
    {
        return new self("Booking cannot be processed in {$currentStatus} status", 422);
    }

    public static function pastServiceDate(): self
    {
        return new self('Service date has not passed yet', 422);
    }

    public static function userMismatch(): self
    {
        return new self('User does not own this booking', 403);
    }

    public static function notInvolved(): self
    {
        return new self('User is not involved with this booking', 403);
    }
}
