<?php

declare(strict_types=1);

namespace App\Providers;

use App\Models\InterestRequest;
use App\Models\UserMatch;
use App\Policies\InterestPolicy;
use App\Policies\MatchPolicy;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Register policies
        Gate::policy(InterestRequest::class, InterestPolicy::class);
        Gate::policy(UserMatch::class, MatchPolicy::class);

        RateLimiter::for('photo-upload', function (Request $request) {
            return Limit::perDay(10)->by($request->user()?->id ?: $request->ip());
        });

        RateLimiter::for('photo-download', function (Request $request) {
            return Limit::perHour(100)->by($request->user()?->id ?: $request->ip());
        });
    }
}
