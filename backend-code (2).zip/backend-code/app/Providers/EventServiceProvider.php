<?php

declare(strict_types=1);

namespace App\Providers;

use App\Events\MessageDeleted;
use App\Events\MessageSent;
use App\Listeners\LogMessageDeleted;
use App\Listeners\LogMessageSent;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event listener mappings for the application.
     *
     * @var array<class-string, array<int, class-string>>
     */
    protected $listen = [
        MessageSent::class => [
            LogMessageSent::class,
        ],
        MessageDeleted::class => [
            LogMessageDeleted::class,
        ],
    ];

    /**
     * Determine if events and listeners should be automatically discovered.
     */
    public function shouldDiscoverEvents(): bool
    {
        return false;
    }
}
