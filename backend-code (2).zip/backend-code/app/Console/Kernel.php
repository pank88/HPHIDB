<?php

declare(strict_types=1);

namespace App\Console;

use App\Jobs\ExpireInterestsJob;
use App\Jobs\GenerateDailySuggestionsJob;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * Define the application's command schedule.
     */
    protected function schedule(Schedule $schedule): void
    {
        // Generate daily suggestions for all users at 2 AM
        $schedule->job(new GenerateDailySuggestionsJob)
            ->dailyAt('02:00')
            ->name('generate-daily-suggestions')
            ->onOneServer()
            ->withoutOverlapping(3600);

        // Expire interests daily at 3 AM
        $schedule->job(new ExpireInterestsJob)
            ->dailyAt('03:00')
            ->name('expire-interests')
            ->onOneServer()
            ->withoutOverlapping(1800);
    }

    /**
     * Register the commands for the application.
     */
    protected function commands(): void
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
