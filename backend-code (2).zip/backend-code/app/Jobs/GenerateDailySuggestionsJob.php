<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Constants\UserRole;
use App\Constants\UserStatus;
use App\Models\User;
use App\Services\SuggestionService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class GenerateDailySuggestionsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 3600; // 1 hour timeout

    public int $tries = 3;

    public function __construct()
    {
        $this->queue = 'default';
    }

    /**
     * Execute the job
     */
    public function handle(SuggestionService $suggestionService): void
    {
        try {
            // Get all active users with user role
            $users = User::where('status', UserStatus::ACTIVE)
                ->where('role', UserRole::USER)
                ->whereNotNull('phone_verified_at')
                ->chunk(100, function ($usersChunk) use ($suggestionService) {
                    foreach ($usersChunk as $user) {
                        try {
                            $suggestionService->generateDailySuggestions($user);

                            Log::info("Daily suggestions generated for user: {$user->id}");
                        } catch (\Exception $e) {
                            Log::error(
                                "Failed to generate suggestions for user {$user->id}: ".$e->getMessage()
                            );
                        }
                    }
                });

            Log::info('Daily suggestions generation completed successfully');
        } catch (\Exception $e) {
            Log::error('Daily suggestions generation job failed: '.$e->getMessage());

            // Re-throw for queue retry
            throw $e;
        }
    }

    /**
     * Handle job failure
     */
    public function failed(\Throwable $exception): void
    {
        Log::error(
            'Daily suggestions generation job permanently failed: '.$exception->getMessage(),
            ['exception' => $exception]
        );
    }
}
