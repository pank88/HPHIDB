<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Models\InterestRequest;
use App\Services\InterestService;
use App\Services\NotificationService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class ExpireInterestsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 1800; // 30 minutes timeout

    public int $tries = 3;

    public function __construct()
    {
        $this->queue = 'default';
    }

    /**
     * Execute the job
     */
    public function handle(InterestService $interestService, NotificationService $notificationService): void
    {
        try {
            // Get all expired pending interests
            $expiredInterests = InterestRequest::where('status', InterestRequest::STATUS_PENDING)
                ->where('expires_at', '<', now())
                ->get();

            $count = 0;
            foreach ($expiredInterests as $interest) {
                try {
                    // Update status to expired
                    $interest->update(['status' => InterestRequest::STATUS_EXPIRED]);

                    // Send notification to sender
                    $notificationService->notifyInterestExpired($interest->sender, $interest);

                    $count++;

                    Log::info("Interest {$interest->id} expired");
                } catch (\Exception $e) {
                    Log::error(
                        "Failed to expire interest {$interest->id}: ".$e->getMessage()
                    );
                }
            }

            Log::info("Interests expiration job completed. {$count} interests expired.");
        } catch (\Exception $e) {
            Log::error('Interests expiration job failed: '.$e->getMessage());

            // Re-throw for queue retry
            throw $e;
        }
    }

    /**
     * Handle job failure
     */
    public function failed(\Throwable $exception): void
    {
        Log::error(
            'Interests expiration job permanently failed: '.$exception->getMessage(),
            ['exception' => $exception]
        );
    }
}
