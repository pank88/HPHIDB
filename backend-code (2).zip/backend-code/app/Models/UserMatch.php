<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class UserMatch extends Model
{
    use HasFactory;

    protected $table = 'matches';

    protected $fillable = [
        'initiator_id',
        'matcher_id',
        'initiator_profile_id',
        'matcher_profile_id',
        'interest_id',
        'compatibility_score',
        'status',
        'matched_at',
        'accepted_at',
        'rejected_at',
        'connected_at',
        'last_interaction_at',
        'is_active',
        'blocked_by_id',
    ];

    protected $casts = [
        'compatibility_score' => 'float',
        'matched_at' => 'datetime',
        'accepted_at' => 'datetime',
        'rejected_at' => 'datetime',
        'connected_at' => 'datetime',
        'last_interaction_at' => 'datetime',
        'is_active' => 'boolean',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function initiator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'initiator_id');
    }

    public function matcher(): BelongsTo
    {
        return $this->belongsTo(User::class, 'matcher_id');
    }

    public function initiatorProfile(): BelongsTo
    {
        return $this->belongsTo(Profile::class, 'initiator_profile_id');
    }

    public function matcherProfile(): BelongsTo
    {
        return $this->belongsTo(Profile::class, 'matcher_profile_id');
    }

    public function interest(): BelongsTo
    {
        return $this->belongsTo(InterestRequest::class, 'interest_id');
    }

    public function messages(): HasMany
    {
        return $this->hasMany(Message::class, 'match_id');
    }

    public function conversations(): HasMany
    {
        return $this->hasMany(Conversation::class, 'match_id');
    }

    public function blockedByUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'blocked_by_id');
    }

    /**
     * Scope: Get active matches only
     */
    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }

    /**
     * Scope: Get matches ordered by most recent
     */
    public function scopeRecent(Builder $query): Builder
    {
        return $query->orderByDesc('connected_at');
    }

    /**
     * Scope: Get matches with messages
     */
    public function scopeWithMessages(Builder $query): Builder
    {
        return $query->has('messages');
    }
}
