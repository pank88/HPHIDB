<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PartnerPreference extends Model
{
    use HasFactory;

    protected $table = 'partner_preferences';

    protected $fillable = [
        'profile_id',
        'age_from',
        'age_to',
        'height_from',
        'height_to',
        'religion_id',
        'caste_id',
        'education_id',
        'occupation_id',
        'annual_income_from',
        'annual_income_to',
        'state_id',
        'city_id',
        'marital_status',
        'body_type',
        'skin_tone',
        'mother_tongue',
        'manglik',
        'smoke',
        'drink',
        'dietary_preference',
        'personality_type',
        'interests',
    ];

    protected $casts = [
        'age_from' => 'integer',
        'age_to' => 'integer',
        'annual_income_from' => 'integer',
        'annual_income_to' => 'integer',
        'manglik' => 'boolean',
        'smoke' => 'boolean',
        'drink' => 'boolean',
        'interests' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function profile(): BelongsTo
    {
        return $this->belongsTo(Profile::class);
    }

    public function religion(): BelongsTo
    {
        return $this->belongsTo(Religion::class);
    }

    public function caste(): BelongsTo
    {
        return $this->belongsTo(Caste::class);
    }

    public function education(): BelongsTo
    {
        return $this->belongsTo(Education::class);
    }

    public function occupation(): BelongsTo
    {
        return $this->belongsTo(Occupation::class);
    }

    public function state(): BelongsTo
    {
        return $this->belongsTo(State::class);
    }

    public function city(): BelongsTo
    {
        return $this->belongsTo(City::class);
    }
}
