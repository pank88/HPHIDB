<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Caste extends Model
{
    use HasFactory;

    protected $table = 'castes';

    protected $fillable = [
        'religion_id',
        'name',
        'description',
    ];

    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function religion(): BelongsTo
    {
        return $this->belongsTo(Religion::class);
    }

    public function profiles(): HasMany
    {
        return $this->hasMany(Profile::class);
    }

    public function partnerPreferences(): HasMany
    {
        return $this->hasMany(PartnerPreference::class);
    }
}
