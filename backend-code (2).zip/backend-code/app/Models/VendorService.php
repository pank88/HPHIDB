<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class VendorService extends Model
{
    use HasFactory;

    protected $table = 'vendor_services';

    protected $fillable = [
        'vendor_id',
        'service_category_id',
        'name',
        'description',
        'base_price',
        'price_label',
        'price_unit',
        'duration_hours',
        'max_guests_count',
        'includes_travel',
        'includes_decoration',
        'includes_makeup',
        'includes_videography',
        'includes_album',
        'is_active',
    ];

    protected $casts = [
        'base_price' => 'decimal:2',
        'duration_hours' => 'integer',
        'max_guests_count' => 'integer',
        'includes_travel' => 'boolean',
        'includes_decoration' => 'boolean',
        'includes_makeup' => 'boolean',
        'includes_videography' => 'boolean',
        'includes_album' => 'boolean',
        'is_active' => 'boolean',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    // Relationships
    public function vendor(): BelongsTo
    {
        return $this->belongsTo(Vendor::class);
    }

    public function serviceCategory(): BelongsTo
    {
        return $this->belongsTo(ServiceCategory::class);
    }

    public function bookings(): HasMany
    {
        return $this->hasMany(Booking::class);
    }

    // Scopes
    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }

    public function scopeByCategory(Builder $query, int $categoryId): Builder
    {
        return $query->where('service_category_id', $categoryId);
    }
}
