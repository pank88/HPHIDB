<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Conversation extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'conversations';

    protected $fillable = [
        'initiator_id',
        'participant_id',
        'match_id',
        'subject',
        'last_message_at',
        'initiator_read_at',
        'participant_read_at',
        'initiator_is_typing',
        'participant_is_typing',
        'is_active',
    ];

    protected $casts = [
        'last_message_at' => 'datetime',
        'initiator_read_at' => 'datetime',
        'participant_read_at' => 'datetime',
        'initiator_is_typing' => 'boolean',
        'participant_is_typing' => 'boolean',
        'is_active' => 'boolean',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];

    public function initiator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'initiator_id');
    }

    public function participant(): BelongsTo
    {
        return $this->belongsTo(User::class, 'participant_id');
    }

    public function messages(): HasMany
    {
        return $this->hasMany(Message::class);
    }

    public function match(): BelongsTo
    {
        return $this->belongsTo(UserMatch::class, 'match_id');
    }

    /**
     * Scope: Get only active conversations (not deleted)
     */
    public function scopeActive(Builder $query): Builder
    {
        return $query->whereNull('deleted_at');
    }

    /**
     * Scope: Get conversations with unread messages for a specific user
     */
    public function scopeWithUnreadMessages(Builder $query, User $user): Builder
    {
        return $query->whereHas('messages', function (Builder $messageQuery) use ($user) {
            $messageQuery->where('sender_id', '!=', $user->id)
                ->whereNull('read_at');
        });
    }

    /**
     * Scope: Order by most recent message
     */
    public function scopeOrderByLatest(Builder $query): Builder
    {
        return $query->orderByDesc('last_message_at');
    }

    /**
     * Get the other participant in the conversation
     */
    public function getOtherUser(User $user): ?User
    {
        if ($this->initiator_id === $user->id) {
            return $this->participant;
        }
        if ($this->participant_id === $user->id) {
            return $this->initiator;
        }

        return null;
    }

    /**
     * Mark conversation as read for a specific user
     */
    public function markAsRead(User $user): void
    {
        if ($this->initiator_id === $user->id) {
            $this->update(['initiator_read_at' => now()]);
        } elseif ($this->participant_id === $user->id) {
            $this->update(['participant_read_at' => now()]);
        }

        // Mark all messages as read
        $this->messages()
            ->where('sender_id', '!=', $user->id)
            ->whereNull('read_at')
            ->update(['read_at' => now()]);
    }

    /**
     * Get unread message count for a specific user
     */
    public function getUnreadCount(User $user): int
    {
        return $this->messages()
            ->where('sender_id', '!=', $user->id)
            ->whereNull('read_at')
            ->count();
    }
}
