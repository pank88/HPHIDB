<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes;

    protected $fillable = [
        'name',
        'email',
        'password',
        'phone',
        'role',
        'email_verified_at',
        'phone_verified_at',
        'status',
        'last_seen_at',
        'suspended_at',
        'suspension_reason',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'phone_verified_at' => 'datetime',
        'last_seen_at' => 'datetime',
        'suspended_at' => 'datetime',
        'password' => 'hashed',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function profiles(): HasMany
    {
        return $this->hasMany(Profile::class);
    }

    public function sentInterestRequests(): HasMany
    {
        return $this->hasMany(InterestRequest::class, 'sender_id');
    }

    public function receivedInterestRequests(): HasMany
    {
        return $this->hasMany(InterestRequest::class, 'receiver_id');
    }

    public function sentMatches(): HasMany
    {
        return $this->hasMany(UserMatch::class, 'initiator_id');
    }

    public function receivedMatches(): HasMany
    {
        return $this->hasMany(UserMatch::class, 'matcher_id');
    }

    public function conversationsAsInitiator(): HasMany
    {
        return $this->hasMany(Conversation::class, 'initiator_id');
    }

    public function conversationsAsParticipant(): HasMany
    {
        return $this->hasMany(Conversation::class, 'participant_id');
    }

    public function bookings(): HasMany
    {
        return $this->hasMany(Booking::class);
    }

    public function reviews(): HasMany
    {
        return $this->hasMany(Review::class);
    }

    public function notificationLogs(): HasMany
    {
        return $this->hasMany(NotificationLog::class);
    }

    public function auditLogs(): HasMany
    {
        return $this->hasMany(AuditLog::class);
    }

    public function suggestedMatches(): HasMany
    {
        return $this->hasMany(SuggestedMatch::class);
    }

    public function vendor(): HasOne
    {
        return $this->hasOne(Vendor::class);
    }

    /**
     * Check if user is currently online
     */
    public function isOnline(): bool
    {
        if (! $this->last_seen_at) {
            return false;
        }

        // Consider user online if seen within last 5 minutes
        return $this->last_seen_at->addMinutes(5)->isFuture();
    }
}
