<?php

declare(strict_types=1);

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class Booking extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'bookings';

    protected $fillable = [
        'user_id',
        'vendor_id',
        'vendor_service_id',
        'vendor_package_id',
        'service_date',
        'service_time_from',
        'service_time_to',
        'location_address',
        'location_city_id',
        'guests_count',
        'special_requirements',
        'estimated_amount',
        'final_amount',
        'status',
        'payment_status',
        'inquiry_responded_at',
        'inquiry_response_time_minutes',
        'confirmed_at',
        'completed_at',
        'cancelled_at',
        'cancellation_reason',
        'review_id',
        'booking_date',
        'event_date',
        'event_time',
        'number_of_guests',
        'total_price',
        'advance_payment',
        'balance_payment',
        'booking_status',
        'special_requests',
    ];

    protected $casts = [
        'service_date' => 'date',
        'service_time_from' => 'datetime',
        'service_time_to' => 'datetime',
        'guests_count' => 'integer',
        'estimated_amount' => 'decimal:2',
        'final_amount' => 'decimal:2',
        'inquiry_responded_at' => 'datetime',
        'inquiry_response_time_minutes' => 'integer',
        'confirmed_at' => 'datetime',
        'completed_at' => 'datetime',
        'cancelled_at' => 'datetime',
        'booking_date' => 'date',
        'event_date' => 'date',
        'event_time' => 'datetime',
        'number_of_guests' => 'integer',
        'total_price' => 'decimal:2',
        'advance_payment' => 'decimal:2',
        'balance_payment' => 'decimal:2',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];

    // Relationships
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function vendor(): BelongsTo
    {
        return $this->belongsTo(Vendor::class);
    }

    public function vendorService(): BelongsTo
    {
        return $this->belongsTo(VendorService::class);
    }

    public function vendorPackage(): BelongsTo
    {
        return $this->belongsTo(VendorPackage::class);
    }

    public function city(): BelongsTo
    {
        return $this->belongsTo(City::class, 'location_city_id');
    }

    public function review(): HasOne
    {
        return $this->hasOne(Review::class);
    }

    public function bookingMessages(): HasMany
    {
        return $this->hasMany(BookingMessage::class);
    }

    public function bookingPhotos(): HasMany
    {
        return $this->hasMany(BookingPhoto::class);
    }

    // Scopes
    public function scopePending(Builder $query): Builder
    {
        return $query->where('status', 'INQUIRY');
    }

    public function scopeConfirmed(Builder $query): Builder
    {
        return $query->where('status', 'CONFIRMED');
    }

    public function scopeCompleted(Builder $query): Builder
    {
        return $query->where('status', 'COMPLETED');
    }

    public function scopeForUser(Builder $query, User $user): Builder
    {
        return $query->where('user_id', $user->id);
    }

    public function scopeForVendor(Builder $query, User $vendor): Builder
    {
        return $query->where('vendor_id', $vendor->vendor?->id);
    }

    public function scopeByStatus(Builder $query, string $status): Builder
    {
        return $query->where('status', $status);
    }

    public function scopeUpcoming(Builder $query): Builder
    {
        return $query->where('service_date', '>=', now()->toDateString());
    }

    public function scopePast(Builder $query): Builder
    {
        return $query->where('service_date', '<', now()->toDateString());
    }

    // Methods
    public function canAcceptQuote(): bool
    {
        return $this->status === 'QUOTED';
    }

    public function respondToQuotation(float $finalAmount, ?string $notes = null): static
    {
        $this->update([
            'final_amount' => $finalAmount,
            'status' => 'QUOTED',
            'inquiry_responded_at' => now(),
            'inquiry_response_time_minutes' => (int) ($this->created_at->diffInMinutes(now())),
        ]);

        return $this;
    }

    public function confirmBooking(): static
    {
        $this->update([
            'status' => 'CONFIRMED',
            'confirmed_at' => now(),
        ]);

        return $this;
    }

    public function completeBooking(): static
    {
        $this->update([
            'status' => 'COMPLETED',
            'completed_at' => now(),
        ]);

        return $this;
    }

    public function cancelBooking(?string $reason = null): static
    {
        $this->update([
            'status' => 'CANCELLED',
            'cancelled_at' => now(),
            'cancellation_reason' => $reason,
        ]);

        return $this;
    }

    public function getPaymentDueDate(): Carbon
    {
        return $this->confirmed_at ? $this->confirmed_at->addDays(7) : now()->addDays(7);
    }
}
