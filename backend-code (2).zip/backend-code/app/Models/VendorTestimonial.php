<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class VendorTestimonial extends Model
{
    use HasFactory;

    protected $table = 'vendor_testimonials';

    protected $fillable = [
        'vendor_id',
        'reviewer_id',
        'reviewer_name',
        'reviewer_title',
        'client_location',
        'client_name',
        'client_email',
        'body',
        'testimonial',
        'rating',
        'image_url',
        'is_featured',
        'is_approved',
        'approved_at',
    ];

    protected $casts = [
        'rating' => 'integer',
        'is_featured' => 'boolean',
        'is_approved' => 'boolean',
        'approved_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    // Relationships
    public function vendor(): BelongsTo
    {
        return $this->belongsTo(Vendor::class);
    }

    public function reviewer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'reviewer_id');
    }
}
