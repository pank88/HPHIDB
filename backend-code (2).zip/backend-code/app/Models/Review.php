<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Review extends Model
{
    use HasFactory;

    protected $table = 'reviews';

    protected $fillable = [
        'booking_id',
        'reviewer_id',
        'vendor_id',
        'rating',
        'title',
        'body',
        'punctuality_rating',
        'communication_rating',
        'quality_rating',
        'value_rating',
        'photos_count',
        'helpful_count',
        'verified_purchase',
        'is_published',
        'response',
        'response_at',
        'user_id',
        'review_text',
        'service_quality',
        'punctuality',
        'professionalism',
        'value_for_money',
        'would_recommend',
        'is_approved',
        'approval_date',
    ];

    protected $casts = [
        'rating' => 'integer',
        'punctuality_rating' => 'integer',
        'communication_rating' => 'integer',
        'quality_rating' => 'integer',
        'value_rating' => 'integer',
        'photos_count' => 'integer',
        'helpful_count' => 'integer',
        'service_quality' => 'integer',
        'punctuality' => 'integer',
        'professionalism' => 'integer',
        'value_for_money' => 'integer',
        'verified_purchase' => 'boolean',
        'is_published' => 'boolean',
        'would_recommend' => 'boolean',
        'is_approved' => 'boolean',
        'response_at' => 'datetime',
        'approval_date' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    // Relationships
    public function booking(): BelongsTo
    {
        return $this->belongsTo(Booking::class);
    }

    public function reviewer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'reviewer_id');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function vendor(): BelongsTo
    {
        return $this->belongsTo(Vendor::class);
    }

    public function reviewPhotos(): HasMany
    {
        return $this->hasMany(ReviewPhoto::class);
    }

    public function reviewHelpful(): HasMany
    {
        return $this->hasMany(ReviewHelpful::class);
    }

    // Scopes
    public function scopePublished(Builder $query): Builder
    {
        return $query->where('is_published', true);
    }

    public function scopeByRating(Builder $query, int $rating): Builder
    {
        return $query->where('rating', $rating);
    }

    public function scopeHighestRated(Builder $query): Builder
    {
        return $query->orderBy('rating', 'desc');
    }

    public function scopeWithPhotos(Builder $query): Builder
    {
        return $query->where('photos_count', '>', 0);
    }
}
