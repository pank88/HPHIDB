<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProfileEducation extends Model
{
    use HasFactory;

    protected $table = 'profile_educations';

    protected $fillable = [
        'profile_id',
        'education_level_id',
        'field_of_study',
        'institution_name',
        'completion_year',
        'is_pursuing',
    ];

    protected $casts = [
        'completion_year' => 'integer',
        'is_pursuing' => 'boolean',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function profile(): BelongsTo
    {
        return $this->belongsTo(Profile::class);
    }

    public function education(): BelongsTo
    {
        return $this->belongsTo(Education::class, 'education_level_id');
    }
}
