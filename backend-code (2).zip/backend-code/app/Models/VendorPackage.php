<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class VendorPackage extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'vendor_packages';

    protected $fillable = [
        'vendor_id',
        'service_category_id',
        'name',
        'description',
        'price',
        'currency',
        'duration',
        'duration_unit',
        'inclusions',
        'exclusions',
        'max_guests',
        'is_available',
        'is_featured',
        'booking_count',
        'average_rating',
        'total_reviews',
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'duration' => 'integer',
        'max_guests' => 'integer',
        'is_available' => 'boolean',
        'is_featured' => 'boolean',
        'booking_count' => 'integer',
        'average_rating' => 'float',
        'total_reviews' => 'integer',
        'inclusions' => 'array',
        'exclusions' => 'array',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];

    public function vendor(): BelongsTo
    {
        return $this->belongsTo(Vendor::class);
    }

    public function serviceCategory(): BelongsTo
    {
        return $this->belongsTo(ServiceCategory::class);
    }

    public function bookings(): HasMany
    {
        return $this->hasMany(Booking::class);
    }
}
