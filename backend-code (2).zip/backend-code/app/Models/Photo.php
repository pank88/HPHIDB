<?php

declare(strict_types=1);

namespace App\Models;

use App\Services\SecurePhotoService;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Photo extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'filename',
        'storage_path',
        'original_name',
        'mime_type',
        'file_size',
        'is_primary',
        'is_verified',
        'status',
        'encrypted',
        'verified_at',
        'rejected_reason',
    ];

    protected $casts = [
        'is_primary' => 'boolean',
        'is_verified' => 'boolean',
        'encrypted' => 'boolean',
        'verified_at' => 'datetime',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Several avatar-display resources (MessageResource, UserMinimalResource,
     * TypingIndicatorResource) read `->photo_url` expecting a ready-to-use
     * thumbnail link — this accessor was simply never defined, so those
     * avatars were always null.
     */
    protected function photoUrl(): Attribute
    {
        return Attribute::get(fn () => app(SecurePhotoService::class)->getThumbUrl($this));
    }
}
