<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SuggestedMatch extends Model
{
    use HasFactory;

    protected $table = 'suggested_matches';

    protected $fillable = [
        'user_id',
        'suggested_profile_id',
        'compatibility_score',
        'breakdown',
        'match_reasons',
        'is_interested',
        'interest_expressed_at',
        'is_rejected',
        'rejection_reason',
        'rejected_at',
        'viewed_at',
        'interacted_at',
    ];

    protected $casts = [
        'compatibility_score' => 'float',
        'breakdown' => 'array',
        'match_reasons' => 'array',
        'is_interested' => 'boolean',
        'interest_expressed_at' => 'datetime',
        'is_rejected' => 'boolean',
        'rejected_at' => 'datetime',
        'viewed_at' => 'datetime',
        'interacted_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function suggestedProfile(): BelongsTo
    {
        return $this->belongsTo(Profile::class, 'suggested_profile_id');
    }

    /**
     * Scope to get today's suggestions
     */
    public function scopeToday($query)
    {
        return $query->whereDate('created_at', today());
    }

    /**
     * Scope to exclude rejected and accepted matches
     */
    public function scopeActive($query)
    {
        return $query->where('is_rejected', false);
    }
}
