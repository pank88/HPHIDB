<?php

declare(strict_types=1);

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Vendor extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'vendors';

    protected $fillable = [
        'user_id',
        'business_name',
        'owner_name',
        'bio',
        'description',
        'phone',
        'email',
        'alt_phone',
        'business_address',
        'city_id',
        'postal_code',
        'service_category_id',
        'website',
        'logo_path',
        'rating',
        'total_reviews',
        'response_time_hours',
        'years_of_experience',
        'certifications',
        'social_media',
        'status',
        'is_verified',
        'verification_document_url',
        'verified_at',
        'rating_updated_at',
    ];

    protected $casts = [
        'verified_at' => 'datetime',
        'rating_updated_at' => 'datetime',
        'rating' => 'float',
        'total_reviews' => 'integer',
        'response_time_hours' => 'integer',
        'is_verified' => 'boolean',
        'status' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];

    // Relationships
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function city(): BelongsTo
    {
        return $this->belongsTo(City::class);
    }

    public function serviceCategory(): BelongsTo
    {
        return $this->belongsTo(ServiceCategory::class);
    }

    public function vendorServices(): HasMany
    {
        return $this->hasMany(VendorService::class);
    }

    public function vendorPackages(): HasMany
    {
        return $this->hasMany(VendorPackage::class);
    }

    public function vendorImages(): HasMany
    {
        return $this->hasMany(VendorImage::class);
    }

    public function vendorTestimonials(): HasMany
    {
        return $this->hasMany(VendorTestimonial::class);
    }

    public function vendorAvailabilities(): HasMany
    {
        return $this->hasMany(VendorAvailability::class);
    }

    public function bookings(): HasMany
    {
        return $this->hasMany(Booking::class);
    }

    public function reviews(): HasMany
    {
        return $this->hasMany(Review::class);
    }

    // Scopes
    public function scopeVerified(Builder $query): Builder
    {
        return $query->where('is_verified', true);
    }

    public function scopeHighRated(Builder $query): Builder
    {
        return $query->where('rating', '>=', 4.0);
    }

    public function scopeAvailable(Builder $query, Carbon $date): Builder
    {
        $dayOfWeek = strtolower($date->format('l'));

        return $query->whereHas('vendorAvailabilities', function (Builder $availQuery) use ($dayOfWeek) {
            $availQuery->where('day_of_week', $dayOfWeek)
                ->where('is_available', true);
        });
    }

    public function scopeWithAverageRating(Builder $query): Builder
    {
        return $query->withAvg('reviews', 'rating');
    }

    // Methods
    public function calculateAverageRating(): float
    {
        $averageRating = $this->reviews()
            ->where('is_published', true)
            ->avg('rating');

        $this->update([
            'rating' => $averageRating ?? 0,
            'total_reviews' => $this->reviews()->where('is_published', true)->count(),
            'rating_updated_at' => now(),
        ]);

        return (float) ($averageRating ?? 0);
    }

    public function updateResponseTime(): int
    {
        $avgResponseTime = $this->bookings()
            ->whereNotNull('inquiry_responded_at')
            ->where('status', '!=', 'CANCELLED')
            ->get()
            ->map(function (Booking $booking) {
                $createdAt = $booking->created_at;
                $respondedAt = $booking->inquiry_responded_at;

                return (int) ($respondedAt->diffInMinutes($createdAt) / 60);
            })
            ->avg();

        $responseTimeHours = (int) ($avgResponseTime ?? 0);
        $this->update(['response_time_hours' => $responseTimeHours]);

        return $responseTimeHours;
    }

    public function getAvailabilitySlots(Carbon $date): array
    {
        $dayOfWeek = strtolower($date->format('l'));
        $availability = $this->vendorAvailabilities()
            ->where('day_of_week', $dayOfWeek)
            ->first();

        if (! $availability || ! $availability->is_available) {
            return [];
        }

        $startTime = $availability->start_time ? Carbon::parse($availability->start_time) : Carbon::createFromFormat('H:i', '09:00');
        $endTime = $availability->end_time ? Carbon::parse($availability->end_time) : Carbon::createFromFormat('H:i', '18:00');

        $slots = [];
        $current = $startTime->copy();

        while ($current->lessThan($endTime)) {
            $slotEnd = $current->copy()->addHour();
            if ($slotEnd->greaterThan($endTime)) {
                $slotEnd = $endTime->copy();
            }

            $bookedCount = $this->bookings()
                ->where('service_date', $date->toDateString())
                ->where('service_time_from', '<=', $current->toTimeString())
                ->where('service_time_to', '>', $current->toTimeString())
                ->whereIn('status', ['CONFIRMED', 'IN_PROGRESS'])
                ->count();

            $slots[] = [
                'start_time' => $current->toTimeString(),
                'end_time' => $slotEnd->toTimeString(),
                'is_available' => $bookedCount === 0,
            ];

            $current = $slotEnd->copy();
        }

        return $slots;
    }
}
