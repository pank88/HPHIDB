<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class Message extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'messages';

    protected $fillable = [
        'conversation_id',
        'match_id',
        'sender_id',
        'receiver_id',
        'body',
        'is_read',
        'type',
        'media_url',
        'file_name',
        'file_size',
        'is_edited',
        'edited_at',
        'read_at',
    ];

    protected $casts = [
        'body' => 'encrypted',
        'is_edited' => 'boolean',
        'read_at' => 'datetime',
        'edited_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];

    public function conversation(): BelongsTo
    {
        return $this->belongsTo(Conversation::class);
    }

    public function sender(): BelongsTo
    {
        return $this->belongsTo(User::class, 'sender_id');
    }

    /**
     * Scope: Get only unread messages
     */
    public function scopeUnread(Builder $query): Builder
    {
        return $query->whereNull('read_at');
    }

    /**
     * Scope: Get only visible messages (not soft deleted)
     */
    public function scopeVisible(Builder $query): Builder
    {
        return $query->whereNull('deleted_at');
    }

    /**
     * Scope: Order messages chronologically
     */
    public function scopeOrdered(Builder $query): Builder
    {
        return $query->orderBy('created_at', 'asc');
    }

    /**
     * Mark message as read
     */
    public function markAsRead(): void
    {
        if (! $this->read_at) {
            $this->update(['read_at' => now()]);
        }
    }

    /**
     * Get media URL (signed URL if media exists)
     */
    public function getMediaUrl(): ?string
    {
        if (! $this->media_url) {
            return null;
        }

        return $this->media_url;
    }

    /**
     * Soft delete message
     */
    public function softDelete(): void
    {
        $this->delete();
    }
}
