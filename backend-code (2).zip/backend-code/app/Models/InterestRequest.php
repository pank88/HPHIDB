<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class InterestRequest extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'interest_requests';

    protected $fillable = [
        'sender_id',
        'receiver_id',
        'sender_profile_id',
        'receiver_profile_id',
        'channel',
        'status',
        'message',
        'sent_at',
        'responded_at',
        'expires_at',
    ];

    protected $casts = [
        'sent_at' => 'datetime',
        'responded_at' => 'datetime',
        'expires_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];

    // Status constants
    public const STATUS_PENDING = 'PENDING';

    public const STATUS_ACCEPTED = 'ACCEPTED';

    public const STATUS_REJECTED = 'REJECTED';

    public const STATUS_BLOCKED = 'BLOCKED';

    public const STATUS_EXPIRED = 'EXPIRED';

    // Channel constants
    public const CHANNEL_APP = 'app';

    public const CHANNEL_SMS = 'sms';

    public const CHANNEL_EMAIL = 'email';

    public function sender(): BelongsTo
    {
        return $this->belongsTo(User::class, 'sender_id');
    }

    public function receiver(): BelongsTo
    {
        return $this->belongsTo(User::class, 'receiver_id');
    }

    public function senderProfile(): BelongsTo
    {
        return $this->belongsTo(Profile::class, 'sender_profile_id');
    }

    public function receiverProfile(): BelongsTo
    {
        return $this->belongsTo(Profile::class, 'receiver_profile_id');
    }

    /**
     * Scope: Get pending interests only
     */
    public function scopePending(Builder $query): Builder
    {
        return $query->where('status', self::STATUS_PENDING);
    }

    /**
     * Scope: Get interests sent by a user
     */
    public function scopeSentBy(Builder $query, User $user): Builder
    {
        return $query->where('sender_id', $user->id);
    }

    /**
     * Scope: Get interests received by a user
     */
    public function scopeReceivedBy(Builder $query, User $user): Builder
    {
        return $query->where('receiver_id', $user->id);
    }

    /**
     * Scope: Get active interests (pending or accepted, not expired)
     */
    public function scopeActive(Builder $query): Builder
    {
        return $query->whereIn('status', [self::STATUS_PENDING, self::STATUS_ACCEPTED])
            ->where('expires_at', '>', now());
    }

    /**
     * Scope: Get expired pending interests
     */
    public function scopeExpired(Builder $query): Builder
    {
        return $query->where('status', self::STATUS_PENDING)
            ->where('expires_at', '<', now());
    }
}
