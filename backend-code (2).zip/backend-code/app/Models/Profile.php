<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class Profile extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'profiles';

    protected $fillable = [
        'user_id',
        'first_name',
        'full_name',
        'last_name',
        'date_of_birth',
        'gender',
        'created_for',
        'height',
        'height_cm',
        'weight',
        'body_type',
        'skin_tone',
        'complexion',
        'food_type',
        'about',
        'marital_status',
        'religion_id',
        'caste_id',
        'gotra_id',
        'mother_tongue',
        'education_id',
        'occupation_id',
        'annual_income',
        'income_level_id',
        'occupation_detail',
        'city_id',
        'state_id',
        'country',
        'bio',
        'looking_for',
        'profile_completion_percentage',
        'is_verified',
        'verification_date',
        'is_active',
        'is_featured',
        'moderation_status',
        'moderated_at',
        'moderated_by',
        'rejection_reason',
    ];

    protected $casts = [
        'date_of_birth' => 'date',
        'verification_date' => 'datetime',
        'profile_completion_percentage' => 'integer',
        'marital_status' => 'integer',
        'height_cm' => 'integer',
        'is_verified' => 'boolean',
        'is_active' => 'boolean',
        'is_featured' => 'boolean',
        'moderation_status' => 'integer',
        'moderated_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'deleted_at' => 'datetime',
    ];

    public function moderator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'moderated_by');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function religion(): BelongsTo
    {
        return $this->belongsTo(Religion::class);
    }

    public function caste(): BelongsTo
    {
        return $this->belongsTo(Caste::class);
    }

    public function gotra(): BelongsTo
    {
        return $this->belongsTo(Gotra::class);
    }

    public function education(): BelongsTo
    {
        return $this->belongsTo(Education::class);
    }

    public function occupation(): BelongsTo
    {
        return $this->belongsTo(Occupation::class);
    }

    public function city(): BelongsTo
    {
        return $this->belongsTo(City::class);
    }

    public function state(): BelongsTo
    {
        return $this->belongsTo(State::class);
    }

    public function incomeLevel(): BelongsTo
    {
        return $this->belongsTo(IncomeLevel::class);
    }

    public function profileEducations(): HasMany
    {
        return $this->hasMany(ProfileEducation::class);
    }

    public function profilePhotos(): HasMany
    {
        return $this->hasMany(ProfilePhoto::class);
    }

    public function educations(): HasMany
    {
        return $this->hasMany(ProfileEducation::class);
    }

    /**
     * Photos actually uploaded through the real upload pipeline
     * (POST /profile/photos → SecurePhotoService → `photos` table, keyed by
     * user_id). `profilePhotos()` below is a separate, legacy relation to
     * ProfilePhoto/`profile_photos` used by search filters and admin
     * moderation — this one is what profile-display views should read.
     */
    public function photos(): HasMany
    {
        return $this->hasMany(Photo::class, 'user_id', 'user_id');
    }

    public function hobbies(): BelongsToMany
    {
        return $this->belongsToMany(Hobby::class, 'profile_hobbies', 'profile_id', 'hobby_id');
    }

    public function partnerPreference(): HasOne
    {
        return $this->hasOne(PartnerPreference::class);
    }

    public function interestRequestsReceived(): HasMany
    {
        return $this->hasMany(InterestRequest::class, 'receiver_profile_id');
    }

    public function suggestedMatches(): HasMany
    {
        return $this->hasMany(SuggestedMatch::class, 'suggested_profile_id');
    }

    /**
     * Scope to get searchable profiles (published, verified, active)
     */
    public function scopeSearchable($query)
    {
        return $query->where('is_active', true)
            ->where('is_verified', true)
            ->whereNull('deleted_at')
            ->whereHas('user', function ($userQuery) {
                // This app verifies mobile via OTP, not email — there's no
                // email verification flow, so email_verified_at is always
                // null and this check silently excluded every real user
                // from ever appearing in search results.
                $userQuery->whereNotNull('phone_verified_at');
            });
    }

    /**
     * Scope to eager load relationships needed for compatibility scoring
     */
    public function scopeWithCompatibility($query)
    {
        return $query->with([
            'user',
            'religion',
            'caste',
            'gotra',
            'education',
            'occupation',
            'city',
            'state',
            'profilePhotos',
            'hobbies',
            'partnerPreference',
        ]);
    }
}
