<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class VendorAvailability extends Model
{
    use HasFactory;

    protected $table = 'vendor_availabilities';

    protected $fillable = [
        'vendor_id',
        'available_date',
        'available_from',
        'available_to',
        'is_available',
        'notes',
    ];

    protected $casts = [
        'available_date' => 'date',
        'available_from' => 'datetime',
        'available_to' => 'datetime',
        'is_available' => 'boolean',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    public function vendor(): BelongsTo
    {
        return $this->belongsTo(Vendor::class);
    }
}
