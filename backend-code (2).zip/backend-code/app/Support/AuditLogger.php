<?php

declare(strict_types=1);

namespace App\Support;

use App\Models\AuditLog;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;

/**
 * Thin replacement for the spatie/laravel-activitylog `activity()` helper,
 * which several services called but the package was never installed —
 * every one of those calls fatal-errored with "Call to undefined function".
 * Writes straight to the app's own `audit_logs` table (App\Models\AuditLog),
 * already read by Admin\DashboardController's recent-activity feed.
 */
class AuditLogger
{
    public static function log(User $user, Model $subject, string $action, array $properties = []): AuditLog
    {
        return AuditLog::create([
            'user_id' => $user->id,
            'action' => $action,
            'model_type' => $subject::class,
            'model_id' => $subject->getKey(),
            'entity_type' => class_basename($subject),
            'entity_id' => $subject->getKey(),
            'new_values' => $properties,
        ]);
    }
}
