<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\InterestRejected;
use App\Services\NotificationService;

class SendRejectionNotification
{
    public function __construct(private NotificationService $notificationService) {}

    public function handle(InterestRejected $event): void
    {
        $this->notificationService->notifyInterestRejected($event->interest->sender, $event->interest);
    }
}
