<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\BookingCancelled;
use App\Events\BookingCompleted;
use App\Events\BookingConfirmed;
use App\Events\BookingInquiryCreated;
use App\Events\QuotationProvided;
use App\Events\ReviewCreated;
use App\Models\AuditLog;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class LogBookingActivity implements ShouldQueue
{
    use InteractsWithQueue;

    public function handle(BookingInquiryCreated|QuotationProvided|BookingConfirmed|BookingCompleted|BookingCancelled|ReviewCreated $event): void
    {
        if ($event instanceof BookingInquiryCreated) {
            $this->logBookingEvent($event->booking->user_id, 'booking_inquiry_created', $event->booking->id);
        } elseif ($event instanceof QuotationProvided) {
            $this->logBookingEvent($event->booking->user_id, 'quotation_provided', $event->booking->id);
        } elseif ($event instanceof BookingConfirmed) {
            $this->logBookingEvent($event->booking->user_id, 'booking_confirmed', $event->booking->id);
        } elseif ($event instanceof BookingCompleted) {
            $this->logBookingEvent($event->booking->user_id, 'booking_completed', $event->booking->id);
        } elseif ($event instanceof BookingCancelled) {
            $this->logBookingEvent($event->booking->user_id, 'booking_cancelled', $event->booking->id);
        } elseif ($event instanceof ReviewCreated) {
            $this->logBookingEvent($event->review->reviewer_id ?? $event->review->user_id, 'review_created', $event->review->id);
        }
    }

    private function logBookingEvent(int $userId, string $action, int $modelId): void
    {
        AuditLog::create([
            'user_id' => $userId,
            'action' => $action,
            'model_id' => $modelId,
            'model_type' => match ($action) {
                'review_created' => 'Review',
                default => 'Booking',
            },
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
        ]);
    }
}
