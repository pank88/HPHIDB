<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\BookingCancelled;
use App\Events\BookingCompleted;
use App\Events\BookingConfirmed;
use App\Events\BookingInquiryCreated;
use App\Events\QuotationProvided;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class SendBookingNotifications implements ShouldQueue
{
    use InteractsWithQueue;

    public function handle(BookingInquiryCreated|QuotationProvided|BookingConfirmed|BookingCompleted|BookingCancelled $event): void
    {
        if ($event instanceof BookingInquiryCreated) {
            $this->notifyVendorOfNewInquiry($event);
        } elseif ($event instanceof QuotationProvided) {
            $this->notifyUserOfQuotation($event);
        } elseif ($event instanceof BookingConfirmed) {
            $this->notifyVendorOfConfirmation($event);
        } elseif ($event instanceof BookingCompleted) {
            $this->notifyUserOfCompletion($event);
        } elseif ($event instanceof BookingCancelled) {
            $this->notifyOfCancellation($event);
        }
    }

    private function notifyVendorOfNewInquiry(BookingInquiryCreated $event): void
    {
        // Send notification to vendor
        // Implementation: Send email, push notification, SMS, etc.
    }

    private function notifyUserOfQuotation(QuotationProvided $event): void
    {
        // Send notification to user about quotation
    }

    private function notifyVendorOfConfirmation(BookingConfirmed $event): void
    {
        // Send notification to vendor about confirmation
    }

    private function notifyUserOfCompletion(BookingCompleted $event): void
    {
        // Send notification to user to review the service
    }

    private function notifyOfCancellation(BookingCancelled $event): void
    {
        // Send notification to both parties about cancellation
    }
}
