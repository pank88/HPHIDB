<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\MessageDeleted;
use App\Models\AuditLog;
use Illuminate\Http\Request;

class LogMessageDeleted
{
    public function __construct(protected Request $request) {}

    public function handle(MessageDeleted $event): void
    {
        AuditLog::create([
            'user_id' => $this->request->user()?->id,
            'action' => 'message_deleted',
            'model' => 'Message',
            'model_id' => $event->messageId,
            'description' => 'User deleted a message in conversation '.$event->conversation->id,
            'ip_address' => $this->request->ip(),
            'user_agent' => $this->request->userAgent(),
        ]);
    }
}
