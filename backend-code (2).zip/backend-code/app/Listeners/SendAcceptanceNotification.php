<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\InterestAccepted;
use App\Services\NotificationService;

class SendAcceptanceNotification
{
    public function __construct(private NotificationService $notificationService) {}

    public function handle(InterestAccepted $event): void
    {
        $this->notificationService->notifyInterestAccepted($event->interest->sender, $event->interest);
    }
}
