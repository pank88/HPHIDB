<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\UserBlocked;
use App\Models\AuditLog;

class LogBlockedUser
{
    public function handle(UserBlocked $event): void
    {
        AuditLog::create([
            'user_id' => $event->interest->receiver_id,
            'action' => 'user_blocked',
            'model_type' => 'InterestRequest',
            'model_id' => $event->interest->id,
            'old_values' => ['status' => $event->interest->getOriginal('status')],
            'new_values' => ['status' => 'BLOCKED'],
            'description' => "Blocked user {$event->interest->sender_id} via interest {$event->interest->id}",
        ]);
    }
}
