<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\MatchBlocked;
use App\Models\AuditLog;

class LogMatchBlocked
{
    public function handle(MatchBlocked $event): void
    {
        AuditLog::create([
            'user_id' => $event->match->blocked_by_id,
            'action' => 'match_blocked',
            'model_type' => 'UserMatch',
            'model_id' => $event->match->id,
            'old_values' => ['is_active' => true, 'blocked_by_id' => null],
            'new_values' => ['is_active' => false, 'blocked_by_id' => $event->match->blocked_by_id],
            'description' => "Blocked match {$event->match->id} with user {$event->match->matcher_id}",
        ]);
    }
}
