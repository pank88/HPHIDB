<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\ReviewCreated;
use App\Services\VendorService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class UpdateVendorRating implements ShouldQueue
{
    use InteractsWithQueue;

    public function __construct(private VendorService $vendorService) {}

    public function handle(ReviewCreated $event): void
    {
        $this->vendorService->updateVendorRating($event->review->vendor);
    }
}
