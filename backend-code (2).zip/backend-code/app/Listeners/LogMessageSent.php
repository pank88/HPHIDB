<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\MessageSent;
use App\Models\AuditLog;

class LogMessageSent
{
    public function handle(MessageSent $event): void
    {
        AuditLog::create([
            'user_id' => $event->message->sender_id,
            'action' => 'message_sent',
            'model' => 'Message',
            'model_id' => $event->message->id,
            'description' => 'User sent a message in conversation '.$event->conversation->id,
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
        ]);
    }
}
