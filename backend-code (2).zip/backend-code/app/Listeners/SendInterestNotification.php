<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\InterestRequested;
use App\Services\NotificationService;

class SendInterestNotification
{
    public function __construct(private NotificationService $notificationService) {}

    public function handle(InterestRequested $event): void
    {
        $this->notificationService->notifyInterestReceived($event->interest->receiver, $event->interest);
    }
}
