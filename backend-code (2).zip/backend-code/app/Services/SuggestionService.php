<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Profile;
use App\Models\SuggestedMatch;
use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;

class SuggestionService
{
    protected MatchingService $matchingService;

    public function __construct(MatchingService $matchingService)
    {
        $this->matchingService = $matchingService;
    }

    /**
     * Generate daily suggestions for a user
     *
     * @return Collection Collection of suggested profiles
     */
    public function generateDailySuggestions(User $user): Collection
    {
        $cacheKey = "suggestions_user_{$user->id}_".today()->format('Y-m-d');

        // Check cache first
        $cached = Cache::get($cacheKey);
        if ($cached) {
            return $cached;
        }

        $userProfile = $user->profiles()->first();
        if (! $userProfile) {
            return collect();
        }

        // Get candidates based on user preferences
        $candidates = $this->getCandidatesForUser($user);

        if ($candidates->isEmpty()) {
            Cache::put($cacheKey, collect(), $this->getCacheTtl());

            return collect();
        }

        // Calculate compatibility and rank
        $scored = $candidates->map(function (Profile $candidate) use ($user) {
            return [
                'profile' => $candidate,
                'score' => $this->matchingService->calculateCompatibility($user, $candidate),
                'breakdown' => $this->matchingService->calculateDetailedBreakdown($user, $candidate),
            ];
        });

        // Sort by score descending
        $sorted = $scored->sortByDesc('score')->values();

        // Take top N suggestions
        $limit = config('discovery.suggestions_per_user', 10);
        $topSuggestions = $sorted->take($limit);

        // Store in database
        $this->storeSuggestions($user, $topSuggestions);

        // Cache results
        $results = $topSuggestions->pluck('profile');
        Cache::put($cacheKey, $results, $this->getCacheTtl());

        return $results;
    }

    /**
     * Get candidate profiles for user based on their preferences
     */
    private function getCandidatesForUser(User $user): Collection
    {
        $userProfile = $user->profiles()->first();
        if (! $userProfile || ! $userProfile->partnerPreference) {
            return collect();
        }

        $prefs = $userProfile->partnerPreference;

        $query = Profile::searchable()->withCompatibility();

        // Exclude own profile
        $query->where('id', '!=', $userProfile->id);

        // Exclude already interacted
        $query->whereDoesntHave('suggestedMatches', function ($q) use ($user) {
            $q->where('user_id', $user->id)
                ->where('is_rejected', false);
        });

        // Age preferences
        if ($prefs->age_from) {
            $minDate = now()->subYears($prefs->age_from);
            $query->where('date_of_birth', '<=', $minDate);
        }
        if ($prefs->age_to) {
            $maxDate = now()->subYears($prefs->age_to);
            $query->where('date_of_birth', '>=', $maxDate);
        }

        // Height preferences
        if ($prefs->height_from) {
            $query->where('height', '>=', $prefs->height_from);
        }
        if ($prefs->height_to) {
            $query->where('height', '<=', $prefs->height_to);
        }

        // Religion
        if ($prefs->religion_id) {
            $query->where('religion_id', $prefs->religion_id);
        }

        // Caste
        if ($prefs->caste_id) {
            $query->where('caste_id', $prefs->caste_id);
        }

        // Education
        if ($prefs->education_id) {
            $query->where('education_id', $prefs->education_id);
        }

        // Occupation
        if ($prefs->occupation_id) {
            $query->where('occupation_id', $prefs->occupation_id);
        }

        // Location preferences
        if ($prefs->state_id) {
            $query->where('state_id', $prefs->state_id);
        }
        if ($prefs->city_id) {
            $query->where('city_id', $prefs->city_id);
        }

        // Marital status
        if ($prefs->marital_status) {
            $query->where('marital_status', $prefs->marital_status);
        }

        // Body type / skin tone
        if ($prefs->body_type) {
            $query->where('complexion', $prefs->body_type);
        }

        return $query->get();
    }

    /**
     * Store suggestions in database
     */
    private function storeSuggestions(User $user, Collection $suggestions): void
    {
        // Clear today's old suggestions
        SuggestedMatch::where('user_id', $user->id)
            ->today()
            ->delete();

        // Insert new suggestions
        $inserts = $suggestions->map(function ($item, $index) use ($user) {
            return [
                'user_id' => $user->id,
                'suggested_profile_id' => $item['profile']->id,
                'compatibility_score' => $item['score'],
                'breakdown' => $item['breakdown'],
                'created_at' => now(),
                'updated_at' => now(),
            ];
        })->values();

        if (! $inserts->isEmpty()) {
            SuggestedMatch::insert($inserts->toArray());
        }
    }

    /**
     * Get today's suggestions for a user
     */
    public function getTodaysSuggestions(User $user): Collection
    {
        $cacheKey = "suggestions_user_{$user->id}_".today()->format('Y-m-d');

        // Check cache first
        $cached = Cache::get($cacheKey);
        if ($cached) {
            return $cached;
        }

        // Fetch from database
        $suggestions = SuggestedMatch::where('user_id', $user->id)
            ->today()
            ->active()
            ->orderByDesc('compatibility_score')
            ->with(['suggestedProfile' => function ($q) {
                $q->with([
                    'user',
                    'religion',
                    'caste',
                    'gotra',
                    'education',
                    'occupation',
                    'city',
                    'state',
                    'profilePhotos',
                    'hobbies',
                    'partnerPreference',
                ]);
            }])
            ->get()
            ->pluck('suggestedProfile');

        // If no suggestions, generate them
        if ($suggestions->isEmpty()) {
            $suggestions = $this->generateDailySuggestions($user);
        } else {
            // Cache retrieved results
            Cache::put($cacheKey, $suggestions, $this->getCacheTtl());
        }

        return $suggestions;
    }

    /**
     * Get compatibility breakdown for a suggestion
     */
    public function getBreakdown(User $user, Profile $profile): array
    {
        // Try to get from database first
        $suggestion = SuggestedMatch::where('user_id', $user->id)
            ->where('suggested_profile_id', $profile->id)
            ->first();

        if ($suggestion && $suggestion->breakdown) {
            // Stored breakdowns may predate the per-factor explanation field
            return array_map(
                fn (array $factor): array => $factor + ['message' => ''],
                $suggestion->breakdown
            );
        }

        // Calculate if not found
        return $this->matchingService->calculateDetailedBreakdown($user, $profile);
    }

    /**
     * Record that user viewed a suggestion
     */
    public function recordView(User $user, Profile $profile): void
    {
        SuggestedMatch::where('user_id', $user->id)
            ->where('suggested_profile_id', $profile->id)
            ->update(['viewed_at' => now()]);
    }

    /**
     * Record that user interacted with a suggestion
     */
    public function recordInteraction(User $user, Profile $profile): void
    {
        SuggestedMatch::where('user_id', $user->id)
            ->where('suggested_profile_id', $profile->id)
            ->update(['interacted_at' => now()]);
    }

    /**
     * Refresh suggestions for a user (clears cache and regenerates)
     */
    public function refreshSuggestions(User $user): Collection
    {
        $cacheKey = "suggestions_user_{$user->id}_".today()->format('Y-m-d');
        Cache::forget($cacheKey);

        return $this->generateDailySuggestions($user);
    }

    /**
     * Get cache TTL
     */
    private function getCacheTtl(): int
    {
        return config('discovery.suggestions_cache_ttl', 86400); // 24 hours
    }
}
