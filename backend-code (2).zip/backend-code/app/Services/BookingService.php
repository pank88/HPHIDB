<?php

declare(strict_types=1);

namespace App\Services;

use App\Constants\UserRole;
use App\Events\BookingCancelled;
use App\Events\BookingCompleted;
use App\Events\BookingConfirmed;
use App\Events\BookingInquiryCreated;
use App\Events\QuotationProvided;
use App\Exceptions\BookingException;
use App\Models\Booking;
use App\Models\User;
use App\Models\Vendor;
use App\Models\VendorService;
use Carbon\Carbon;
use Illuminate\Pagination\LengthAwarePaginator;

class BookingService
{
    public function createBookingInquiry(User $user, array $data): Booking
    {
        $vendorService = VendorService::findOrFail($data['vendor_service_id']);

        $booking = Booking::create([
            'user_id' => $user->id,
            'vendor_id' => $vendorService->vendor_id,
            'vendor_service_id' => $data['vendor_service_id'],
            'service_date' => $data['service_date'],
            'service_time_from' => $data['service_time_from'] ?? null,
            'service_time_to' => $data['service_time_to'] ?? null,
            'location_address' => $data['location_address'],
            'location_city_id' => $data['location_city_id'],
            'guests_count' => $data['guests_count'] ?? null,
            'special_requirements' => $data['special_requirements'] ?? null,
            'estimated_amount' => $vendorService->base_price,
            'status' => 'INQUIRY',
            'payment_status' => 'PENDING',
        ]);

        event(new BookingInquiryCreated($booking));

        return $booking->load('vendor', 'vendorService', 'city');
    }

    public function respondToInquiry(Vendor $vendor, Booking $booking, float $finalAmount): Booking
    {
        if ($booking->vendor_id !== $vendor->id) {
            throw BookingException::vendorMismatch();
        }

        if ($booking->status !== 'INQUIRY') {
            throw BookingException::invalidStatus($booking->status);
        }

        $booking->update([
            'status' => 'QUOTED',
            'final_amount' => $finalAmount,
            'inquiry_responded_at' => now(),
            'inquiry_response_time_minutes' => (int) ($booking->created_at->diffInMinutes(now())),
        ]);

        event(new QuotationProvided($booking));

        return $booking->fresh();
    }

    public function confirmBooking(User $user, Booking $booking): Booking
    {
        if ($booking->user_id !== $user->id) {
            throw BookingException::userMismatch();
        }

        if (! $booking->canAcceptQuote()) {
            throw BookingException::invalidStatus($booking->status);
        }

        $booking->update([
            'status' => 'CONFIRMED',
            'confirmed_at' => now(),
            'payment_status' => 'PARTIAL',
        ]);

        event(new BookingConfirmed($booking));

        return $booking->fresh();
    }

    public function cancelBooking(User $user, Booking $booking, ?string $reason = null): Booking
    {
        $isUserOwner = $booking->user_id === $user->id;
        $isVendor = $user->vendor && $user->vendor->id === $booking->vendor_id;

        if (! $isUserOwner && ! $isVendor) {
            throw BookingException::notInvolved();
        }

        if (in_array($booking->status, ['COMPLETED', 'CANCELLED'])) {
            throw BookingException::invalidStatus($booking->status);
        }

        $booking->cancelBooking($reason);

        if ($booking->payment_status === 'PAID') {
            // Process refund logic here
        }

        event(new BookingCancelled($booking));

        return $booking->fresh();
    }

    public function completeBooking(Vendor $vendor, Booking $booking): Booking
    {
        if ($booking->vendor_id !== $vendor->id) {
            throw BookingException::vendorMismatch();
        }

        if ($booking->status !== 'CONFIRMED') {
            throw BookingException::invalidStatus($booking->status);
        }

        if (Carbon::now()->toDateString() < $booking->service_date->toDateString()) {
            throw BookingException::pastServiceDate();
        }

        $booking->completeBooking();

        event(new BookingCompleted($booking));

        return $booking->fresh();
    }

    public function getBookings(User $user, ?string $status = null, int $page = 1): LengthAwarePaginator
    {
        // A vendor calling GET /bookings wants inquiries/bookings made
        // *against their business*, not bookings they personally placed —
        // scopeForVendor existed but nothing ever called it, so vendors had
        // no way to see their incoming bookings at all.
        $query = (int) $user->role === UserRole::VENDOR
            ? Booking::forVendor($user)
            : Booking::forUser($user);

        if ($status) {
            $query->byStatus($status);
        }

        return $query->with('vendor', 'vendorService', 'review', 'user')
            ->orderBy('service_date', 'desc')
            ->paginate(20, ['*'], 'page', $page);
    }
}
