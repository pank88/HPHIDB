<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Profile;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Pagination\Paginator;

class SearchService
{
    protected MatchingService $matchingService;

    public function __construct(MatchingService $matchingService)
    {
        $this->matchingService = $matchingService;
    }

    /**
     * Search profiles based on filters
     *
     * @param  User  $user  The user performing the search
     * @param  array  $filters  Search filters
     * @return Paginator Paginated results
     */
    public function search(User $user, array $filters): Paginator
    {
        $query = Profile::searchable()->withCompatibility();

        // Exclude own profile
        $userProfile = $user->profiles()->first();
        if ($userProfile) {
            $query->where('id', '!=', $userProfile->id);
        }

        // Exclude blocked users
        $blockedUserIds = $this->getBlockedUserIds($user);
        if (! empty($blockedUserIds)) {
            $query->whereNotIn('user_id', $blockedUserIds);
        }

        // Apply filters
        $query = $this->applyFilters($query, $filters);

        // Apply sorting
        $sortBy = $filters['sort_by'] ?? 'compatibility';
        $query = $this->applySorting($query, $sortBy, $user);

        // Paginate
        $page = $filters['page'] ?? 1;
        $pageSize = config('discovery.search_page_size', 20);

        return $query->simplePaginate($pageSize, ['*'], 'page', $page);
    }

    /**
     * Apply search filters to query
     */
    private function applyFilters(Builder $query, array $filters): Builder
    {
        // Age filter
        if (isset($filters['age_min'])) {
            $minDate = now()->subYears($filters['age_min']);
            $query->where('date_of_birth', '<=', $minDate);
        }
        if (isset($filters['age_max'])) {
            $maxDate = now()->subYears($filters['age_max']);
            $query->where('date_of_birth', '>=', $maxDate);
        }

        // Height filter
        if (isset($filters['height_min'])) {
            $query->where('height', '>=', $filters['height_min']);
        }
        if (isset($filters['height_max'])) {
            $query->where('height', '<=', $filters['height_max']);
        }

        // Religion filter
        if (isset($filters['religion_id'])) {
            $query->where('religion_id', $filters['religion_id']);
        }

        // Caste filter
        if (isset($filters['caste_ids']) && is_array($filters['caste_ids'])) {
            $query->whereIn('caste_id', $filters['caste_ids']);
        }

        // Gotra filter
        if (isset($filters['gotra_ids']) && is_array($filters['gotra_ids'])) {
            $query->whereIn('gotra_id', $filters['gotra_ids']);
        }

        // Complexion filter
        if (isset($filters['complexions']) && is_array($filters['complexions'])) {
            $query->whereIn('complexion', $filters['complexions']);
        }

        // Food type filter
        if (isset($filters['food_types']) && is_array($filters['food_types'])) {
            $query->whereIn('food_type', $filters['food_types']);
        }

        // Education filter
        if (isset($filters['education_ids']) && is_array($filters['education_ids'])) {
            $query->whereIn('education_id', $filters['education_ids']);
        }

        // Occupation filter
        if (isset($filters['occupation_ids']) && is_array($filters['occupation_ids'])) {
            $query->whereIn('occupation_id', $filters['occupation_ids']);
        }

        // State filter
        if (isset($filters['state_id'])) {
            $query->where('state_id', $filters['state_id']);
        }

        // City filter
        if (isset($filters['city_id'])) {
            $query->where('city_id', $filters['city_id']);
        }

        // Hobby filter
        if (isset($filters['hobby_ids']) && is_array($filters['hobby_ids'])) {
            $query->whereHas('hobbies', function ($q) use ($filters) {
                $q->whereIn('hobby_id', $filters['hobby_ids']);
            }, '>=', count($filters['hobby_ids']));
        }

        // Profile completeness filter
        if (isset($filters['profile_completeness_min'])) {
            $query->where('profile_completion_percentage', '>=', $filters['profile_completeness_min']);
        }

        // Photos filter
        if (isset($filters['photos_min'])) {
            $query->whereHas('profilePhotos', function ($q) {
                $q->where('is_verified', true);
            }, '>=', $filters['photos_min']);
        }

        return $query;
    }

    /**
     * Apply sorting to query
     */
    private function applySorting(Builder $query, string $sortBy, User $user): Builder
    {
        switch ($sortBy) {
            case 'recent':
                return $query->orderByDesc('created_at');

            case 'completeness':
                return $query->orderByDesc('profile_completion_percentage');

            case 'photos':
                return $query->withCount(['profilePhotos' => function ($q) {
                    $q->where('is_verified', true);
                }])
                    ->orderByDesc('profile_photos_count');

            case 'compatibility':
            default:
                // For compatibility sort, we'll do it in memory after fetching
                // This is a limitation but necessary for now
                return $query->orderByDesc('created_at'); // Fallback
        }
    }

    /**
     * Get IDs of users blocked by the current user
     */
    private function getBlockedUserIds(User $user): array
    {
        // TODO: Implement blocking logic when blocking feature is added
        // For now, return empty array
        return [];
    }

    /**
     * Calculate compatibility for search results
     */
    public function addCompatibilityScores($profiles, User $user): void
    {
        foreach ($profiles as $profile) {
            if ($profile->user) {
                $profile->compatibility_score = $this->matchingService->calculateCompatibility(
                    $user,
                    $profile
                );
                $profile->compatibility_breakdown = $this->matchingService->calculateDetailedBreakdown(
                    $user,
                    $profile
                );
            }
        }
    }
}
