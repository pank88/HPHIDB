<?php

declare(strict_types=1);

namespace App\Services;

use App\Events\InterestAccepted;
use App\Events\InterestRejected;
use App\Events\InterestRequested;
use App\Events\UserBlocked;
use App\Models\InterestRequest;
use App\Models\Profile;
use App\Models\User;
use App\Models\UserMatch;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

class InterestService
{
    protected NotificationService $notificationService;

    public function __construct(NotificationService $notificationService)
    {
        $this->notificationService = $notificationService;
    }

    /**
     * Send interest from sender to receiver profile
     */
    public function sendInterest(
        User $sender,
        Profile $receiverProfile,
        ?string $message = null,
        string $channel = InterestRequest::CHANNEL_APP
    ): InterestRequest {
        // Validate receiver profile belongs to different user
        if ($receiverProfile->user_id === $sender->id) {
            throw new \InvalidArgumentException('Cannot send interest to yourself');
        }

        $receiver = $receiverProfile->user;

        // Validate receiver is not blocked
        if ($this->isBlocked($sender->id, $receiver->id)) {
            throw new \InvalidArgumentException('You are blocked by this user');
        }

        // Validate no existing pending interest between users
        $existingInterest = InterestRequest::where(function ($query) use ($sender, $receiver) {
            $query->where('sender_id', $sender->id)
                ->where('receiver_id', $receiver->id);
        })->orWhere(function ($query) use ($sender, $receiver) {
            $query->where('sender_id', $receiver->id)
                ->where('receiver_id', $sender->id);
        })
            ->where('status', InterestRequest::STATUS_PENDING)
            ->first();

        if ($existingInterest) {
            throw new \InvalidArgumentException('Interest already exists between these users');
        }

        // Get sender's profile
        $senderProfile = $sender->profiles()->first();
        if (! $senderProfile) {
            throw new \InvalidArgumentException('Sender profile not found');
        }

        // Create interest request
        $interest = InterestRequest::create([
            'sender_id' => $sender->id,
            'receiver_id' => $receiver->id,
            'sender_profile_id' => $senderProfile->id,
            'receiver_profile_id' => $receiverProfile->id,
            'channel' => $channel,
            'status' => InterestRequest::STATUS_PENDING,
            'message' => $message,
            'sent_at' => now(),
            'expires_at' => now()->addDays(config('interests.interest_ttl_days', 30)),
        ]);

        // Fire event
        InterestRequested::dispatch($interest);

        // Send notification
        $this->notificationService->notifyInterestReceived($receiver, $interest);

        return $interest->load(['sender', 'receiver', 'senderProfile', 'receiverProfile']);
    }

    /**
     * Accept interest request
     */
    public function acceptInterest(User $receiver, InterestRequest $interest): UserMatch
    {
        // Validate receiver owns this interest
        if ($interest->receiver_id !== $receiver->id) {
            throw new \InvalidArgumentException('You cannot accept this interest');
        }

        // Validate status is pending
        if ($interest->status !== InterestRequest::STATUS_PENDING) {
            throw new \InvalidArgumentException('Interest is no longer pending');
        }

        // Validate not expired
        if ($interest->expires_at < now()) {
            throw new \InvalidArgumentException('Interest has expired');
        }

        // Create match
        $match = UserMatch::create([
            'initiator_id' => $interest->sender_id,
            'matcher_id' => $interest->receiver_id,
            'initiator_profile_id' => $interest->sender_profile_id,
            'matcher_profile_id' => $interest->receiver_profile_id,
            'interest_id' => $interest->id,
            'connected_at' => now(),
            'is_active' => true,
        ]);

        // Update interest status
        $interest->update([
            'status' => InterestRequest::STATUS_ACCEPTED,
            'responded_at' => now(),
        ]);

        // Fire event
        InterestAccepted::dispatch($interest);

        // Send notification
        $this->notificationService->notifyInterestAccepted($interest->sender, $interest);

        return $match->load(['initiator', 'matcher', 'initiatorProfile', 'matcherProfile']);
    }

    /**
     * Reject interest request
     */
    public function rejectInterest(User $receiver, InterestRequest $interest, ?string $reason = null): InterestRequest
    {
        // Validate receiver owns this interest
        if ($interest->receiver_id !== $receiver->id) {
            throw new \InvalidArgumentException('You cannot reject this interest');
        }

        // Validate status is pending
        if ($interest->status !== InterestRequest::STATUS_PENDING) {
            throw new \InvalidArgumentException('Interest is no longer pending');
        }

        // Update status
        $interest->update([
            'status' => InterestRequest::STATUS_REJECTED,
            'responded_at' => now(),
        ]);

        // Fire event
        InterestRejected::dispatch($interest);

        // Send notification
        $this->notificationService->notifyInterestRejected($interest->sender, $interest);

        return $interest->load(['sender', 'receiver', 'senderProfile', 'receiverProfile']);
    }

    /**
     * Block interest request
     */
    public function blockInterest(User $receiver, InterestRequest $interest): InterestRequest
    {
        // Validate receiver owns this interest
        if ($interest->receiver_id !== $receiver->id) {
            throw new \InvalidArgumentException('You cannot block this interest');
        }

        // Validate status is pending
        if ($interest->status !== InterestRequest::STATUS_PENDING) {
            throw new \InvalidArgumentException('Interest is no longer pending');
        }

        // Update status
        $interest->update([
            'status' => InterestRequest::STATUS_BLOCKED,
            'responded_at' => now(),
        ]);

        // Block user
        $this->blockUser($receiver->id, $interest->sender_id);

        // Fire event
        UserBlocked::dispatch($interest);

        // Send notification
        $this->notificationService->notifyUserBlocked($interest->sender);

        return $interest->load(['sender', 'receiver', 'senderProfile', 'receiverProfile']);
    }

    /**
     * Get received interests for user
     */
    public function getReceivedInterests(
        User $user,
        ?string $status = null,
        int $page = 1
    ): LengthAwarePaginator {
        $query = InterestRequest::where('receiver_id', $user->id)
            ->with(['sender', 'senderProfile', 'receiver', 'receiverProfile'])
            ->orderByDesc('sent_at');

        if ($status) {
            $query->where('status', $status);
        } else {
            // Exclude expired pending interests by default
            $query->where(function ($q) {
                $q->where('status', '!=', InterestRequest::STATUS_PENDING)
                    ->orWhere('expires_at', '>', now());
            });
        }

        return $query->paginate(
            perPage: config('interests.interest_search_page_size', 20),
            page: $page
        );
    }

    /**
     * Get sent interests for user
     */
    public function getSentInterests(
        User $user,
        ?string $status = null,
        int $page = 1
    ): LengthAwarePaginator {
        $query = InterestRequest::where('sender_id', $user->id)
            ->with(['receiver', 'receiverProfile', 'sender', 'senderProfile'])
            ->orderByDesc('sent_at');

        if ($status) {
            $query->where('status', $status);
        } else {
            // Exclude expired pending interests by default
            $query->where(function ($q) {
                $q->where('status', '!=', InterestRequest::STATUS_PENDING)
                    ->orWhere('expires_at', '>', now());
            });
        }

        return $query->paginate(
            perPage: config('interests.interest_search_page_size', 20),
            page: $page
        );
    }

    /**
     * Get pending interests for user (both sent and received)
     */
    public function getPendingInterests(User $user): Collection
    {
        $sentPending = InterestRequest::where('sender_id', $user->id)
            ->where('status', InterestRequest::STATUS_PENDING)
            ->where('expires_at', '>', now())
            ->with(['receiver', 'receiverProfile'])
            ->orderByDesc('sent_at')
            ->limit(5)
            ->get();

        $receivedPending = InterestRequest::where('receiver_id', $user->id)
            ->where('status', InterestRequest::STATUS_PENDING)
            ->where('expires_at', '>', now())
            ->with(['sender', 'senderProfile'])
            ->orderByDesc('sent_at')
            ->limit(5)
            ->get();

        return $sentPending->concat($receivedPending);
    }

    /**
     * Check if user is blocked
     */
    private function isBlocked(int $userId, int $blockedUserId): bool
    {
        return InterestRequest::where('status', InterestRequest::STATUS_BLOCKED)
            ->where(function ($query) use ($userId, $blockedUserId) {
                $query->where(function ($q) use ($userId, $blockedUserId) {
                    $q->where('sender_id', $userId)->where('receiver_id', $blockedUserId);
                })->orWhere(function ($q) use ($userId, $blockedUserId) {
                    $q->where('sender_id', $blockedUserId)->where('receiver_id', $userId);
                });
            })
            ->exists();
    }

    /**
     * Block user
     */
    private function blockUser(int $userId, int $blockedUserId): void
    {
        // Create a record in a blocks table or use a flag
        // For now, the status = BLOCKED on InterestRequest is used as the block mechanism
    }

    /**
     * Expire interests job
     */
    public function expireInterests(): int
    {
        $expiredCount = InterestRequest::where('status', InterestRequest::STATUS_PENDING)
            ->where('expires_at', '<', now())
            ->update([
                'status' => InterestRequest::STATUS_EXPIRED,
                'updated_at' => now(),
            ]);

        return $expiredCount;
    }
}
