<?php

declare(strict_types=1);

namespace App\Services;

use App\Events\MessageDeleted;
use App\Events\MessageEdited;
use App\Events\MessageRead;
use App\Events\MessageSent;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\User;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Collection;

class MessageService
{
    /**
     * Send a message
     */
    public function sendMessage(
        User $sender,
        Conversation $conversation,
        string $body,
        string $type = 'text',
        ?UploadedFile $media = null
    ): Message {
        // Validate sender is conversation participant
        if (! $this->isConversationParticipant($sender, $conversation)) {
            throw new \Exception('User is not a participant in this conversation.');
        }

        // Handle media upload
        $mediaUrl = null;
        $fileName = null;
        $fileSize = null;

        if ($media) {
            $uploadedMedia = $this->uploadChatMedia($media, $sender);
            $mediaUrl = $uploadedMedia['url'];
            $fileName = $uploadedMedia['file_name'];
            $fileSize = $uploadedMedia['file_size'];
        }

        // Create message
        $message = Message::create([
            'conversation_id' => $conversation->id,
            'sender_id' => $sender->id,
            'body' => $body,
            'type' => $type,
            'media_url' => $mediaUrl,
            'file_name' => $fileName,
            'file_size' => $fileSize,
            'is_edited' => false,
        ]);

        // Update conversation last message timestamp
        $conversation->update(['last_message_at' => now()]);

        // Dispatch broadcast event
        event(new MessageSent($message, $conversation));

        return $message->load('sender');
    }

    /**
     * Mark conversation as read for a user
     */
    public function markConversationAsRead(User $user, Conversation $conversation): Conversation
    {
        // Update conversation read timestamp
        if ($conversation->initiator_id === $user->id) {
            $conversation->update(['initiator_read_at' => now()]);
        } elseif ($conversation->participant_id === $user->id) {
            $conversation->update(['participant_read_at' => now()]);
        }

        // Mark all messages as read
        $conversation->messages()
            ->where('sender_id', '!=', $user->id)
            ->whereNull('read_at')
            ->update(['read_at' => now()]);

        // Dispatch broadcast event
        event(new MessageRead($conversation, $user));

        return $conversation;
    }

    /**
     * Delete a message (soft delete)
     */
    public function deleteMessage(User $user, Message $message): void
    {
        // Validate user is sender
        if ($message->sender_id !== $user->id) {
            throw new \Exception('Only the sender can delete this message.');
        }

        // Soft delete message
        $message->softDelete();

        // Dispatch broadcast event
        event(new MessageDeleted($message->id, $message->conversation));
    }

    /**
     * Edit a message
     */
    public function editMessage(User $user, Message $message, string $newBody): Message
    {
        // Validate user is sender
        if ($message->sender_id !== $user->id) {
            throw new \Exception('Only the sender can edit this message.');
        }

        // Validate within edit window
        $editWindowMinutes = config('chat.edit_window_minutes', 60);
        if ($message->created_at->addMinutes($editWindowMinutes)->isPast()) {
            throw new \Exception('Message can only be edited within '.$editWindowMinutes.' minutes.');
        }

        // Update message
        $message->update([
            'body' => $newBody,
            'is_edited' => true,
            'edited_at' => now(),
        ]);

        // Dispatch broadcast event
        event(new MessageEdited($message, $message->conversation));

        return $message;
    }

    /**
     * Get conversation messages with pagination
     */
    public function getConversationMessages(Conversation $conversation, ?int $beforeId = null, int $limit = 50): Collection
    {
        $query = $conversation->messages()
            ->visible()
            ->ordered()
            ->with('sender');

        if ($beforeId) {
            $beforeMessage = Message::find($beforeId);
            if ($beforeMessage) {
                $query->where('created_at', '<', $beforeMessage->created_at);
            }
        }

        return $query->limit($limit)->get();
    }

    /**
     * Upload chat media
     */
    public function uploadChatMedia(UploadedFile $file, User $user): array
    {
        $storagePath = 'chat-media/'.$user->id.'/'.uniqid();
        $fileName = $file->getClientOriginalName();

        // Store file
        $path = $file->storeAs($storagePath, $fileName, 'chat');

        return [
            'url' => $path,
            'file_name' => $fileName,
            'file_size' => $file->getSize(),
        ];
    }

    /**
     * Check if user is conversation participant
     */
    protected function isConversationParticipant(User $user, Conversation $conversation): bool
    {
        return $user->id === $conversation->initiator_id || $user->id === $conversation->participant_id;
    }
}
