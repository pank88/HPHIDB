<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\ProfileEducation;
use App\Models\User;
use App\Support\AuditLogger;
use Illuminate\Database\Eloquent\Collection;

class EducationService
{
    /**
     * Get all educations for a profile
     */
    public function getEducations(User $user): Collection
    {
        return ProfileEducation::where('user_id', $user->id)
            ->with('education')
            ->orderByDesc('is_highest')
            ->orderByDesc('created_at')
            ->get();
    }

    /**
     * Store education
     */
    public function storeEducation(User $user, array $data): ProfileEducation
    {
        // If marking as highest, unset others
        if ($data['is_highest'] ?? false) {
            ProfileEducation::where('user_id', $user->id)
                ->update(['is_highest' => false]);
        }

        $education = ProfileEducation::create([
            'user_id' => $user->id,
            'education_id' => $data['education_id'],
            'specialization' => $data['specialization'] ?? null,
            'institute' => $data['institute'] ?? null,
            'is_highest' => $data['is_highest'] ?? false,
        ]);

        // Ensure at least one is marked as highest
        if (! ProfileEducation::where('user_id', $user->id)
            ->where('is_highest', true)
            ->exists()) {
            $education->update(['is_highest' => true]);
        }

        AuditLogger::log($user, $education, 'education.created', $education->toArray());

        return $education;
    }

    /**
     * Update education
     */
    public function updateEducation(User $user, ProfileEducation $education, array $data): ProfileEducation
    {
        // Check ownership
        if ($education->user_id !== $user->id) {
            throw new \Exception('Unauthorized');
        }

        // If marking as highest, unset others
        if (($data['is_highest'] ?? false) && ! $education->is_highest) {
            ProfileEducation::where('user_id', $user->id)
                ->where('id', '!=', $education->id)
                ->update(['is_highest' => false]);
        }

        $updateData = [
            'education_id' => $data['education_id'] ?? $education->education_id,
            'specialization' => $data['specialization'] ?? $education->specialization,
            'institute' => $data['institute'] ?? $education->institute,
            'is_highest' => $data['is_highest'] ?? $education->is_highest,
        ];

        $education->update($updateData);

        AuditLogger::log($user, $education, 'education.updated', $updateData);

        return $education;
    }

    /**
     * Delete education
     */
    public function deleteEducation(User $user, ProfileEducation $education): bool
    {
        if ($education->user_id !== $user->id) {
            throw new \Exception('Unauthorized');
        }

        $wasHighest = $education->is_highest;

        AuditLogger::log($user, $education, 'education.deleted');

        $education->delete();

        // If was highest, mark another as highest
        if ($wasHighest) {
            $nextEducation = ProfileEducation::where('user_id', $user->id)
                ->orderByDesc('created_at')
                ->first();

            if ($nextEducation) {
                $nextEducation->update(['is_highest' => true]);
            }
        }

        return true;
    }

    /**
     * Set education as highest
     */
    public function setHighest(User $user, ProfileEducation $education): ProfileEducation
    {
        if ($education->user_id !== $user->id) {
            throw new \Exception('Unauthorized');
        }

        ProfileEducation::where('user_id', $user->id)
            ->update(['is_highest' => false]);

        $education->update(['is_highest' => true]);

        AuditLogger::log($user, $education, 'education.set_as_highest');

        return $education;
    }

    /**
     * Get highest education
     */
    public function getHighestEducation(User $user): ?ProfileEducation
    {
        return ProfileEducation::where('user_id', $user->id)
            ->where('is_highest', true)
            ->with('education')
            ->first();
    }
}
