<?php

declare(strict_types=1);

namespace App\Services\Admin;

use App\Constants\BookingStatus;
use App\Constants\ModerationStatus;
use App\Constants\UserStatus;
use App\Constants\VendorStatus;
use App\Models\AuditLog;
use App\Models\Booking;
use App\Models\InterestRequest;
use App\Models\Message;
use App\Models\Profile;
use App\Models\User;
use App\Models\UserMatch;
use App\Models\Vendor;
use Illuminate\Support\Facades\Cache;

class AdminDashboardService
{
    public const CACHE_KEY = 'admin.dashboard.stats';

    public const CACHE_TTL_SECONDS = 900; // 15 minutes

    public function stats(): array
    {
        return Cache::remember(self::CACHE_KEY, self::CACHE_TTL_SECONDS, function (): array {
            $usersByStatus = User::query()
                ->selectRaw('status, COUNT(*) as total')
                ->groupBy('status')
                ->pluck('total', 'status');

            $profilesByModeration = Profile::query()
                ->selectRaw('moderation_status, COUNT(*) as total')
                ->groupBy('moderation_status')
                ->pluck('total', 'moderation_status');

            $vendorsByStatus = Vendor::query()
                ->selectRaw('status, COUNT(*) as total')
                ->groupBy('status')
                ->pluck('total', 'status');

            $bookingsByStatus = Booking::query()
                ->selectRaw('status, COUNT(*) as total')
                ->groupBy('status')
                ->pluck('total', 'status');

            return [
                'users' => [
                    'total' => (int) $usersByStatus->sum(),
                    'by_status' => collect(UserStatus::values())->mapWithKeys(
                        fn (int $status): array => [
                            strtolower(UserStatus::label($status)) => (int) ($usersByStatus[$status] ?? 0),
                        ]
                    )->all(),
                ],
                'profiles' => [
                    'total' => (int) $profilesByModeration->sum(),
                    'by_moderation_status' => collect(ModerationStatus::values())->mapWithKeys(
                        fn (int $status): array => [
                            strtolower(ModerationStatus::label($status)) => (int) ($profilesByModeration[$status] ?? 0),
                        ]
                    )->all(),
                ],
                'vendors' => [
                    'total' => (int) $vendorsByStatus->sum(),
                    'by_status' => collect(VendorStatus::values())->mapWithKeys(
                        fn (int $status): array => [
                            strtolower(VendorStatus::label($status)) => (int) ($vendorsByStatus[$status] ?? 0),
                        ]
                    )->all(),
                ],
                'bookings' => [
                    'total' => (int) $bookingsByStatus->sum(),
                    'by_status' => collect(BookingStatus::values())->mapWithKeys(
                        fn (int $status): array => [
                            strtolower(BookingStatus::label($status)) => (int) ($bookingsByStatus[$status] ?? 0),
                        ]
                    )->all(),
                ],
                'interests' => InterestRequest::query()->count(),
                'matches' => UserMatch::query()->count(),
                'messages_today' => Message::query()
                    ->whereDate('created_at', now()->toDateString())
                    ->count(),
                'revenue_this_month' => (float) Booking::query()
                    ->where('status', BookingStatus::COMPLETED)
                    ->whereBetween('updated_at', [now()->startOfMonth(), now()->endOfMonth()])
                    ->sum('final_amount'),
                'generated_at' => now()->toIso8601String(),
            ];
        });
    }

    /**
     * Latest audit log entries with their actor.
     */
    public function recentActivity(int $limit = 20)
    {
        return AuditLog::query()
            ->with('user:id,name,email')
            ->latest('id')
            ->limit($limit)
            ->get();
    }

    public static function clearCache(): void
    {
        Cache::forget(self::CACHE_KEY);
    }
}
