<?php

declare(strict_types=1);

namespace App\Services\Admin;

use App\Constants\ModerationStatus;
use App\Constants\UserStatus;
use App\Constants\VendorStatus;
use App\Models\AuditLog;
use App\Models\NotificationLog;
use App\Models\Profile;
use App\Models\ProfilePhoto;
use App\Models\User;
use App\Models\Vendor;
use App\Models\VendorTestimonial;
use Illuminate\Support\Facades\Cache;

class ModerationService
{
    /**
     * Write an audit log entry for an admin action.
     */
    public function audit(
        User $actor,
        string $action,
        object $target,
        array $oldValues = [],
        array $newValues = [],
        ?string $description = null
    ): AuditLog {
        return AuditLog::create([
            'user_id' => $actor->id,
            'action' => $action,
            'entity_type' => class_basename($target),
            'entity_id' => $target->id ?? null,
            'model_type' => get_class($target),
            'model_id' => $target->id ?? null,
            'old_values' => $oldValues,
            'new_values' => $newValues,
            'ip_address' => request()->ip(),
            'user_agent' => (string) request()->userAgent(),
            'description' => $description,
        ]);
    }

    public function activateUser(User $admin, User $user): User
    {
        $old = ['status' => $user->status, 'suspension_reason' => $user->suspension_reason];

        $user->update([
            'status' => UserStatus::ACTIVE,
            'suspended_at' => null,
            'suspension_reason' => null,
        ]);

        $this->audit($admin, 'user.activate', $user, $old, ['status' => UserStatus::ACTIVE]);

        return $user;
    }

    public function suspendUser(User $admin, User $user, string $reason): User
    {
        $old = ['status' => $user->status];

        $user->update([
            'status' => UserStatus::SUSPENDED,
            'suspended_at' => now(),
            'suspension_reason' => $reason,
        ]);

        // Revoke all Sanctum tokens so the user is logged out everywhere
        $user->tokens()->delete();

        $this->audit($admin, 'user.suspend', $user, $old, [
            'status' => UserStatus::SUSPENDED,
            'suspension_reason' => $reason,
        ], $reason);

        return $user;
    }

    public function deleteUser(User $admin, User $user): void
    {
        $this->audit($admin, 'user.delete', $user, ['status' => $user->status], []);

        $user->tokens()->delete();
        $user->profiles()->delete();
        $user->delete();
    }

    public function approveProfile(User $admin, Profile $profile): Profile
    {
        $old = ['moderation_status' => $profile->moderation_status];

        $profile->update([
            'moderation_status' => ModerationStatus::APPROVED,
            'moderated_at' => now(),
            'moderated_by' => $admin->id,
            'rejection_reason' => null,
        ]);

        $this->audit($admin, 'profile.approve', $profile, $old, [
            'moderation_status' => ModerationStatus::APPROVED,
        ]);

        return $profile;
    }

    public function rejectProfile(User $admin, Profile $profile, string $reason): Profile
    {
        $old = ['moderation_status' => $profile->moderation_status];

        $profile->update([
            'moderation_status' => ModerationStatus::REJECTED,
            'moderated_at' => now(),
            'moderated_by' => $admin->id,
            'rejection_reason' => $reason,
        ]);

        $this->audit($admin, 'profile.reject', $profile, $old, [
            'moderation_status' => ModerationStatus::REJECTED,
            'rejection_reason' => $reason,
        ], $reason);

        $this->notifyUser(
            (int) $profile->user_id,
            'profile_rejected',
            'Profile Rejected',
            'Your profile was rejected by moderation. Reason: '.$reason
        );

        return $profile;
    }

    public function approvePhoto(User $admin, ProfilePhoto $photo): ProfilePhoto
    {
        $old = ['is_verified' => $photo->is_verified];

        $photo->update([
            'is_verified' => true,
            'verification_date' => now(),
            'is_active' => true,
        ]);

        $this->audit($admin, 'photo.approve', $photo, $old, ['is_verified' => true]);

        return $photo;
    }

    public function rejectPhoto(User $admin, ProfilePhoto $photo, string $reason): ProfilePhoto
    {
        $old = ['is_verified' => $photo->is_verified, 'is_active' => $photo->is_active];

        $photo->update([
            'is_verified' => false,
            'is_active' => false,
        ]);

        $this->audit($admin, 'photo.reject', $photo, $old, [
            'is_verified' => false,
            'is_active' => false,
        ], $reason);

        $photo->loadMissing('profile');

        if ($photo->profile !== null) {
            $this->notifyUser(
                (int) $photo->profile->user_id,
                'photo_rejected',
                'Photo Rejected',
                'One of your profile photos was rejected. Reason: '.$reason
            );
        }

        return $photo;
    }

    public function verifyVendor(User $admin, Vendor $vendor): Vendor
    {
        $old = ['is_verified' => $vendor->is_verified, 'status' => $vendor->status];

        $vendor->update([
            'is_verified' => true,
            'verified_at' => now(),
            'status' => VendorStatus::APPROVED,
        ]);

        $this->audit($admin, 'vendor.verify', $vendor, $old, [
            'is_verified' => true,
            'status' => VendorStatus::APPROVED,
        ]);

        return $vendor;
    }

    public function suspendVendor(User $admin, Vendor $vendor, string $reason): Vendor
    {
        $old = ['status' => $vendor->status];

        $vendor->update([
            'status' => VendorStatus::SUSPENDED,
        ]);

        $this->audit($admin, 'vendor.suspend', $vendor, $old, [
            'status' => VendorStatus::SUSPENDED,
        ], $reason);

        return $vendor;
    }

    public function approveTestimonial(User $admin, VendorTestimonial $testimonial): VendorTestimonial
    {
        $old = ['is_approved' => $testimonial->is_approved];

        $testimonial->update([
            'is_approved' => true,
            'approved_at' => now(),
        ]);

        $this->audit($admin, 'testimonial.approve', $testimonial, $old, ['is_approved' => true]);

        return $testimonial;
    }

    public function rejectTestimonial(User $admin, VendorTestimonial $testimonial, string $reason): VendorTestimonial
    {
        $old = ['is_approved' => $testimonial->is_approved];

        $testimonial->update([
            'is_approved' => false,
            'approved_at' => null,
        ]);

        $this->audit($admin, 'testimonial.reject', $testimonial, $old, ['is_approved' => false], $reason);

        return $testimonial;
    }

    /**
     * Record an in-app notification for a user.
     */
    private function notifyUser(int $userId, string $type, string $title, string $body): void
    {
        try {
            NotificationLog::create([
                'user_id' => $userId,
                'notification_type' => $type,
                'subject' => $title,
                'message' => $body,
                'data' => [],
                'channel' => 'in_app',
                'sent_at' => now(),
            ]);
        } catch (\Throwable $e) {
            // Notification is best-effort; never block moderation on it
            report($e);
        }

        Cache::forget('notifications.unread.'.$userId);
    }
}
