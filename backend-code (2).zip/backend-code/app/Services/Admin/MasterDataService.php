<?php

declare(strict_types=1);

namespace App\Services\Admin;

use App\Models\Caste;
use App\Models\City;
use App\Models\Country;
use App\Models\Education;
use App\Models\Gotra;
use App\Models\Hobby;
use App\Models\IncomeLevel;
use App\Models\Occupation;
use App\Models\Religion;
use App\Models\ServiceCategory;
use App\Models\State;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class MasterDataService
{
    /**
     * Map of type slug => model class.
     *
     * @var array<string, class-string<Model>>
     */
    private array $typeMap = [
        'religions' => Religion::class,
        'castes' => Caste::class,
        'gotras' => Gotra::class,
        'educations' => Education::class,
        'occupations' => Occupation::class,
        'hobbies' => Hobby::class,
        'countries' => Country::class,
        'states' => State::class,
        'cities' => City::class,
        'income-levels' => IncomeLevel::class,
        'service-categories' => ServiceCategory::class,
    ];

    /**
     * Display/search column per type (defaults to "name").
     *
     * @var array<string, string>
     */
    private array $nameColumnMap = [
        'income-levels' => 'label',
    ];

    /**
     * References to check before deletion: type slug => [[table, foreign_key], ...].
     *
     * @var array<string, array<int, array{0: string, 1: string}>>
     */
    private array $referenceMap = [
        'religions' => [['profiles', 'religion_id'], ['castes', 'religion_id'], ['partner_preferences', 'religion_id']],
        'castes' => [['profiles', 'caste_id'], ['partner_preferences', 'caste_id']],
        'gotras' => [['profiles', 'gotra_id']],
        'educations' => [['profiles', 'education_id'], ['profile_educations', 'education_id']],
        'occupations' => [['profiles', 'occupation_id']],
        'hobbies' => [['profile_hobbies', 'hobby_id']],
        'countries' => [['states', 'country_id']],
        'states' => [['cities', 'state_id'], ['profiles', 'state_id']],
        'cities' => [['profiles', 'city_id'], ['vendors', 'city_id']],
        'income-levels' => [['profiles', 'income_level_id']],
        'service-categories' => [['vendors', 'service_category_id']],
    ];

    public function isValidType(string $type): bool
    {
        return isset($this->typeMap[$type]);
    }

    /**
     * @return class-string<Model>
     */
    public function modelClass(string $type): string
    {
        if (! $this->isValidType($type)) {
            throw new NotFoundHttpException('Unknown master data type: '.$type);
        }

        return $this->typeMap[$type];
    }

    public function tableName(string $type): string
    {
        $class = $this->modelClass($type);

        return (new $class)->getTable();
    }

    public function nameColumn(string $type): string
    {
        return $this->nameColumnMap[$type] ?? 'name';
    }

    public function list(string $type, ?string $search = null, int $perPage = 25): LengthAwarePaginator
    {
        $class = $this->modelClass($type);
        $nameColumn = $this->nameColumn($type);

        return $class::query()
            ->when($search !== null && $search !== '', function ($query) use ($search, $nameColumn) {
                $query->where($nameColumn, 'like', '%'.$search.'%');
            })
            ->orderBy($nameColumn)
            ->paginate($perPage);
    }

    public function create(string $type, array $data): Model
    {
        $class = $this->modelClass($type);

        $model = $class::create($this->filterFillable($class, $data));

        $this->clearCaches($type);

        return $model;
    }

    public function update(string $type, int $id, array $data): Model
    {
        $class = $this->modelClass($type);

        /** @var Model $model */
        $model = $class::query()->findOrFail($id);
        $model->update($this->filterFillable($class, $data));

        $this->clearCaches($type);

        return $model;
    }

    /**
     * Delete a master record, returning the number of blocking references (0 = deleted).
     */
    public function delete(string $type, int $id): int
    {
        $class = $this->modelClass($type);

        /** @var Model $model */
        $model = $class::query()->findOrFail($id);

        $references = $this->referenceCount($type, $id);

        if ($references > 0) {
            return $references;
        }

        $model->delete();

        $this->clearCaches($type);

        return 0;
    }

    public function referenceCount(string $type, int $id): int
    {
        $total = 0;

        foreach ($this->referenceMap[$type] ?? [] as [$table, $foreignKey]) {
            $total += (int) DB::table($table)->where($foreignKey, $id)->count();
        }

        return $total;
    }

    /**
     * @param  class-string<Model>  $class
     */
    private function filterFillable(string $class, array $data): array
    {
        $fillable = (new $class)->getFillable();

        return array_intersect_key($data, array_flip($fillable));
    }

    private function clearCaches(string $type): void
    {
        Cache::forget('masters.'.$type);
        Cache::forget('masters.all');
        Cache::forget('masters.coded-lists');
    }
}
