<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Profile;
use App\Models\User;

class MatchingService
{
    /**
     * Calculate compatibility score between viewer and candidate profile
     *
     * @return float Compatibility score 0-100
     */
    public function calculateCompatibility(User $viewer, Profile $candidate): float
    {
        $viewerProfile = $viewer->profiles()->first();
        if (! $viewerProfile || ! $candidate->user) {
            return 0.0;
        }

        $factors = $this->calculateDetailedBreakdown($viewer, $candidate);

        // Sum all weighted scores
        $totalScore = 0;
        foreach ($factors as $factor) {
            $totalScore += $factor['weighted_score'];
        }

        return min(100.0, max(0.0, $totalScore));
    }

    /**
     * Calculate detailed compatibility breakdown
     *
     * @return array Array of factors with score, weight, and message
     */
    public function calculateDetailedBreakdown(User $viewer, Profile $candidate): array
    {
        $viewerProfile = $viewer->profiles()->first();
        $factors = [];

        // Age compatibility (max 12 points)
        $factors['age'] = $this->scoreAge($viewerProfile, $candidate);

        // Location proximity (max 12 points)
        $factors['location'] = $this->scoreLocation($viewerProfile, $candidate);

        // Religion match (max 10 points)
        $factors['religion'] = $this->scoreReligion($viewerProfile, $candidate);

        // Caste compatibility (max 10 points)
        $factors['caste'] = $this->scoreCaste($viewerProfile, $candidate);

        // Gotra avoidance (max 5 points or -30 if same)
        $factors['gotra'] = $this->scoreGotra($viewerProfile, $candidate);

        // Height range (max 8 points)
        $factors['height'] = $this->scoreHeight($viewerProfile, $candidate);

        // Complexion preference (max 5 points)
        $factors['complexion'] = $this->scoreComplexion($viewerProfile, $candidate);

        // Food type compatibility (max 5 points)
        $factors['food_type'] = $this->scoreFoodType($viewerProfile, $candidate);

        // Education level match (max 6 points)
        $factors['education'] = $this->scoreEducation($viewerProfile, $candidate);

        // Occupation compatibility (max 5 points)
        $factors['occupation'] = $this->scoreOccupation($viewerProfile, $candidate);

        // Hobbies intersection (max 8 points)
        $factors['hobbies'] = $this->scoreHobbies($viewerProfile, $candidate);

        // Profile completeness bonus (max 5 points)
        $factors['completeness'] = $this->scoreCompleteness($candidate);

        // Photos present (max 6 points)
        $factors['photos'] = $this->scorePhotos($candidate);

        // Created recency bonus (max -5 points)
        $factors['recency'] = $this->scoreRecency($candidate);

        // Profile active status (max 3 points)
        $factors['profile_status'] = $this->scoreProfileStatus($candidate);

        return $factors;
    }

    /**
     * Score age compatibility (±5 years optimal)
     */
    private function scoreAge(?Profile $viewer, Profile $candidate): array
    {
        $maxScore = 12;
        $weight = 12;
        $score = 0;
        $message = '';

        if (! $viewer || ! $viewer->date_of_birth || ! $candidate->date_of_birth) {
            return $this->formatFactor($score, $weight, 'Age information missing');
        }

        $viewerAge = (int) abs(now()->diffInYears($viewer->date_of_birth));
        $candidateAge = (int) abs(now()->diffInYears($candidate->date_of_birth));
        $ageDiff = abs($viewerAge - $candidateAge);

        if ($ageDiff <= 2) {
            $score = $maxScore; // Perfect match
            $message = 'Perfect age match';
        } elseif ($ageDiff <= 5) {
            $score = 10; // Very good
            $message = 'Good age compatibility';
        } elseif ($ageDiff <= 10) {
            $score = 6; // Fair
            $message = 'Acceptable age difference';
        } elseif ($ageDiff <= 15) {
            $score = 2; // Poor
            $message = 'Significant age gap';
        } else {
            $score = 0; // Very poor
            $message = 'Age difference too large';
        }

        return $this->formatFactor($score, $weight, $message);
    }

    /**
     * Score location proximity
     */
    private function scoreLocation(?Profile $viewer, Profile $candidate): array
    {
        $maxScore = 12;
        $weight = 12;
        $score = 0;
        $message = '';

        if (! $viewer || ! $candidate->state_id) {
            return $this->formatFactor($score, $weight, 'Location information missing');
        }

        if ($viewer->city_id && $candidate->city_id && $viewer->city_id === $candidate->city_id) {
            $score = $maxScore; // Same city
            $message = 'Same city';
        } elseif ($viewer->state_id && $candidate->state_id && $viewer->state_id === $candidate->state_id) {
            $score = 10; // Same state
            $message = 'Same state';
        } elseif ($viewer->state_id && $candidate->state_id) {
            // Check if neighboring state (simplified - just award points)
            $score = 5; // Different state
            $message = 'Different state';
        } else {
            $score = 2;
            $message = 'Unknown location';
        }

        return $this->formatFactor($score, $weight, $message);
    }

    /**
     * Score religion match
     */
    private function scoreReligion(?Profile $viewer, Profile $candidate): array
    {
        $maxScore = 10;
        $weight = 10;
        $score = 0;
        $message = '';

        if (! $candidate->religion_id) {
            $score = 5;
            $message = 'Religion not specified';

            return $this->formatFactor($score, $weight, $message);
        }

        // Check preferences
        $preferences = $viewer?->partnerPreference;
        if ($preferences && $preferences->religion_id) {
            if ($preferences->religion_id === $candidate->religion_id) {
                $score = $maxScore; // Perfect match
                $message = 'Religion preference matched';
            } else {
                $score = 0; // Mismatch
                $message = 'Religion mismatch with preferences';
            }
        } elseif ($viewer && $viewer->religion_id && $viewer->religion_id === $candidate->religion_id) {
            $score = 8; // Same religion
            $message = 'Same religion';
        } else {
            $score = 4; // No preference set
            $message = 'Religion preference not specified';
        }

        return $this->formatFactor($score, $weight, $message);
    }

    /**
     * Score caste compatibility
     */
    private function scoreCaste(?Profile $viewer, Profile $candidate): array
    {
        $maxScore = 10;
        $weight = 10;
        $score = 0;
        $message = '';

        if (! $candidate->caste_id) {
            $score = 5;
            $message = 'Caste not specified';

            return $this->formatFactor($score, $weight, $message);
        }

        // Check preferences
        $preferences = $viewer?->partnerPreference;
        if ($preferences && $preferences->caste_id) {
            if ($preferences->caste_id === $candidate->caste_id) {
                $score = $maxScore; // Perfect match
                $message = 'Caste preference matched';
            } else {
                $score = 2; // Mismatch
                $message = 'Caste mismatch with preferences';
            }
        } elseif ($viewer && $viewer->caste_id && $viewer->caste_id === $candidate->caste_id) {
            $score = 8; // Same caste
            $message = 'Same caste';
        } else {
            $score = 4; // No preference set
            $message = 'Caste preference not specified';
        }

        return $this->formatFactor($score, $weight, $message);
    }

    /**
     * Score gotra avoidance (critical: same gotra = -30%)
     */
    private function scoreGotra(?Profile $viewer, Profile $candidate): array
    {
        $maxScore = 5;
        $weight = 5;
        $score = 0;
        $message = '';

        if (! $viewer || ! $viewer->gotra_id || ! $candidate->gotra_id) {
            $score = 5; // No gotra specified
            $message = 'Gotra not specified';

            return $this->formatFactor($score, $weight, $message);
        }

        if ($viewer->gotra_id === $candidate->gotra_id) {
            $score = -30; // Critical mismatch
            $message = 'Same gotra - avoided in Hindu traditions';
        } else {
            $score = 5; // Good
            $message = 'Different gotra';
        }

        return $this->formatFactor($score, $weight, $message);
    }

    /**
     * Score height range compatibility
     */
    private function scoreHeight(?Profile $viewer, Profile $candidate): array
    {
        $maxScore = 8;
        $weight = 8;
        $score = 0;
        $message = '';

        if (! $viewer || ! $candidate->height) {
            return $this->formatFactor($score, $weight, 'Height information missing');
        }

        $preferences = $viewer->partnerPreference;
        if (! $preferences || ! $preferences->height_from || ! $preferences->height_to) {
            $score = 5; // No preference set
            $message = 'Height preference not specified';

            return $this->formatFactor($score, $weight, $message);
        }

        $heightDiff = abs($candidate->height - $preferences->height_from);

        if ($candidate->height >= $preferences->height_from && $candidate->height <= $preferences->height_to) {
            $score = $maxScore; // Perfect match
            $message = 'Within height preference';
        } elseif ($heightDiff <= 5) {
            $score = 6; // Close
            $message = 'Close to height preference';
        } elseif ($heightDiff <= 10) {
            $score = 3; // Acceptable
            $message = 'Slightly outside height range';
        } else {
            $score = 0; // Too different
            $message = 'Outside height preference';
        }

        return $this->formatFactor($score, $weight, $message);
    }

    /**
     * Score complexion preference match
     */
    private function scoreComplexion(?Profile $viewer, Profile $candidate): array
    {
        $maxScore = 5;
        $weight = 5;
        $score = 0;
        $message = '';

        if (! $candidate->complexion) {
            return $this->formatFactor($score, $weight, 'Complexion not specified');
        }

        $preferences = $viewer?->partnerPreference;
        if (! $preferences || ! $preferences->body_type) {
            $score = 3;
            $message = 'Complexion preference not specified';

            return $this->formatFactor($score, $weight, $message);
        }

        if ($preferences->body_type === $candidate->complexion) {
            $score = $maxScore;
            $message = 'Matches complexion preference';
        } else {
            $score = 2;
            $message = 'Different from complexion preference';
        }

        return $this->formatFactor($score, $weight, $message);
    }

    /**
     * Score food type compatibility
     */
    private function scoreFoodType(?Profile $viewer, Profile $candidate): array
    {
        $maxScore = 5;
        $weight = 5;
        $score = 0;
        $message = '';

        if (! $candidate->food_type) {
            return $this->formatFactor($score, $weight, 'Food type not specified');
        }

        $preferences = $viewer?->partnerPreference;
        if (! $preferences || ! $preferences->dietary_preference) {
            $score = 3;
            $message = 'Food preference not specified';

            return $this->formatFactor($score, $weight, $message);
        }

        if ($preferences->dietary_preference === $candidate->food_type) {
            $score = $maxScore;
            $message = 'Food type match';
        } elseif ($preferences->dietary_preference === 'both' || $candidate->food_type === 'both') {
            $score = 3;
            $message = 'Flexible food preferences';
        } else {
            $score = 0;
            $message = 'Food type mismatch';
        }

        return $this->formatFactor($score, $weight, $message);
    }

    /**
     * Score education level match
     */
    private function scoreEducation(?Profile $viewer, Profile $candidate): array
    {
        $maxScore = 6;
        $weight = 6;
        $score = 0;
        $message = '';

        if (! $candidate->education_id) {
            return $this->formatFactor($score, $weight, 'Education not specified');
        }

        $preferences = $viewer?->partnerPreference;
        if (! $preferences || ! $preferences->education_id) {
            $score = 3;
            $message = 'Education preference not specified';

            return $this->formatFactor($score, $weight, $message);
        }

        if ($preferences->education_id === $candidate->education_id) {
            $score = $maxScore;
            $message = 'Same education level';
        } elseif (abs($preferences->education_id - $candidate->education_id) <= 1) {
            $score = 4;
            $message = 'Similar education level';
        } else {
            $score = 1;
            $message = 'Different education levels';
        }

        return $this->formatFactor($score, $weight, $message);
    }

    /**
     * Score occupation compatibility
     */
    private function scoreOccupation(?Profile $viewer, Profile $candidate): array
    {
        $maxScore = 5;
        $weight = 5;
        $score = 0;
        $message = '';

        if (! $candidate->occupation_id) {
            return $this->formatFactor($score, $weight, 'Occupation not specified');
        }

        $preferences = $viewer?->partnerPreference;
        if (! $preferences || ! $preferences->occupation_id) {
            $score = 3;
            $message = 'Occupation preference not specified';

            return $this->formatFactor($score, $weight, $message);
        }

        if ($preferences->occupation_id === $candidate->occupation_id) {
            $score = $maxScore;
            $message = 'Same occupation category';
        } else {
            $score = 2;
            $message = 'Different occupations';
        }

        return $this->formatFactor($score, $weight, $message);
    }

    /**
     * Score hobbies intersection (common hobbies: +5% each, max +25%)
     */
    private function scoreHobbies(?Profile $viewer, Profile $candidate): array
    {
        $maxScore = 8;
        $weight = 8;
        $score = 0;
        $message = '';

        if (! $viewer) {
            return $this->formatFactor($score, $weight, 'Hobbies not available');
        }

        $viewerHobbyIds = $viewer->hobbies()->pluck('hobby_id')->toArray();
        $candidateHobbyIds = $candidate->hobbies()->pluck('hobby_id')->toArray();

        if (empty($viewerHobbyIds) || empty($candidateHobbyIds)) {
            $score = 2;
            $message = 'Hobbies not fully specified';

            return $this->formatFactor($score, $weight, $message);
        }

        $commonHobbies = count(array_intersect($viewerHobbyIds, $candidateHobbyIds));
        $score = min($maxScore, $commonHobbies * 2);
        $message = $commonHobbies > 0 ? "Common hobbies: {$commonHobbies}" : 'No common hobbies';

        return $this->formatFactor($score, $weight, $message);
    }

    /**
     * Score profile completeness bonus (+5% if >80% complete)
     */
    private function scoreCompleteness(Profile $candidate): array
    {
        $maxScore = 5;
        $weight = 5;
        $score = 0;
        $message = '';

        $completeness = $candidate->profile_completion_percentage ?? 0;

        if ($completeness >= 80) {
            $score = $maxScore;
            $message = 'Profile well-completed';
        } elseif ($completeness >= 60) {
            $score = 3;
            $message = 'Profile partially complete';
        } else {
            $score = 1;
            $message = 'Profile incomplete';
        }

        return $this->formatFactor($score, $weight, $message);
    }

    /**
     * Score photos present (+6 points if 3+ verified photos)
     */
    private function scorePhotos(Profile $candidate): array
    {
        $maxScore = 6;
        $weight = 6;
        $score = 0;
        $message = '';

        $photoCount = $candidate->profilePhotos()->where('is_verified', true)->count();

        if ($photoCount >= 3) {
            $score = $maxScore;
            $message = 'Multiple verified photos';
        } elseif ($photoCount === 2) {
            $score = 4;
            $message = 'Two verified photos';
        } elseif ($photoCount === 1) {
            $score = 2;
            $message = 'One verified photo';
        } else {
            $score = 0;
            $message = 'No verified photos';
        }

        return $this->formatFactor($score, $weight, $message);
    }

    /**
     * Score profile recency bonus (-2% per month old, max -5%)
     */
    private function scoreRecency(Profile $candidate): array
    {
        $maxScore = 0; // Max positive
        $weight = 5;
        $score = 0;
        $message = '';

        if ($candidate->created_at) {
            $monthsOld = $candidate->created_at->diffInMonths(now());

            if ($monthsOld === 0) {
                $score = 3; // Just created
                $message = 'Profile recently created';
            } elseif ($monthsOld <= 3) {
                $score = 2;
                $message = 'Profile relatively new';
            } elseif ($monthsOld <= 6) {
                $score = 1;
                $message = 'Profile created recently';
            } else {
                $score = 0; // No bonus for old profiles
                $message = 'Profile somewhat old';
            }
        }

        return $this->formatFactor($score, $weight, $message);
    }

    /**
     * Score profile active status
     */
    private function scoreProfileStatus(Profile $candidate): array
    {
        $weight = 3;
        $score = 0;
        $message = '';

        if ($candidate->is_active && $candidate->is_verified) {
            $score = 3;
            $message = 'Active and verified';
        } elseif ($candidate->is_active) {
            $score = 2;
            $message = 'Active profile';
        } else {
            $score = 0;
            $message = 'Inactive profile';
        }

        return $this->formatFactor($score, $weight, $message);
    }

    /**
     * Format a scoring factor
     */
    private function formatFactor(float $score, float $weight, string $message): array
    {
        $maxPossible = abs($weight); // Weight represents max possible score
        $normalizedScore = $weight > 0 ? ($score / $maxPossible) * $weight : $score;

        return [
            'score' => $score,
            'weight' => $weight,
            'weighted_score' => $normalizedScore,
            'message' => $message,
            'percentage' => $weight > 0 ? round(($score / $maxPossible) * 100) : 0,
        ];
    }
}
