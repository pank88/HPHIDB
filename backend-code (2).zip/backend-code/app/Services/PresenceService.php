<?php

declare(strict_types=1);

namespace App\Services;

use App\Events\PresenceUpdated;
use App\Models\User;
use Illuminate\Support\Collection;

class PresenceService
{
    /**
     * Update user presence
     */
    public function updatePresence(User $user, string $status = 'online'): void
    {
        $user->update(['last_seen_at' => now()]);

        // Broadcast presence update
        event(new PresenceUpdated($user, $status));
    }

    /**
     * Get user presence status
     */
    public function getUserPresence(User $user): array
    {
        $isOnline = $user->isOnline();

        return [
            'status' => $isOnline ? 'online' : 'offline',
            'last_seen' => $user->last_seen_at,
            'is_online' => $isOnline,
        ];
    }

    /**
     * Get all online matches for a user
     */
    public function getOnlineMatches(User $user): Collection
    {
        return $user->sentMatches()
            ->orWhere('matcher_id', $user->id)
            ->whereHas('messages')
            ->with(['initiator', 'matcher'])
            ->get()
            ->filter(function ($match) use ($user) {
                $otherUser = $match->initiator_id === $user->id ? $match->matcher : $match->initiator;

                return $otherUser->isOnline();
            });
    }
}
