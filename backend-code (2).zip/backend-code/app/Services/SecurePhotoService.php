<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Photo;
use App\Models\User;
use Exception;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class SecurePhotoService
{
    private string $disk;

    private string $path;

    private bool $encryptionEnabled;

    private array $uploadLimits;

    private array $rateLimits;

    public function __construct()
    {
        $this->disk = config('photo-storage.disk', 'local');
        $this->path = config('photo-storage.path', 'profiles/photos');
        $this->encryptionEnabled = config('photo-storage.encryption.enabled', true);
        $this->uploadLimits = config('photo-storage.upload', []);
        $this->rateLimits = config('photo-storage.rate_limit', []);
    }

    /**
     * Validate photo file before upload
     */
    public function validatePhoto(UploadedFile $file): array
    {
        $errors = [];

        // Check file size
        $maxSizeMb = $this->uploadLimits['max_size_mb'] ?? 2;
        if ($file->getSize() > ($maxSizeMb * 1024 * 1024)) {
            $errors[] = "Photo must not exceed {$maxSizeMb}MB";
        }

        // Validate MIME type
        $validMimes = ['image/jpeg', 'image/png'];
        if (! in_array($file->getMimeType(), $validMimes)) {
            $errors[] = 'Photo must be JPG or PNG format';
        }

        // Validate magic bytes
        $extension = strtolower($file->getClientOriginalExtension());
        if (! $this->validateMagicBytes($file, $extension)) {
            $errors[] = 'Invalid photo file';
        }

        // Validate dimensions
        $this->validateDimensions($file, $errors);

        return $errors;
    }

    /**
     * Validate file magic bytes
     */
    private function validateMagicBytes(UploadedFile $file, string $extension): bool
    {
        $handle = fopen($file->getRealPath(), 'rb');
        if (! $handle) {
            return false;
        }

        $magic = fread($handle, 12);
        fclose($handle);

        $hexMagic = bin2hex($magic);

        $validMagics = [
            'jpg' => ['ffd8ffe0', 'ffd8ffe1', 'ffd8ffe2'],  // JPEG
            'jpeg' => ['ffd8ffe0', 'ffd8ffe1', 'ffd8ffe2'], // JPEG
            'png' => ['89504e47'],                          // PNG
        ];

        $allowed = $validMagics[$extension] ?? [];
        foreach ($allowed as $validMagic) {
            if (str_starts_with($hexMagic, $validMagic)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Validate image dimensions
     */
    private function validateDimensions(UploadedFile $file, array &$errors): void
    {
        try {
            $size = getimagesize($file->getRealPath());
            if ($size === false) {
                $errors[] = 'Unable to determine photo dimensions';

                return;
            }

            $minWidth = $this->uploadLimits['min_width_px'] ?? 200;
            $minHeight = $this->uploadLimits['min_height_px'] ?? 200;

            if ($size[0] < $minWidth || $size[1] < $minHeight) {
                $errors[] = "Photo must be at least {$minWidth}x{$minHeight}px";
            }
        } catch (Exception $e) {
            $errors[] = 'Could not validate photo dimensions';
        }
    }

    /**
     * Upload and encrypt photo
     */
    public function uploadPhoto(User $user, UploadedFile $file, bool $isPrimary = false): ?Photo
    {
        // Validate photo
        $errors = $this->validatePhoto($file);
        if (! empty($errors)) {
            throw new Exception(implode(', ', $errors));
        }

        // Check rate limit
        $uploadCount = Photo::where('user_id', $user->id)
            ->where('created_at', '>=', now()->subDay())
            ->count();

        if ($uploadCount >= ($this->rateLimits['uploads_per_day'] ?? 10)) {
            throw new Exception('Daily photo upload limit reached');
        }

        // Check profile photo limit
        $photoCount = Photo::where('user_id', $user->id)->count();
        if ($photoCount >= ($this->uploadLimits['max_per_profile'] ?? 6)) {
            throw new Exception('Maximum photos per profile reached');
        }

        try {
            // Generate unique filename
            $filename = $this->generateFilename($file);
            $storagePath = $this->path.'/'.$user->id.'/'.$filename;

            // Read file content
            $fileContent = file_get_contents($file->getRealPath());

            // Encrypt if enabled
            if ($this->encryptionEnabled) {
                $fileContent = Crypt::encrypt($fileContent);
            }

            // Store encrypted file
            Storage::disk($this->disk)->put($storagePath, $fileContent);

            // If this is primary, unset others as primary
            if ($isPrimary) {
                Photo::where('user_id', $user->id)
                    ->where('is_primary', true)
                    ->update(['is_primary' => false]);
            }

            // Create photo record
            $photo = Photo::create([
                'user_id' => $user->id,
                'filename' => $filename,
                'storage_path' => $storagePath,
                'original_name' => $file->getClientOriginalName(),
                'mime_type' => $file->getMimeType(),
                'file_size' => $file->getSize(),
                'is_primary' => $isPrimary || Photo::where('user_id', $user->id)->count() === 0,
                'is_verified' => false,
                'status' => 'pending',
                'encrypted' => $this->encryptionEnabled,
            ]);

            return $photo;
        } catch (Exception $e) {
            throw new Exception('Failed to upload photo: '.$e->getMessage());
        }
    }

    /**
     * Generate unique filename
     */
    private function generateFilename(UploadedFile $file): string
    {
        $extension = strtolower($file->getClientOriginalExtension());

        return Str::random(32).'.'.$extension;
    }

    /**
     * Get signed URL for photo view
     */
    public function getSignedUrl(Photo $photo, int $expiryMinutes = 15): string
    {
        $expiryMinutes = config('photo-storage.signed_url.expiry_minutes', $expiryMinutes);
        $token = hash_hmac(
            'sha256',
            $photo->id.'|'.now()->addMinutes($expiryMinutes)->timestamp,
            config('app.key')
        );

        return route('photos.view', [
            'photoId' => $photo->id,
            'token' => $token,
            'expires' => now()->addMinutes($expiryMinutes)->timestamp,
        ]);
    }

    /**
     * Get signed URL for thumbnail
     */
    public function getThumbUrl(Photo $photo, int $expiryMinutes = 15): string
    {
        $expiryMinutes = config('photo-storage.signed_url.expiry_minutes', $expiryMinutes);
        $token = hash_hmac(
            'sha256',
            $photo->id.'|'.now()->addMinutes($expiryMinutes)->timestamp,
            config('app.key')
        );

        return route('photos.thumb', [
            'photoId' => $photo->id,
            'token' => $token,
            'expires' => now()->addMinutes($expiryMinutes)->timestamp,
        ]);
    }

    /**
     * Verify signed URL token
     */
    public function verifySignedUrl(int $photoId, string $token, int $expires): bool
    {
        // Check expiry
        if ($expires < now()->timestamp) {
            return false;
        }

        // Verify token
        $expectedToken = hash_hmac(
            'sha256',
            $photoId.'|'.$expires,
            config('app.key')
        );

        return hash_equals($token, $expectedToken);
    }

    /**
     * Get decrypted photo content
     */
    public function getPhotoContent(Photo $photo): string
    {
        try {
            $content = Storage::disk($this->disk)->get($photo->storage_path);

            if ($photo->encrypted && $this->encryptionEnabled) {
                return Crypt::decrypt($content);
            }

            return $content;
        } catch (Exception $e) {
            throw new Exception('Failed to retrieve photo: '.$e->getMessage());
        }
    }

    /**
     * Delete photo
     */
    public function deletePhoto(Photo $photo): bool
    {
        try {
            // Delete file from storage
            Storage::disk($this->disk)->delete($photo->storage_path);

            // If was primary, set another as primary
            if ($photo->is_primary) {
                $nextPhoto = Photo::where('user_id', $photo->user_id)
                    ->where('id', '!=', $photo->id)
                    ->orderBy('created_at')
                    ->first();

                if ($nextPhoto) {
                    $nextPhoto->update(['is_primary' => true]);
                }
            }

            // Delete record
            return $photo->delete();
        } catch (Exception $e) {
            throw new Exception('Failed to delete photo: '.$e->getMessage());
        }
    }

    /**
     * Set photo as primary
     */
    public function setPrimary(Photo $photo): bool
    {
        Photo::where('user_id', $photo->user_id)
            ->where('id', '!=', $photo->id)
            ->update(['is_primary' => false]);

        return $photo->update(['is_primary' => true]);
    }
}
