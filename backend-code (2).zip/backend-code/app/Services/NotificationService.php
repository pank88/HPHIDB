<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\InterestRequest;
use App\Models\NotificationLog;
use App\Models\User;

class NotificationService
{
    /**
     * Notify interest received
     */
    public function notifyInterestReceived(User $receiver, InterestRequest $interest): void
    {
        $message = "{$interest->sender->name} has shown interest in you";

        NotificationLog::create([
            'user_id' => $receiver->id,
            'notification_type' => 'interest_received',
            'subject' => 'New Interest',
            'message' => $message,
            'data' => [
                'sender_id' => $interest->sender_id,
                'sender_name' => $interest->sender->name,
                'receiver_profile_id' => $interest->receiver_profile_id,
                'interest_id' => $interest->id,
            ],
            'channel' => 'push',
            'sent_at' => now(),
        ]);

        // TODO: Send push notification via Firebase Cloud Messaging
        // TODO: Send SMS if opted in
        // TODO: Send Email if opted in
    }

    /**
     * Notify interest accepted
     */
    public function notifyInterestAccepted(User $sender, InterestRequest $interest): void
    {
        $message = "{$interest->receiver->name} has accepted your interest!";

        NotificationLog::create([
            'user_id' => $sender->id,
            'notification_type' => 'interest_accepted',
            'subject' => 'Interest Accepted',
            'message' => $message,
            'data' => [
                'receiver_id' => $interest->receiver_id,
                'receiver_name' => $interest->receiver->name,
                'receiver_profile_id' => $interest->receiver_profile_id,
                'interest_id' => $interest->id,
            ],
            'channel' => 'push',
            'sent_at' => now(),
        ]);

        // TODO: Send push notification via Firebase Cloud Messaging
        // TODO: Send SMS if opted in
        // TODO: Send Email if opted in
    }

    /**
     * Notify interest rejected
     */
    public function notifyInterestRejected(User $sender, InterestRequest $interest): void
    {
        $message = "{$interest->receiver->name} has declined your interest";

        NotificationLog::create([
            'user_id' => $sender->id,
            'notification_type' => 'interest_rejected',
            'subject' => 'Interest Declined',
            'message' => $message,
            'data' => [
                'receiver_id' => $interest->receiver_id,
                'receiver_name' => $interest->receiver->name,
                'interest_id' => $interest->id,
            ],
            'channel' => 'push',
            'sent_at' => now(),
        ]);

        // TODO: Send push notification via Firebase Cloud Messaging
    }

    /**
     * Notify user blocked
     */
    public function notifyUserBlocked(User $sender): void
    {
        $message = "You've been blocked by this user";

        NotificationLog::create([
            'user_id' => $sender->id,
            'notification_type' => 'user_blocked',
            'subject' => 'User Blocked',
            'message' => $message,
            'data' => [],
            'channel' => 'push',
            'sent_at' => now(),
        ]);

        // TODO: Send push notification via Firebase Cloud Messaging
    }

    /**
     * Notify interest expired
     */
    public function notifyInterestExpired(User $sender, InterestRequest $interest): void
    {
        $message = "Your interest to {$interest->receiver->name} has expired after 30 days";

        NotificationLog::create([
            'user_id' => $sender->id,
            'notification_type' => 'interest_expired',
            'subject' => 'Interest Expired',
            'message' => $message,
            'data' => [
                'receiver_id' => $interest->receiver_id,
                'receiver_name' => $interest->receiver->name,
                'interest_id' => $interest->id,
            ],
            'channel' => 'push',
            'sent_at' => now(),
        ]);

        // TODO: Send push notification via Firebase Cloud Messaging
    }
}
