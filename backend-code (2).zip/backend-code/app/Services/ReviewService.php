<?php

declare(strict_types=1);

namespace App\Services;

use App\Events\ReviewCreated;
use App\Events\ReviewResponded;
use App\Exceptions\ReviewException;
use App\Models\Booking;
use App\Models\Review;
use App\Models\User;
use App\Models\Vendor;
use Illuminate\Pagination\LengthAwarePaginator;

class ReviewService
{
    public function createReview(User $reviewer, Booking $booking, array $data): Review
    {
        if ($booking->user_id !== $reviewer->id) {
            throw ReviewException::userNotBooker();
        }

        if ($booking->status !== 'COMPLETED') {
            throw ReviewException::bookingNotCompleted();
        }

        if ($booking->review) {
            throw ReviewException::alreadyReviewed();
        }

        $review = Review::create([
            'booking_id' => $booking->id,
            'reviewer_id' => $reviewer->id,
            'vendor_id' => $booking->vendor_id,
            'rating' => $data['rating'],
            'title' => $data['title'],
            'body' => $data['body'],
            'punctuality_rating' => $data['punctuality_rating'],
            'communication_rating' => $data['communication_rating'],
            'quality_rating' => $data['quality_rating'],
            'value_rating' => $data['value_rating'],
            'verified_purchase' => true,
            'is_published' => true,
            'photos_count' => isset($data['photos']) ? count($data['photos']) : 0,
        ]);

        // Store photos if provided
        if (isset($data['photos']) && is_array($data['photos'])) {
            foreach ($data['photos'] as $photoUrl) {
                $review->reviewPhotos()->create(['photo_url' => $photoUrl]);
            }
        }

        // Update vendor rating
        $vendorService = app(VendorService::class);
        $vendorService->updateVendorRating($booking->vendor);

        event(new ReviewCreated($review));

        return $review->load('reviewer', 'reviewPhotos');
    }

    public function respondToReview(Vendor $vendor, Review $review, string $response): Review
    {
        if ($review->vendor_id !== $vendor->id) {
            throw ReviewException::vendorMismatch();
        }

        $review->update([
            'response' => $response,
            'response_at' => now(),
        ]);

        event(new ReviewResponded($review));

        return $review->fresh();
    }

    public function getVendorReviews(Vendor $vendor, ?int $rating = null, int $page = 1): LengthAwarePaginator
    {
        $query = Review::where('vendor_id', $vendor->id)
            ->where('is_published', true);

        if ($rating) {
            $query->where('rating', $rating);
        }

        return $query->with('reviewer', 'reviewPhotos')
            ->orderBy('created_at', 'desc')
            ->paginate(20, ['*'], 'page', $page);
    }
}
