<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Vendor;
use Carbon\Carbon;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;

class VendorService
{
    private const CACHE_TTL = 24 * 60; // 24 hours in minutes

    public function updateVendorRating(Vendor $vendor): Vendor
    {
        $averageRating = $vendor->calculateAverageRating();

        Cache::put("vendor.rating.{$vendor->id}", $averageRating, now()->addMinutes(self::CACHE_TTL));

        return $vendor->fresh();
    }

    public function getTopVendors(?string $category = null, int $limit = 10): Collection
    {
        $cacheKey = "top.vendors.{$category}.{$limit}";

        return Cache::remember($cacheKey, now()->addMinutes(self::CACHE_TTL), function () use ($category, $limit) {
            $query = Vendor::verified()
                ->highRated()
                ->withAverageRating();

            if ($category) {
                $query->where('service_category_id', $category);
            }

            return $query->orderBy('rating', 'desc')
                ->orderBy('total_reviews', 'desc')
                ->limit($limit)
                ->get();
        });
    }

    public function searchVendors(array $filters, int $page = 1): LengthAwarePaginator
    {
        $query = Vendor::query();

        if (isset($filters['category_id'])) {
            $query->where('service_category_id', $filters['category_id']);
        }

        if (isset($filters['city_id'])) {
            $query->where('city_id', $filters['city_id']);
        }

        if (isset($filters['rating_min'])) {
            $query->where('rating', '>=', $filters['rating_min']);
        }

        if (isset($filters['price_min']) && isset($filters['price_max'])) {
            $query->whereHas('vendorServices', function ($q) use ($filters) {
                $q->whereBetween('base_price', [$filters['price_min'], $filters['price_max']]);
            });
        }

        if (isset($filters['search'])) {
            $search = $filters['search'];
            $query->where(function ($q) use ($search) {
                $q->where('business_name', 'like', "%{$search}%")
                    ->orWhere('description', 'like', "%{$search}%");
            });
        }

        if (isset($filters['availability_date'])) {
            $query->available(Carbon::parse($filters['availability_date']));
        }

        return $query->with('vendorServices', 'reviews', 'vendorTestimonials')
            ->orderBy('rating', 'desc')
            ->paginate(20, ['*'], 'page', $page);
    }

    public function getAvailableSlots(Vendor $vendor, Carbon $date): Collection
    {
        $slots = $vendor->getAvailabilitySlots($date);

        return collect($slots);
    }
}
