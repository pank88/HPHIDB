<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\PartnerPreference;
use App\Models\User;
use App\Support\AuditLogger;

/**
 * `partner_preferences` is keyed by profile_id (not user_id), and its
 * multi-select fields are JSON-encoded text columns (preferred_castes,
 * preferred_educations, preferred_occupations, preferred_locations,
 * preferred_qualities) rather than array-typed pivot relations — this
 * service maps the API's flat *_ids naming onto those real columns.
 * `complexions`/`food_types`/`state_ids` have no dedicated columns, so
 * they're folded into `additional_preferences` as a JSON blob.
 */
class PreferenceService
{
    private function profileId(User $user): int
    {
        // Deliberately strict: a user must complete "create profile" first —
        // callers should catch ModelNotFoundException and surface a
        // "please create your profile first" message rather than paper
        // over it with a silently auto-created empty profile.
        return $user->profiles()->firstOrFail()->id;
    }

    public function getOrCreatePreferences(User $user): PartnerPreference
    {
        return PartnerPreference::firstOrCreate(
            ['profile_id' => $this->profileId($user)],
            [
                'age_from' => 18,
                'age_to' => 50,
                'height_from' => 150,
                'height_to' => 200,
            ]
        );
    }

    public function updatePreferences(User $user, array $data): PartnerPreference
    {
        $preferences = $this->getOrCreatePreferences($user);

        $updateData = [];

        if (isset($data['age_min'])) {
            $updateData['age_from'] = $data['age_min'];
        }
        if (isset($data['age_max'])) {
            $updateData['age_to'] = $data['age_max'];
        }
        if (isset($data['height_min_cm'])) {
            $updateData['height_from'] = $data['height_min_cm'];
        }
        if (isset($data['height_max_cm'])) {
            $updateData['height_to'] = $data['height_max_cm'];
        }
        if (isset($data['religion_id'])) {
            $updateData['religion_id'] = $data['religion_id'];
        }
        if (isset($data['caste_ids'])) {
            $updateData['preferred_castes'] = json_encode($data['caste_ids']);
        }
        if (isset($data['hobby_ids'])) {
            $updateData['preferred_qualities'] = json_encode($data['hobby_ids']);
        }
        if (isset($data['city_ids'])) {
            $updateData['preferred_locations'] = json_encode($data['city_ids']);
        }
        if (isset($data['education_ids'])) {
            $updateData['preferred_educations'] = json_encode($data['education_ids']);
        }
        if (isset($data['occupation_ids'])) {
            $updateData['preferred_occupations'] = json_encode($data['occupation_ids']);
        }

        // No dedicated columns for these — preserved as a JSON blob so
        // they round-trip instead of being silently dropped.
        if (array_key_exists('complexions', $data) || array_key_exists('food_types', $data) || array_key_exists('state_ids', $data)) {
            $extra = json_decode($preferences->additional_preferences ?: '{}', true) ?: [];
            if (array_key_exists('complexions', $data)) {
                $extra['complexions'] = $data['complexions'];
            }
            if (array_key_exists('food_types', $data)) {
                $extra['food_types'] = $data['food_types'];
            }
            if (array_key_exists('state_ids', $data)) {
                $extra['state_ids'] = $data['state_ids'];
            }
            $updateData['additional_preferences'] = json_encode($extra);
        }

        $preferences->update($updateData);

        AuditLogger::log($user, $preferences, 'preferences.updated', $updateData);

        return $preferences;
    }

    public function getPreferencesWithRelations(User $user): PartnerPreference
    {
        return PartnerPreference::where('profile_id', $this->profileId($user))
            ->with(['religion', 'caste', 'education', 'occupation', 'state', 'city'])
            ->firstOrFail();
    }

    public function clearPreferences(User $user): PartnerPreference
    {
        $preferences = $this->getOrCreatePreferences($user);

        $preferences->update([
            'preferred_castes' => null,
            'preferred_educations' => null,
            'preferred_occupations' => null,
            'preferred_locations' => null,
            'preferred_qualities' => null,
            'additional_preferences' => null,
        ]);

        AuditLogger::log($user, $preferences, 'preferences.cleared');

        return $preferences;
    }
}
