<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Profile;
use App\Models\User;
use App\Support\AuditLogger;

class ProfileService
{
    /**
     * Get or create user profile
     */
    public function getOrCreateProfile(User $user): Profile
    {
        return Profile::firstOrCreate(
            ['user_id' => $user->id],
            [
                'full_name' => $user->name ?? '',
                'created_for' => 'self',
                'marital_status' => 1, // MaritalStatus::NEVER_MARRIED
            ]
        );
    }

    /**
     * Store profile data
     */
    public function storeProfile(User $user, array $data): Profile
    {
        $profile = $this->getOrCreateProfile($user);

        $profileData = [
            'full_name' => $data['full_name'] ?? null,
            'gender' => $data['gender'] ?? null,
            'date_of_birth' => $data['dob'] ?? null,
            'created_for' => $data['created_for'] ?? $profile->created_for,
            'religion_id' => $data['religion_id'] ?? null,
            'caste_id' => $data['caste_id'] ?? null,
            'gotra_id' => $data['gotra_id'] ?? null,
            'occupation_id' => $data['occupation_id'] ?? null,
            'state_id' => $data['state_id'] ?? null,
            'city_id' => $data['city_id'] ?? null,
            'marital_status' => $data['marital_status'] ?? $profile->marital_status,
            'height_cm' => $data['height_cm'] ?? null,
            'complexion' => $data['complexion'] ?? null,
            'food_type' => $data['food_type'] ?? null,
            'about' => $data['about'] ?? $profile->about,
        ];

        $profile->update($profileData);

        // Mark user for re-verification if key fields changed
        $keyFields = ['full_name', 'gender', 'date_of_birth', 'religion_id', 'caste_id', 'marital_status'];
        foreach ($keyFields as $field) {
            if (isset($data[$field]) && $profile->isDirty($field)) {
                $user->update(['verification_status' => 'pending']);
                break;
            }
        }

        AuditLogger::log($user, $profile, 'profile.updated', $profileData);

        return $profile;
    }

    /**
     * Update profile data
     */
    public function updateProfile(User $user, array $data): Profile
    {
        return $this->storeProfile($user, $data);
    }

    /**
     * Calculate profile completeness percentage
     */
    public function calculateCompleteness(User $user): array
    {
        $profile = $this->getOrCreateProfile($user);
        $scores = [];
        $totalScore = 0;
        $maxScore = 100;

        // Basic profile (40%)
        $basicFields = ['full_name', 'gender', 'date_of_birth', 'religion_id', 'caste_id', 'marital_status'];
        $basicCount = 0;
        foreach ($basicFields as $field) {
            if ($profile->{$field}) {
                $basicCount++;
            }
        }
        $basicScore = ($basicCount / count($basicFields)) * 40;
        $scores['basic'] = round($basicScore);
        $totalScore += $basicScore;

        // Education (15%)
        $hasEducation = $profile->educations()->exists();
        $educationScore = $hasEducation ? 15 : 0;
        $scores['education'] = $educationScore;
        $totalScore += $educationScore;

        // Photos (15%)
        $photoCount = $profile->photos()->where('is_verified', true)->count();
        $photoScore = min(15, ($photoCount / 3) * 15);
        $scores['photos'] = round($photoScore);
        $totalScore += $photoScore;

        // Preferences (20%)
        $hasPreferences = $profile->partnerPreference()->exists();
        $preferencesScore = $hasPreferences ? 20 : 0;
        $scores['preferences'] = $preferencesScore;
        $totalScore += $preferencesScore;

        // Hobbies and About (10%)
        $hobbiesCount = $profile->hobbies()->count();
        $hasAbout = ! empty($profile->about);
        $hobbiesAboutScore = 0;

        if ($hasAbout) {
            $hobbiesAboutScore += 5;
        }
        if ($hobbiesCount > 0) {
            $hobbiesAboutScore += 5;
        }

        $scores['hobbies_about'] = $hobbiesAboutScore;
        $totalScore += $hobbiesAboutScore;

        $completeness = round(($totalScore / $maxScore) * 100);

        return [
            'overall' => min(100, $completeness),
            'breakdown' => $scores,
            'next_steps' => $this->getNextCompletionSteps($profile, $scores),
        ];
    }

    /**
     * Get next steps to improve profile
     */
    private function getNextCompletionSteps(Profile $profile, array $scores): array
    {
        $steps = [];

        if ($scores['basic'] < 40) {
            $steps[] = 'Complete basic profile information';
        }

        if ($scores['education'] === 0) {
            $steps[] = 'Add education details';
        }

        if ($scores['photos'] < 15) {
            $steps[] = 'Add verified photos (minimum 3)';
        }

        if ($scores['preferences'] === 0) {
            $steps[] = 'Set partner preferences';
        }

        if ($scores['hobbies_about'] < 10) {
            $steps[] = 'Add hobbies and about information';
        }

        return $steps;
    }

    /**
     * Get profile with all relations
     */
    public function getProfileWithRelations(User $user): Profile
    {
        return Profile::where('user_id', $user->id)
            ->with([
                'educations.education',
                'photos',
                'hobbies',
                'partnerPreference',
                'religion',
                'caste',
                'gotra',
                'occupation',
                'state',
                'city',
            ])
            ->firstOrFail();
    }
}
