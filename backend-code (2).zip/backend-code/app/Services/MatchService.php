<?php

declare(strict_types=1);

namespace App\Services;

use App\Events\ConversationStarted;
use App\Events\MatchBlocked;
use App\Events\MatchUnblocked;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\Profile;
use App\Models\User;
use App\Models\UserMatch;
use Illuminate\Pagination\LengthAwarePaginator;

class MatchService
{
    protected NotificationService $notificationService;

    public function __construct(NotificationService $notificationService)
    {
        $this->notificationService = $notificationService;
    }

    /**
     * Get matches for user
     */
    public function getMatches(User $user, bool $activeOnly = true, int $page = 1): LengthAwarePaginator
    {
        $query = UserMatch::where(function ($q) use ($user) {
            $q->where('initiator_id', $user->id)
                ->orWhere('matcher_id', $user->id);
        })
            ->with([
                'initiator',
                'matcher',
                'initiatorProfile',
                'matcherProfile',
                'messages' => function ($q) {
                    $q->latest()->first();
                },
            ])
            ->orderByDesc('connected_at');

        if ($activeOnly) {
            $query->where('is_active', true);
        }

        return $query->paginate(
            perPage: config('interests.interest_search_page_size', 20),
            page: $page
        );
    }

    /**
     * Get a specific match
     */
    public function getMatch(User $user, UserMatch $match): UserMatch
    {
        // Validate user is part of match
        if ($match->initiator_id !== $user->id && $match->matcher_id !== $user->id) {
            throw new \InvalidArgumentException('You are not part of this match');
        }

        return $match->load([
            'initiator',
            'matcher',
            'initiatorProfile',
            'matcherProfile',
            'messages' => function ($q) {
                $q->latest()->take(20);
            },
        ]);
    }

    /**
     * Start conversation (send first message)
     */
    public function startConversation(UserMatch $match, User $initiator, string $message): Message
    {
        // Validate initiator is part of match
        if ($match->initiator_id !== $initiator->id && $match->matcher_id !== $initiator->id) {
            throw new \InvalidArgumentException('You are not part of this match');
        }

        // Determine the other user
        $otherUserId = $match->initiator_id === $initiator->id ? $match->matcher_id : $match->initiator_id;

        // Get or create conversation
        $conversation = Conversation::firstOrCreate([
            'initiator_id' => min($initiator->id, $otherUserId),
            'participant_id' => max($initiator->id, $otherUserId),
            'match_id' => $match->id,
        ], [
            'is_active' => true,
        ]);

        // Create message
        $messageRecord = Message::create([
            'conversation_id' => $conversation->id,
            'match_id' => $match->id,
            'sender_id' => $initiator->id,
            'body' => $message,
            'is_read' => false,
        ]);

        // Update match last interaction
        $match->update(['last_interaction_at' => now()]);

        // Update conversation last message
        $conversation->update(['last_message_at' => now()]);

        // Fire event
        ConversationStarted::dispatch($match, $messageRecord);

        return $messageRecord->load(['sender', 'conversation']);
    }

    /**
     * Block match
     */
    public function blockMatch(UserMatch $match, User $blocker): UserMatch
    {
        // Validate blocker is part of match
        if ($match->initiator_id !== $blocker->id && $match->matcher_id !== $blocker->id) {
            throw new \InvalidArgumentException('You are not part of this match');
        }

        // Validate match is active
        if (! $match->is_active) {
            throw new \InvalidArgumentException('Match is already blocked');
        }

        // Update match
        $match->update([
            'is_active' => false,
            'blocked_by_id' => $blocker->id,
        ]);

        // Fire event
        MatchBlocked::dispatch($match);

        return $match->load(['initiator', 'matcher', 'blockedByUser']);
    }

    /**
     * Unblock match
     */
    public function unblockMatch(UserMatch $match, User $unblocker): UserMatch
    {
        // Validate unblocker blocked this match
        if ($match->blocked_by_id !== $unblocker->id) {
            throw new \InvalidArgumentException('You did not block this match');
        }

        // Update match
        $match->update([
            'is_active' => true,
            'blocked_by_id' => null,
        ]);

        // Fire event
        MatchUnblocked::dispatch($match);

        return $match->load(['initiator', 'matcher']);
    }

    /**
     * Get matched profile (the other person)
     */
    public function getMatchedProfile(UserMatch $match, User $viewer): Profile
    {
        // Validate viewer is part of match
        if ($match->initiator_id !== $viewer->id && $match->matcher_id !== $viewer->id) {
            throw new \InvalidArgumentException('You are not part of this match');
        }

        // Return the other person's profile
        if ($match->initiator_id === $viewer->id) {
            return $match->matcherProfile->load([
                'user',
                'religion',
                'caste',
                'gotra',
                'education',
                'occupation',
                'city',
                'state',
                'profileEducations.education',
                'profilePhotos',
                'hobbies',
                'partnerPreference',
            ]);
        }

        return $match->initiatorProfile->load([
            'user',
            'religion',
            'caste',
            'gotra',
            'education',
            'occupation',
            'city',
            'state',
            'profileEducations.education',
            'profilePhotos',
            'hobbies',
            'partnerPreference',
        ]);
    }
}
