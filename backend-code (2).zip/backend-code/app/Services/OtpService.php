<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Otp;
use App\Notifications\OtpNotification;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Notification;

/**
 * Central place for OTP generation, delivery, and verification.
 *
 * Delivery channels (SMS/email) are toggled independently via env so each
 * can be switched on once a real gateway is wired up. While a channel is
 * off, delivery falls back to the log (see storage/logs/laravel.log).
 *
 * `shouldExposeInResponse()` controls whether the plaintext OTP is echoed
 * back in the API response — it stays true as long as neither channel is
 * enabled, so the flow is testable end-to-end before any gateway exists.
 */
class OtpService
{
    private const LENGTH = 6;

    private const EXPIRY_MINUTES = 10;

    private const MAX_ATTEMPTS = 3;

    public function generate(string $mobile): string
    {
        $otp = str_pad((string) random_int(0, 999999), self::LENGTH, '0', STR_PAD_LEFT);

        Otp::where('mobile', $mobile)->delete();

        Otp::create([
            'mobile' => $mobile,
            'otp' => Hash::make($otp),
            'attempts' => 0,
            'expires_at' => now()->addMinutes(self::EXPIRY_MINUTES),
        ]);

        return $otp;
    }

    public function deliver(string $mobile, string $otp, ?string $email = null): void
    {
        if (config('services.otp.sms_enabled')) {
            $this->sendSms($mobile, $otp);
        } else {
            Log::info("[OTP][sms-disabled] OTP for {$mobile}: {$otp}");
        }

        if (config('services.otp.email_enabled') && $email) {
            Notification::route('mail', $email)->notify(new OtpNotification($otp));
        } elseif ($email) {
            Log::info("[OTP][email-disabled] OTP for {$email}: {$otp}");
        }
    }

    /**
     * SMS gateway plug-in point. No gateway is integrated yet — replace this
     * body with a real client (Twilio/MSG91/etc.) once SMS is enabled.
     */
    private function sendSms(string $mobile, string $otp): void
    {
        Log::info("[OTP][sms-enabled-but-no-gateway] Would send OTP {$otp} to {$mobile}");
    }

    public function shouldExposeInResponse(): bool
    {
        return ! config('services.otp.sms_enabled') && ! config('services.otp.email_enabled');
    }

    /**
     * @return array{ok: bool, message?: string, code?: int}
     */
    public function verify(string $mobile, string $code): array
    {
        $otpRecord = Otp::where('mobile', $mobile)->orderBy('created_at', 'desc')->first();

        if (! $otpRecord) {
            return ['ok' => false, 'message' => 'OTP not found. Please register again.', 'code' => 404];
        }

        if ($otpRecord->isExpired()) {
            $otpRecord->delete();

            return ['ok' => false, 'message' => 'OTP has expired. Please request a new one.', 'code' => 410];
        }

        if ($otpRecord->isMaxAttemptsExceeded(self::MAX_ATTEMPTS)) {
            $otpRecord->delete();

            return ['ok' => false, 'message' => 'Maximum OTP verification attempts exceeded. Please register again.', 'code' => 429];
        }

        if (! Hash::check($code, $otpRecord->otp)) {
            $otpRecord->increment('attempts');

            return ['ok' => false, 'message' => 'Invalid OTP provided.', 'code' => 400];
        }

        $otpRecord->delete();

        return ['ok' => true];
    }
}
