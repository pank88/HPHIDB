<?php

declare(strict_types=1);

namespace App\Constants;

class Gender
{
    public const MALE = 1;

    public const FEMALE = 2;

    public static function labels(): array
    {
        return [self::MALE => 'Male', self::FEMALE => 'Female'];
    }

    public static function label(int $value): string
    {
        return self::labels()[$value] ?? 'Unknown';
    }

    public static function values(): array
    {
        return [self::MALE, self::FEMALE];
    }
}
