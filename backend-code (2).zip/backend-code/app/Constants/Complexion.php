<?php

declare(strict_types=1);

namespace App\Constants;

class Complexion
{
    public const VERY_FAIR = 1;

    public const FAIR = 2;

    public const WHEATISH = 3;

    public const DUSKY = 4;

    public const DARK = 5;

    public static function labels(): array
    {
        return [self::VERY_FAIR => 'Very Fair', self::FAIR => 'Fair', self::WHEATISH => 'Wheatish', self::DUSKY => 'Dusky', self::DARK => 'Dark'];
    }

    public static function label(int $value): string
    {
        return self::labels()[$value] ?? 'Unknown';
    }

    public static function values(): array
    {
        return [self::VERY_FAIR, self::FAIR, self::WHEATISH, self::DUSKY, self::DARK];
    }
}
