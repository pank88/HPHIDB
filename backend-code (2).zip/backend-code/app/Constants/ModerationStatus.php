<?php

declare(strict_types=1);

namespace App\Constants;

class ModerationStatus
{
    public const PENDING = 1;

    public const APPROVED = 2;

    public const REJECTED = 3;

    public static function labels(): array
    {
        return [self::PENDING => 'Pending', self::APPROVED => 'Approved', self::REJECTED => 'Rejected'];
    }

    public static function label(int $value): string
    {
        return self::labels()[$value] ?? 'Unknown';
    }

    public static function values(): array
    {
        return [self::PENDING, self::APPROVED, self::REJECTED];
    }
}
