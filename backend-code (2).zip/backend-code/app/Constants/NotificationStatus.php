<?php

declare(strict_types=1);

namespace App\Constants;

class NotificationStatus
{
    public const QUEUED = 1;

    public const SENT = 2;

    public const FAILED = 3;

    public static function labels(): array
    {
        return [self::QUEUED => 'Queued', self::SENT => 'Sent', self::FAILED => 'Failed'];
    }

    public static function label(int $value): string
    {
        return self::labels()[$value] ?? 'Unknown';
    }

    public static function values(): array
    {
        return [self::QUEUED, self::SENT, self::FAILED];
    }
}
