<?php

declare(strict_types=1);

namespace App\Constants;

class BookingStatus
{
    public const INQUIRY = 1;

    public const CONFIRMED = 2;

    public const CANCELLED = 3;

    public const COMPLETED = 4;

    public static function labels(): array
    {
        return [self::INQUIRY => 'Inquiry', self::CONFIRMED => 'Confirmed', self::CANCELLED => 'Cancelled', self::COMPLETED => 'Completed'];
    }

    public static function label(int $value): string
    {
        return self::labels()[$value] ?? 'Unknown';
    }

    public static function values(): array
    {
        return [self::INQUIRY, self::CONFIRMED, self::CANCELLED, self::COMPLETED];
    }
}
