<?php

declare(strict_types=1);

namespace App\Constants;

class UserRole
{
    public const ADMIN = 1;

    public const USER = 2;

    public const VENDOR = 3;

    public static function labels(): array
    {
        return [
            self::ADMIN => 'Admin',
            self::USER => 'User',
            self::VENDOR => 'Vendor',
        ];
    }

    public static function label(int $value): string
    {
        return self::labels()[$value] ?? 'Unknown';
    }

    public static function values(): array
    {
        return [self::ADMIN, self::USER, self::VENDOR];
    }
}
