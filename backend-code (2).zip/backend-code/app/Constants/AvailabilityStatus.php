<?php

declare(strict_types=1);

namespace App\Constants;

class AvailabilityStatus
{
    public const AVAILABLE = 1;

    public const BOOKED = 2;

    public const BLOCKED = 3;

    public static function labels(): array
    {
        return [self::AVAILABLE => 'Available', self::BOOKED => 'Booked', self::BLOCKED => 'Blocked'];
    }

    public static function label(int $value): string
    {
        return self::labels()[$value] ?? 'Unknown';
    }

    public static function values(): array
    {
        return [self::AVAILABLE, self::BOOKED, self::BLOCKED];
    }
}
