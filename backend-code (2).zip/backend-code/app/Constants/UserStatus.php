<?php

declare(strict_types=1);

namespace App\Constants;

class UserStatus
{
    public const PENDING = 1;

    public const ACTIVE = 2;

    public const SUSPENDED = 3;

    public static function labels(): array
    {
        return [self::PENDING => 'Pending', self::ACTIVE => 'Active', self::SUSPENDED => 'Suspended'];
    }

    public static function label(int $value): string
    {
        return self::labels()[$value] ?? 'Unknown';
    }

    public static function values(): array
    {
        return [self::PENDING, self::ACTIVE, self::SUSPENDED];
    }
}
