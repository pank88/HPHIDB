<?php

declare(strict_types=1);

namespace App\Constants;

class MatchStatus
{
    public const CONFIRMED = 1;

    public const UNMATCHED = 2;

    public static function labels(): array
    {
        return [self::CONFIRMED => 'Confirmed', self::UNMATCHED => 'Unmatched'];
    }

    public static function label(int $value): string
    {
        return self::labels()[$value] ?? 'Unknown';
    }

    public static function values(): array
    {
        return [self::CONFIRMED, self::UNMATCHED];
    }
}
