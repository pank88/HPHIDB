<?php

declare(strict_types=1);

namespace App\Constants;

class EducationLevel
{
    public const HIGH_SCHOOL = 1;

    public const DIPLOMA = 2;

    public const BACHELOR = 3;

    public const MASTER = 4;

    public const DOCTORATE = 5;

    public const OTHER = 6;

    public static function labels(): array
    {
        return [self::HIGH_SCHOOL => 'High School', self::DIPLOMA => 'Diploma', self::BACHELOR => 'Bachelor', self::MASTER => 'Master', self::DOCTORATE => 'Doctorate', self::OTHER => 'Other'];
    }

    public static function label(int $value): string
    {
        return self::labels()[$value] ?? 'Unknown';
    }

    public static function values(): array
    {
        return [self::HIGH_SCHOOL, self::DIPLOMA, self::BACHELOR, self::MASTER, self::DOCTORATE, self::OTHER];
    }
}
