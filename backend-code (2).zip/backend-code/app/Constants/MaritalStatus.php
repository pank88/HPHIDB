<?php

declare(strict_types=1);

namespace App\Constants;

class MaritalStatus
{
    public const NEVER_MARRIED = 1;

    public const DIVORCED = 2;

    public const WIDOWED = 3;

    public static function labels(): array
    {
        return [self::NEVER_MARRIED => 'Never Married', self::DIVORCED => 'Divorced', self::WIDOWED => 'Widowed'];
    }

    public static function label(int $value): string
    {
        return self::labels()[$value] ?? 'Unknown';
    }

    public static function values(): array
    {
        return [self::NEVER_MARRIED, self::DIVORCED, self::WIDOWED];
    }
}
