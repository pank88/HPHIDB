<?php

declare(strict_types=1);

namespace App\Constants;

class CreatedFor
{
    public const SELF = 1;

    public const SON = 2;

    public const DAUGHTER = 3;

    public const SIBLING = 4;

    public const RELATIVE = 5;

    public static function labels(): array
    {
        return [self::SELF => 'Self', self::SON => 'Son', self::DAUGHTER => 'Daughter', self::SIBLING => 'Sibling', self::RELATIVE => 'Relative'];
    }

    public static function label(int $value): string
    {
        return self::labels()[$value] ?? 'Unknown';
    }

    public static function values(): array
    {
        return [self::SELF, self::SON, self::DAUGHTER, self::SIBLING, self::RELATIVE];
    }
}
