<?php

declare(strict_types=1);

namespace App\Constants;

class InterestChannel
{
    public const SMS = 1;

    public const EMAIL = 2;

    public static function labels(): array
    {
        return [self::SMS => 'SMS', self::EMAIL => 'Email'];
    }

    public static function label(int $value): string
    {
        return self::labels()[$value] ?? 'Unknown';
    }

    public static function values(): array
    {
        return [self::SMS, self::EMAIL];
    }
}
