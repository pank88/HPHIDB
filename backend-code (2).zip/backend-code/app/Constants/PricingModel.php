<?php

declare(strict_types=1);

namespace App\Constants;

class PricingModel
{
    public const HOURLY = 1;

    public const DAILY = 2;

    public const PACKAGE = 3;

    public static function labels(): array
    {
        return [self::HOURLY => 'Hourly', self::DAILY => 'Daily', self::PACKAGE => 'Package'];
    }

    public static function label(int $value): string
    {
        return self::labels()[$value] ?? 'Unknown';
    }

    public static function values(): array
    {
        return [self::HOURLY, self::DAILY, self::PACKAGE];
    }
}
