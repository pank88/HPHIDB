<?php

declare(strict_types=1);

namespace App\Constants;

class FoodType
{
    public const VEG = 1;

    public const NON_VEG = 2;

    public const EGGETARIAN = 3;

    public const JAIN = 4;

    public static function labels(): array
    {
        return [self::VEG => 'Vegetarian', self::NON_VEG => 'Non-Vegetarian', self::EGGETARIAN => 'Eggetarian', self::JAIN => 'Jain'];
    }

    public static function label(int $value): string
    {
        return self::labels()[$value] ?? 'Unknown';
    }

    public static function values(): array
    {
        return [self::VEG, self::NON_VEG, self::EGGETARIAN, self::JAIN];
    }
}
