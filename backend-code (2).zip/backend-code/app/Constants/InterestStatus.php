<?php

declare(strict_types=1);

namespace App\Constants;

class InterestStatus
{
    public const PENDING = 1;

    public const ACCEPTED = 2;

    public const REJECTED = 3;

    public const WITHDRAWN = 4;

    public const EXPIRED = 5;

    public static function labels(): array
    {
        return [self::PENDING => 'Pending', self::ACCEPTED => 'Accepted', self::REJECTED => 'Rejected', self::WITHDRAWN => 'Withdrawn', self::EXPIRED => 'Expired'];
    }

    public static function label(int $value): string
    {
        return self::labels()[$value] ?? 'Unknown';
    }

    public static function values(): array
    {
        return [self::PENDING, self::ACCEPTED, self::REJECTED, self::WITHDRAWN, self::EXPIRED];
    }
}
