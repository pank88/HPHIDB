<?php

declare(strict_types=1);

namespace App\Events;

use App\Models\Conversation;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class MessageDeleted implements ShouldBroadcast
{
    use Dispatchable, SerializesModels;

    public int $messageId;

    public Conversation $conversation;

    public function __construct(int $messageId, Conversation $conversation)
    {
        $this->messageId = $messageId;
        $this->conversation = $conversation;
    }

    public function broadcastOn(): Channel
    {
        return new PrivateChannel("conversation.{$this->conversation->id}");
    }

    public function broadcastAs(): string
    {
        return 'message-deleted';
    }

    public function broadcastWith(): array
    {
        return [
            'id' => $this->messageId,
        ];
    }
}
