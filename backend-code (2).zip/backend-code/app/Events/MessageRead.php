<?php

declare(strict_types=1);

namespace App\Events;

use App\Models\Conversation;
use App\Models\User;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class MessageRead implements ShouldBroadcast
{
    use Dispatchable, SerializesModels;

    public Conversation $conversation;

    public User $user;

    public ?\DateTime $readAt;

    public function __construct(Conversation $conversation, User $user, ?\DateTime $readAt = null)
    {
        $this->conversation = $conversation;
        $this->user = $user;
        $this->readAt = $readAt ?? now();
    }

    public function broadcastOn(): Channel
    {
        return new PrivateChannel("conversation.{$this->conversation->id}");
    }

    public function broadcastAs(): string
    {
        return 'message-read';
    }

    public function broadcastWith(): array
    {
        return [
            'user_id' => $this->user->id,
            'read_at' => $this->readAt,
        ];
    }
}
