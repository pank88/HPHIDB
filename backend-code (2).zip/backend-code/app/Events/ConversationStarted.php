<?php

declare(strict_types=1);

namespace App\Events;

use App\Models\Message;
use App\Models\UserMatch;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class ConversationStarted
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public function __construct(public UserMatch $match, public Message $message) {}
}
