<?php

declare(strict_types=1);

namespace App\Events;

use App\Models\User;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class PresenceUpdated implements ShouldBroadcast
{
    use Dispatchable, SerializesModels;

    public User $user;

    public string $status;

    public function __construct(User $user, string $status = 'online')
    {
        $this->user = $user;
        $this->status = $status;
    }

    public function broadcastOn(): Channel
    {
        return new PresenceChannel("users.{$this->user->id}");
    }

    public function broadcastAs(): string
    {
        return 'presence-updated';
    }

    public function broadcastWith(): array
    {
        return [
            'user_id' => $this->user->id,
            'status' => $this->status,
            'last_seen' => now(),
        ];
    }
}
