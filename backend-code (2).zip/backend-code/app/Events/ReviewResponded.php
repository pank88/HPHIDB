<?php

declare(strict_types=1);

namespace App\Events;

use App\Models\Review;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class ReviewResponded
{
    use Dispatchable, SerializesModels;

    public function __construct(public Review $review) {}

    public function broadcastOn(): array
    {
        return [
            new PrivateChannel('user.'.$this->review->reviewer_id),
        ];
    }
}
