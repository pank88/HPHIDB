<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Models\InterestRequest;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class InterestResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'status' => $this->status,
            'message' => $this->message,
            'channel' => $this->channel,
            'sent_at' => $this->sent_at?->toIso8601String(),
            'responded_at' => $this->responded_at?->toIso8601String(),
            'expires_at' => $this->expires_at?->toIso8601String(),
            'sender' => new UserResource($this->whenLoaded('sender')),
            'receiver' => new UserResource($this->whenLoaded('receiver')),
            'sender_profile' => new ProfileResource($this->whenLoaded('senderProfile')),
            'receiver_profile' => new ProfileResource($this->whenLoaded('receiverProfile')),
            'can_accept' => $this->canAccept(),
            'can_reject' => $this->canReject(),
            'can_block' => $this->canBlock(),
            'days_until_expiry' => $this->daysUntilExpiry(),
        ];
    }

    private function canAccept(): bool
    {
        return $this->status === InterestRequest::STATUS_PENDING
            && $this->expires_at > now();
    }

    private function canReject(): bool
    {
        return $this->status === InterestRequest::STATUS_PENDING
            && $this->expires_at > now();
    }

    private function canBlock(): bool
    {
        return $this->status === InterestRequest::STATUS_PENDING
            && $this->expires_at > now();
    }

    private function daysUntilExpiry(): ?int
    {
        if (! $this->expires_at) {
            return null;
        }

        $diff = (int) floor(now()->diffInDays($this->expires_at));

        return $diff >= 0 ? $diff : 0;
    }
}
