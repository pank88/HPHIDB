<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class VendorImageResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'image_url' => $this->image_url,
            'caption' => $this->caption,
            'is_primary' => $this->is_primary,
            'display_order' => $this->display_order,
            'created_at' => $this->created_at?->toIso8601String(),
        ];
    }
}
