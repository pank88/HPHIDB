<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MatchResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'initiator' => new UserResource($this->whenLoaded('initiator')),
            'matcher' => new UserResource($this->whenLoaded('matcher')),
            'initiator_profile' => new ProfileResource($this->whenLoaded('initiatorProfile')),
            'matcher_profile' => new ProfileResource($this->whenLoaded('matcherProfile')),
            'matched_profile' => $this->getMatchedProfile(),
            'connected_at' => $this->connected_at?->toIso8601String(),
            'last_interaction_at' => $this->last_interaction_at?->toIso8601String(),
            'is_active' => $this->is_active,
            'blocked_by' => $this->blocked_by_id ? $this->blockedByUser->name : null,
            'message_count' => $this->messages_count ?? $this->messages()->count(),
            'latest_message' => new MessageResource($this->whenLoaded('messages', function () {
                return $this->messages()->latest()->first();
            })),
            'can_block' => $this->is_active,
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }

    private function getMatchedProfile(): ?ProfileResource
    {
        $request = request();
        $viewer = auth()->user();

        if (! $viewer || ! $this->relationLoaded('initiatorProfile')) {
            return null;
        }

        if ($this->initiator_id === $viewer->id) {
            return new ProfileResource($this->whenLoaded('matcherProfile'));
        }

        return new ProfileResource($this->whenLoaded('initiatorProfile'));
    }
}
