<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserMinimalResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'email' => $this->email,
            'avatar' => $this->profiles?->first()?->photos?->first()?->photo_url,
            'is_online' => $this->isOnline(),
            'last_seen_at' => $this->last_seen_at,
        ];
    }
}
