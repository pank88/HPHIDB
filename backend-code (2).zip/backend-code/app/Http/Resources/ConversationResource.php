<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ConversationResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $currentUser = $request->user();
        $otherUser = $this->getOtherUser($currentUser);
        $lastMessage = $this->messages()->visible()->latest()->first();

        return [
            'id' => $this->id,
            'match_id' => $this->match_id,
            'last_message_at' => $this->last_message_at,
            'created_at' => $this->created_at,
            'match_data' => new MatchResource($this->match),
            'other_user' => new UserMinimalResource($otherUser),
            'last_message' => $lastMessage ? new MessageResource($lastMessage) : null,
            'unread_count' => $currentUser ? $this->getUnreadCount($currentUser) : 0,
            'is_online' => $otherUser ? $otherUser->isOnline() : false,
            'last_seen' => $otherUser?->last_seen_at,
        ];
    }
}
