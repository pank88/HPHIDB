<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class VendorServiceResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'description' => $this->description,
            'base_price' => (float) $this->base_price,
            'price_label' => $this->price_label,
            'price_unit' => $this->price_unit,
            'duration_hours' => $this->duration_hours,
            'max_guests_count' => $this->max_guests_count,
            'features' => [
                'includes_travel' => $this->includes_travel ?? false,
                'includes_decoration' => $this->includes_decoration ?? false,
                'includes_makeup' => $this->includes_makeup ?? false,
                'includes_videography' => $this->includes_videography ?? false,
                'includes_album' => $this->includes_album ?? false,
            ],
            'bookings_count' => $this->bookings_count ?? 0,
            'average_delivery_time' => $this->average_delivery_time ?? null,
            'is_active' => $this->is_active,
        ];
    }
}
