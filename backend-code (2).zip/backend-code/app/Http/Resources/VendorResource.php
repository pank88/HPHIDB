<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class VendorResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $reviews = $this->reviews()->with('reviewPhotos')->where('is_published', true)->latest()->limit(5)->get();
        $ratingCounts = $this->reviews()
            ->where('is_published', true)
            ->groupBy('rating')
            ->selectRaw('rating, count(*) as count')
            ->pluck('count', 'rating')
            ->toArray();

        return [
            'id' => $this->id,
            'name' => $this->business_name,
            'owner_name' => $this->owner_name,
            'bio' => $this->bio ?? $this->description,
            'rating' => (float) ($this->rating ?? 0),
            'total_reviews' => $this->total_reviews ?? 0,
            'is_verified' => $this->is_verified,
            'verified_at' => $this->verified_at?->toDateTimeString(),
            'response_time_hours' => $this->response_time_hours ?? 0,
            'years_of_experience' => $this->years_of_experience ?? 0,
            'contact' => [
                'email' => $this->email,
                'phone' => $this->phone,
                'alt_phone' => $this->alt_phone,
                'website' => $this->website,
            ],
            'location' => [
                'address' => $this->business_address,
                'city' => $this->city->name ?? null,
                'city_id' => $this->city_id,
                'postal_code' => $this->postal_code,
            ],
            'service_category_id' => $this->service_category_id,
            'services' => VendorServiceResource::collection($this->vendorServices()->active()->get()),
            'gallery' => VendorImageResource::collection($this->vendorImages()->orderBy('display_order')->get()),
            'reviews' => ReviewResource::collection($reviews),
            'testimonials' => VendorTestimonialResource::collection($this->vendorTestimonials()->where('is_approved', true)->limit(5)->get()),
            'ratings_breakdown' => [
                'five_star_count' => $ratingCounts[5] ?? 0,
                'four_star_count' => $ratingCounts[4] ?? 0,
                'three_star_count' => $ratingCounts[3] ?? 0,
                'two_star_count' => $ratingCounts[2] ?? 0,
                'one_star_count' => $ratingCounts[1] ?? 0,
            ],
            'average_booking_price' => $this->vendorServices()
                ->active()
                ->avg('base_price') ?? 0,
            'logo_url' => $this->logo_path ? Storage::disk('public')->url($this->logo_path) : null,
            'created_at' => $this->created_at?->toDateTimeString(),
        ];
    }
}
