<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ReviewResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'rating' => $this->rating,
            'title' => $this->title,
            'body' => $this->body,
            'reviewer' => new UserCompactResource($this->reviewer ?? $this->user),
            'vendor' => new VendorCompactResource($this->vendor),
            'ratings' => [
                'punctuality' => $this->punctuality_rating,
                'communication' => $this->communication_rating,
                'quality' => $this->quality_rating,
                'value' => $this->value_rating,
            ],
            'photos' => $this->reviewPhotos->pluck('photo_url')->toArray(),
            'helpful_count' => $this->helpful_count,
            'is_helpful_by_viewer' => $request->user() ? $this->reviewHelpful()->where('user_id', $request->user()->id)->exists() : false,
            'vendor_response' => $this->response,
            'response_at' => $this->response_at?->toDateTimeString(),
            'verified_purchase' => $this->verified_purchase,
            'is_published' => $this->is_published,
            'created_at' => $this->created_at?->toDateTimeString(),
        ];
    }
}
