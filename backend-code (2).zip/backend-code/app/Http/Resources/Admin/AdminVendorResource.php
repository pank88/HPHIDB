<?php

declare(strict_types=1);

namespace App\Http\Resources\Admin;

use App\Constants\VendorStatus;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AdminVendorResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'business_name' => $this->business_name,
            'owner_name' => $this->owner_name,
            'email' => $this->email,
            'phone' => $this->phone,
            'status' => $this->status,
            'status_label' => VendorStatus::label((int) $this->status),
            'is_verified' => (bool) $this->is_verified,
            'verified_at' => $this->verified_at,
            'rating' => $this->rating,
            'service_category' => $this->whenLoaded('serviceCategory', fn () => [
                'id' => $this->serviceCategory?->id,
                'name' => $this->serviceCategory?->name,
            ]),
            'counts' => [
                'bookings' => $this->whenCounted('bookings'),
                'reviews' => $this->whenCounted('reviews'),
            ],
            'created_at' => $this->created_at,
        ];
    }
}
