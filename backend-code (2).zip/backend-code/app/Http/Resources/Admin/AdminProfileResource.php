<?php

declare(strict_types=1);

namespace App\Http\Resources\Admin;

use App\Constants\ModerationStatus;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AdminProfileResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'gender' => $this->gender,
            'date_of_birth' => $this->date_of_birth,
            'bio' => $this->bio,
            'is_active' => $this->is_active,
            'is_verified' => $this->is_verified,
            'profile_completion_percentage' => $this->profile_completion_percentage,
            'moderation' => [
                'status' => $this->moderation_status,
                'status_label' => ModerationStatus::label((int) ($this->moderation_status ?? ModerationStatus::PENDING)),
                'moderated_at' => $this->moderated_at,
                'moderated_by' => $this->moderated_by,
                'moderator_name' => $this->whenLoaded('moderator', fn () => $this->moderator?->name),
                'rejection_reason' => $this->rejection_reason,
            ],
            'user' => $this->whenLoaded('user', fn () => [
                'id' => $this->user->id,
                'name' => $this->user->name,
                'email' => $this->user->email,
                'status' => $this->user->status,
            ]),
            'photos_count' => $this->whenCounted('profilePhotos'),
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
