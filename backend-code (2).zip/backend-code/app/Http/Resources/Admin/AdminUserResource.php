<?php

declare(strict_types=1);

namespace App\Http\Resources\Admin;

use App\Constants\UserRole;
use App\Constants\UserStatus;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AdminUserResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $profile = $this->whenLoaded('profiles', fn () => $this->profiles->first());

        return [
            'id' => $this->id,
            'name' => $this->name,
            'email' => $this->email,
            'phone' => $this->phone,
            'role' => $this->role,
            'role_label' => UserRole::label((int) $this->role),
            'status' => $this->status,
            'status_label' => UserStatus::label((int) $this->status),
            'email_verified_at' => $this->email_verified_at,
            'phone_verified_at' => $this->phone_verified_at,
            'suspended_at' => $this->suspended_at,
            'suspension_reason' => $this->suspension_reason,
            'last_seen_at' => $this->last_seen_at,
            'created_at' => $this->created_at,
            'deleted_at' => $this->deleted_at,
            'profile' => $this->when($this->relationLoaded('profiles') && $profile !== null, fn () => [
                'id' => $profile->id,
                'first_name' => $profile->first_name,
                'last_name' => $profile->last_name,
                'gender' => $profile->gender,
                'moderation_status' => $profile->moderation_status,
                'profile_completion_percentage' => $profile->profile_completion_percentage,
            ]),
            'counts' => [
                'interests_sent' => $this->whenCounted('sentInterestRequests'),
                'interests_received' => $this->whenCounted('receivedInterestRequests'),
                'bookings' => $this->whenCounted('bookings'),
                'reviews' => $this->whenCounted('reviews'),
            ],
        ];
    }
}
