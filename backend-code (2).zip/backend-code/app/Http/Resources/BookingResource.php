<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class BookingResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'status' => $this->status,
            'payment_status' => $this->payment_status,
            'service_date' => $this->service_date?->toDateString(),
            'service_time_from' => $this->service_time_from?->toTimeString(),
            'service_time_to' => $this->service_time_to?->toTimeString(),
            'location' => [
                'address' => $this->location_address,
                'city' => $this->city->name ?? null,
            ],
            'guests_count' => $this->guests_count,
            'special_requirements' => $this->special_requirements,
            'estimated_amount' => $this->estimated_amount !== null ? (float) $this->estimated_amount : null,
            'final_amount' => $this->final_amount !== null ? (float) $this->final_amount : null,
            'vendor' => new VendorCompactResource($this->vendor),
            'customer' => $this->whenLoaded('user', fn () => new UserMinimalResource($this->user)),
            'service' => new VendorServiceResource($this->vendorService),
            'inquiry_responded_at' => $this->inquiry_responded_at?->toDateTimeString(),
            'confirmed_at' => $this->confirmed_at?->toDateTimeString(),
            'completed_at' => $this->completed_at?->toDateTimeString(),
            'cancelled_at' => $this->cancelled_at?->toDateTimeString(),
            'review' => new ReviewResource($this->review),
            'can_confirm' => $this->canAcceptQuote(),
            'can_cancel' => ! in_array($this->status, ['COMPLETED', 'CANCELLED']),
            'can_review' => $this->status === 'COMPLETED' && ! $this->review,
            'created_at' => $this->created_at?->toDateTimeString(),
            'updated_at' => $this->updated_at?->toDateTimeString(),
        ];
    }
}
