<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Models\Caste;
use App\Models\City;
use App\Models\Education;
use App\Models\Hobby;
use App\Models\Occupation;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PreferenceResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $casteIds = $this->decodeIds($this->preferred_castes);
        $educationIds = $this->decodeIds($this->preferred_educations);
        $occupationIds = $this->decodeIds($this->preferred_occupations);
        $cityIds = $this->decodeIds($this->preferred_locations);
        $hobbyIds = $this->decodeIds($this->preferred_qualities);
        $extra = json_decode($this->additional_preferences ?: '{}', true) ?: [];

        return [
            'id' => $this->id,
            'profile_id' => $this->profile_id,
            'age_min' => $this->age_from,
            'age_max' => $this->age_to,
            'height_min_cm' => $this->height_from,
            'height_max_cm' => $this->height_to,
            'religion_id' => $this->religion_id,
            'religion' => $this->whenLoaded('religion', fn () => $this->religion?->name),
            'caste_ids' => $casteIds,
            'castes' => $casteIds ? Caste::whereIn('id', $casteIds)->pluck('name')->toArray() : [],
            'complexions' => $extra['complexions'] ?? [],
            'food_types' => $extra['food_types'] ?? [],
            'hobby_ids' => $hobbyIds,
            'hobbies' => $hobbyIds ? Hobby::whereIn('id', $hobbyIds)->pluck('name')->toArray() : [],
            'city_ids' => $cityIds,
            'cities' => $cityIds ? City::whereIn('id', $cityIds)->pluck('name')->toArray() : [],
            'state_ids' => $extra['state_ids'] ?? [],
            'education_ids' => $educationIds,
            'educations' => $educationIds ? Education::whereIn('id', $educationIds)->pluck('level')->toArray() : [],
            'occupation_ids' => $occupationIds,
            'occupations' => $occupationIds ? Occupation::whereIn('id', $occupationIds)->pluck('name')->toArray() : [],
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }

    private function decodeIds(?string $json): array
    {
        if (! $json) {
            return [];
        }

        $decoded = json_decode($json, true);

        return is_array($decoded) ? array_values(array_map('intval', $decoded)) : [];
    }
}
