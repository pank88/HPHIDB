<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class VendorTestimonialResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'reviewer_name' => $this->reviewer_name ?? $this->client_name,
            'reviewer_title' => $this->reviewer_title,
            'location' => $this->client_location,
            'body' => $this->body ?? $this->testimonial,
            'rating' => $this->rating,
            'image_url' => $this->image_url,
            'is_featured' => $this->is_featured,
            'created_at' => $this->created_at?->toDateTimeString(),
        ];
    }
}
