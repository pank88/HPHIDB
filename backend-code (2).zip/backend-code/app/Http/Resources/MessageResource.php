<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class MessageResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $currentUser = $request->user();
        $canEdit = $currentUser && $this->sender_id === $currentUser->id && $this->canBeEdited();
        $canDelete = $currentUser && $this->sender_id === $currentUser->id && $this->canBeDeleted();

        return [
            'id' => $this->id,
            'conversation_id' => $this->conversation_id,
            'body' => $this->body,
            'type' => $this->type ?? 'text',
            'media_url' => $this->media_url,
            'file_name' => $this->file_name,
            'file_size' => $this->file_size,
            'is_edited' => $this->is_edited ?? false,
            'edited_at' => $this->edited_at?->toIso8601String(),
            'read_at' => $this->read_at?->toIso8601String(),
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
            'sender' => new UserMinimalResource($this->sender),
            'sender_name' => $this->sender?->name ?? null,
            'sender_avatar' => $this->sender?->profiles?->first()?->photos?->first()?->photo_url,
            'is_sent_by_current_user' => $currentUser && $this->sender_id === $currentUser->id,
            'can_edit' => $canEdit,
            'can_delete' => $canDelete,
        ];
    }

    protected function canBeEdited(): bool
    {
        $editWindowMinutes = config('chat.edit_window_minutes', 60);

        return $this->created_at->addMinutes($editWindowMinutes)->isFuture();
    }

    protected function canBeDeleted(): bool
    {
        $deleteWindowMinutes = config('chat.delete_window_minutes', 1440);

        return $this->created_at->addMinutes($deleteWindowMinutes)->isFuture();
    }
}
