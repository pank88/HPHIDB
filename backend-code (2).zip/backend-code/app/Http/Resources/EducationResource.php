<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class EducationResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'education_id' => $this->education_id,
            'education_level' => $this->whenLoaded('education', fn () => $this->education->name),
            'specialization' => $this->specialization,
            'institute' => $this->institute,
            'is_highest' => $this->is_highest,
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }
}
