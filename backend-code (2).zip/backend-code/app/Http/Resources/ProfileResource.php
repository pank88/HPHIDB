<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ProfileResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'full_name' => $this->full_name,
            'gender' => $this->gender,
            'gender_label' => $this->getGenderLabel(),
            'date_of_birth' => $this->date_of_birth?->format('Y-m-d'),
            'age' => $this->date_of_birth ? (int) abs(now()->diffInYears($this->date_of_birth)) : null,
            'created_for' => $this->created_for,
            'created_for_label' => $this->getCreatedForLabel(),
            'religion_id' => $this->religion_id,
            'religion' => $this->when($this->relationLoaded('religion'), fn () => new ReligionResource($this->religion)),
            'caste_id' => $this->caste_id,
            'caste' => $this->when($this->relationLoaded('caste'), fn () => $this->caste ? $this->caste->name : null),
            'gotra_id' => $this->gotra_id,
            'gotra' => $this->when($this->relationLoaded('gotra'), fn () => $this->gotra ? $this->gotra->name : null),
            'occupation_id' => $this->occupation_id,
            'occupation' => $this->when($this->relationLoaded('occupation'), fn () => $this->occupation ? $this->occupation->name : null),
            'state_id' => $this->state_id,
            'state' => $this->when($this->relationLoaded('state'), fn () => $this->state ? $this->state->name : null),
            'city_id' => $this->city_id,
            'city' => $this->when($this->relationLoaded('city'), fn () => $this->city ? $this->city->name : null),
            'income_level_id' => $this->income_level_id,
            'income_level' => $this->when($this->relationLoaded('incomeLevel'), fn () => $this->incomeLevel ? ['id' => $this->incomeLevel->id, 'label' => $this->incomeLevel->label] : null),
            'marital_status' => $this->marital_status,
            'marital_status_label' => $this->getMaritalStatusLabel(),
            'height_cm' => $this->height_cm,
            'complexion' => $this->complexion,
            'complexion_label' => $this->getComplexionLabel(),
            'food_type' => $this->food_type,
            'food_type_label' => $this->getFoodTypeLabel(),
            'about' => $this->about,
            'educations' => EducationResource::collection($this->whenLoaded('educations')),
            'photos' => PhotoResource::collection($this->whenLoaded('photos')),
            'hobbies' => $this->whenLoaded('hobbies', function () {
                return $this->hobbies->map(fn ($h) => [
                    'id' => $h->id,
                    'name' => $h->name,
                ]);
            }),
            'preferences' => $this->when($this->relationLoaded('partnerPreference'), fn () => new PreferenceResource($this->partnerPreference)),
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }

    private function getGenderLabel(): ?string
    {
        return match ($this->gender) {
            'male' => 'Male',
            'female' => 'Female',
            'other' => 'Other',
            default => null,
        };
    }

    private function getCreatedForLabel(): ?string
    {
        return match ($this->created_for) {
            'self' => 'Self',
            'son' => 'Son',
            'daughter' => 'Daughter',
            'brother' => 'Brother',
            'sister' => 'Sister',
            'friend' => 'Friend',
            default => null,
        };
    }

    private function getMaritalStatusLabel(): ?string
    {
        return match ($this->marital_status) {
            1 => 'Never Married',
            2 => 'Divorced',
            3 => 'Widowed',
            default => null,
        };
    }

    private function getComplexionLabel(): ?string
    {
        return match ($this->complexion) {
            'fair' => 'Fair',
            'very_fair' => 'Very Fair',
            'wheatish' => 'Wheatish',
            'wheatish_brown' => 'Wheatish Brown',
            'brown' => 'Brown',
            'dark_brown' => 'Dark Brown',
            default => null,
        };
    }

    private function getFoodTypeLabel(): ?string
    {
        return match ($this->food_type) {
            'veg' => 'Vegetarian',
            'non_veg' => 'Non-Vegetarian',
            'both' => 'Both',
            'jain' => 'Jain',
            default => null,
        };
    }
}
