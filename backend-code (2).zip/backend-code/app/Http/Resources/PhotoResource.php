<?php

declare(strict_types=1);

namespace App\Http\Resources;

use App\Models\ProfilePhoto;
use App\Services\SecurePhotoService;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class PhotoResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        // ProfilePhoto (profile_photos table, populated by the demo seeder /
        // gallery photos) has a different schema than Photo (the encrypted,
        // signed-URL upload pipeline behind SecurePhotoService) — branch so
        // this resource can serialize either without crashing.
        if ($this->resource instanceof ProfilePhoto) {
            return [
                'id' => $this->id,
                'is_primary' => $this->is_primary,
                'is_verified' => $this->is_verified,
                'status' => $this->status,
                // Pinned to 'public' explicitly: Storage::url() without a disk
                // resolves against config('filesystems.default'), which is
                // 'local' in .env.example (no 'url' mapping there) and would
                // throw RuntimeException on any environment that hasn't
                // overridden it the way the current dev .env happens to.
                'signed_url' => Storage::disk('public')->url($this->photo_path),
                'thumbnail_url' => Storage::disk('public')->url($this->photo_path),
                'created_at' => $this->created_at?->toIso8601String(),
                'updated_at' => $this->updated_at?->toIso8601String(),
            ];
        }

        $photoService = app(SecurePhotoService::class);

        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'original_name' => $this->original_name,
            'mime_type' => $this->mime_type,
            'file_size' => $this->file_size,
            'is_primary' => $this->is_primary,
            'is_verified' => $this->is_verified,
            'status' => $this->status,
            'status_label' => $this->getStatusLabel(),
            'signed_url' => $photoService->getSignedUrl($this->resource),
            'thumbnail_url' => $photoService->getThumbUrl($this->resource),
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }

    private function getStatusLabel(): string
    {
        return match ($this->status) {
            'pending' => 'Pending Review',
            'approved' => 'Approved',
            'rejected' => 'Rejected',
            'private' => 'Private',
            default => 'Unknown',
        };
    }
}
