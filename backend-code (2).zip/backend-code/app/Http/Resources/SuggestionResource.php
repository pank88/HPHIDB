<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class SuggestionResource extends JsonResource
{
    protected ?array $breakdown = null;

    protected ?float $compatibilityScore = null;

    public function __construct($resource, ?array $breakdown = null, ?float $compatibilityScore = null)
    {
        parent::__construct($resource);
        $this->breakdown = $breakdown;
        $this->compatibilityScore = $compatibilityScore;
    }

    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->user_id,
            'full_name' => $this->full_name,
            'gender' => $this->gender,
            'gender_label' => $this->getGenderLabel(),
            'date_of_birth' => $this->date_of_birth?->format('Y-m-d'),
            'age' => $this->date_of_birth ? (int) abs(now()->diffInYears($this->date_of_birth)) : null,
            'created_for' => $this->created_for,
            'created_for_label' => $this->getCreatedForLabel(),
            'religion_id' => $this->religion_id,
            'religion' => $this->when($this->relationLoaded('religion'), fn () => new ReligionResource($this->religion)),
            'caste_id' => $this->caste_id,
            'caste' => $this->when($this->relationLoaded('caste'), fn () => $this->caste?->name),
            'gotra_id' => $this->gotra_id,
            'gotra' => $this->when($this->relationLoaded('gotra'), fn () => $this->gotra?->name),
            'occupation_id' => $this->occupation_id,
            'occupation' => $this->when($this->relationLoaded('occupation'), fn () => $this->occupation?->name),
            'state_id' => $this->state_id,
            'state' => $this->when($this->relationLoaded('state'), fn () => $this->state?->name),
            'city_id' => $this->city_id,
            'city' => $this->when($this->relationLoaded('city'), fn () => $this->city?->name),
            'marital_status' => $this->marital_status,
            'marital_status_label' => $this->getMaritalStatusLabel(),
            'height' => $this->height,
            'complexion' => $this->complexion,
            'complexion_label' => $this->getComplexionLabel(),
            'food_type' => $this->food_type,
            'food_type_label' => $this->getFoodTypeLabel(),
            'about' => $this->about,
            'profile_completion_percentage' => $this->profile_completion_percentage,
            'is_verified' => $this->is_verified,
            'is_active' => $this->is_active,
            'educations' => EducationResource::collection($this->whenLoaded('educations')),
            'photos' => PhotoResource::collection($this->whenLoaded('profilePhotos')),
            'hobbies' => $this->whenLoaded('hobbies', function () {
                return $this->hobbies->map(fn ($h) => [
                    'id' => $h->id,
                    'name' => $h->name,
                ]);
            }),
            'compatibility_score' => $this->compatibilityScore,
            'compatibility_breakdown' => $this->formatBreakdown($this->breakdown),
            'created_at' => $this->created_at?->toIso8601String(),
            'updated_at' => $this->updated_at?->toIso8601String(),
        ];
    }

    private function getGenderLabel(): ?string
    {
        return match ($this->gender) {
            'male' => 'Male',
            'female' => 'Female',
            'other' => 'Other',
            default => null,
        };
    }

    private function getCreatedForLabel(): ?string
    {
        return match ($this->created_for) {
            'self' => 'Self',
            'son' => 'Son',
            'daughter' => 'Daughter',
            'brother' => 'Brother',
            'sister' => 'Sister',
            'friend' => 'Friend',
            default => null,
        };
    }

    private function getMaritalStatusLabel(): ?string
    {
        return match ($this->marital_status) {
            1 => 'Never Married',
            2 => 'Divorced',
            3 => 'Widowed',
            default => null,
        };
    }

    private function getComplexionLabel(): ?string
    {
        return match ($this->complexion) {
            'fair' => 'Fair',
            'very_fair' => 'Very Fair',
            'wheatish' => 'Wheatish',
            'wheatish_brown' => 'Wheatish Brown',
            'brown' => 'Brown',
            'dark_brown' => 'Dark Brown',
            default => null,
        };
    }

    private function getFoodTypeLabel(): ?string
    {
        return match ($this->food_type) {
            'veg' => 'Vegetarian',
            'non_veg' => 'Non-Vegetarian',
            'both' => 'Both',
            'jain' => 'Jain',
            default => null,
        };
    }

    private function formatBreakdown(?array $breakdown): array
    {
        if (! $breakdown) {
            return [];
        }

        return array_map(function ($factor) {
            return [
                'score' => $factor['score'] ?? 0,
                'weight' => $factor['weight'] ?? 0,
                'weighted_score' => $factor['weighted_score'] ?? 0,
                'message' => $factor['message'] ?? '',
                'percentage' => $factor['percentage'] ?? 0,
            ];
        }, $breakdown);
    }
}
