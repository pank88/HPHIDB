<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\CancelBookingRequest;
use App\Http\Requests\CreateBookingRequest;
use App\Http\Requests\RespondInquiryRequest;
use App\Http\Resources\BookingResource;
use App\Models\Booking;
use App\Services\BookingService;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;

class BookingController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [
            new Middleware('auth:sanctum'),
            new Middleware('throttle:50,1', only: ['store']),
        ];
    }

    public function __construct(private BookingService $bookingService) {}

    public function store(CreateBookingRequest $request): JsonResponse
    {
        $booking = $this->bookingService->createBookingInquiry(
            $request->user(),
            $request->validated()
        );

        return (new BookingResource($booking))->response()->setStatusCode(201);
    }

    public function index(Request $request): JsonResponse
    {
        $status = $request->query('status');
        $page = (int) $request->query('page', 1);

        $bookings = $this->bookingService->getBookings($request->user(), $status, $page);

        return response()->json(BookingResource::collection($bookings)->response()->getData());
    }

    public function show(Booking $booking): JsonResponse
    {
        $this->authorize('view', $booking);

        return (new BookingResource($booking->load('vendor', 'vendorService', 'city', 'review', 'user')))->response();
    }

    public function respondToInquiry(Booking $booking, RespondInquiryRequest $request): JsonResponse
    {
        if (! $request->user()->vendor || $request->user()->vendor->id !== $booking->vendor_id) {
            throw new AuthorizationException('Unauthorized');
        }

        $updatedBooking = $this->bookingService->respondToInquiry(
            $request->user()->vendor,
            $booking,
            (float) $request->validated('final_amount'),
            $request->validated('response_notes')
        );

        return (new BookingResource($updatedBooking))->response();
    }

    public function confirmBooking(Booking $booking, Request $request): JsonResponse
    {
        if ($booking->user_id !== $request->user()->id) {
            throw new AuthorizationException('Unauthorized');
        }

        $updatedBooking = $this->bookingService->confirmBooking($request->user(), $booking);

        return (new BookingResource($updatedBooking))->response();
    }

    public function completeBooking(Booking $booking, Request $request): JsonResponse
    {
        if (! $request->user()->vendor || $request->user()->vendor->id !== $booking->vendor_id) {
            throw new AuthorizationException('Unauthorized');
        }

        $updatedBooking = $this->bookingService->completeBooking($request->user()->vendor, $booking);

        return (new BookingResource($updatedBooking))->response();
    }

    public function cancelBooking(Booking $booking, CancelBookingRequest $request): JsonResponse
    {
        $cancelledBooking = $this->bookingService->cancelBooking(
            $request->user(),
            $booking,
            $request->validated('cancellation_reason')
        );

        return (new BookingResource($cancelledBooking))->response();
    }
}
