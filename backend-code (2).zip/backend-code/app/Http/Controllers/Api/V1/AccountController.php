<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\Account\UpdateEmailRequest;
use App\Http\Requests\Account\UpdateMobileRequest;
use App\Http\Requests\Account\UpdatePasswordRequest;
use App\Services\OtpService;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;
use Illuminate\Support\Facades\Hash;

/** Self-service account settings: change password, update email/mobile. */
class AccountController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [new Middleware('auth:sanctum')];
    }

    public function __construct(private readonly OtpService $otpService) {}

    public function updatePassword(UpdatePasswordRequest $request): JsonResponse
    {
        $user = $request->user();

        if ($response = $this->rejectIfWrongPassword($user, $request->validated('current_password'))) {
            return $response;
        }

        $user->update(['password' => Hash::make($request->validated('password'))]);

        return ApiResponse::success(null, 'Password updated successfully.');
    }

    public function updateEmail(UpdateEmailRequest $request): JsonResponse
    {
        $user = $request->user();

        if ($response = $this->rejectIfWrongPassword($user, $request->validated('current_password'))) {
            return $response;
        }

        $user->update(['email' => $request->validated('email')]);

        return ApiResponse::success(['email' => $user->email], 'Email updated successfully.');
    }

    /**
     * Changes the phone number and immediately un-verifies it, sending a
     * fresh OTP to confirm the new number (mirrors the register/verify-otp
     * flow) — the account stays usable in the meantime.
     */
    public function updateMobile(UpdateMobileRequest $request): JsonResponse
    {
        $user = $request->user();

        if ($response = $this->rejectIfWrongPassword($user, $request->validated('current_password'))) {
            return $response;
        }

        $mobile = $request->validated('mobile');
        $user->update(['phone' => $mobile, 'phone_verified_at' => null]);

        $otp = $this->otpService->generate($mobile);
        $this->otpService->deliver($mobile, $otp, $user->email);

        $response = ['mobile' => $mobile];
        if ($this->otpService->shouldExposeInResponse()) {
            $response['otp'] = $otp;
        }

        return ApiResponse::success($response, 'Mobile number updated. Please verify it with the OTP we sent.');
    }

    private function rejectIfWrongPassword(mixed $user, string $currentPassword): ?JsonResponse
    {
        if (Hash::check($currentPassword, $user->password)) {
            return null;
        }

        return ApiResponse::error(
            'Current password is incorrect.',
            ['current_password' => ['Current password is incorrect.']],
            422
        );
    }
}
