<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Constants\UserRole;
use App\Http\Controllers\Controller;
use App\Http\Requests\Discovery\RefreshSuggestionsRequest;
use App\Http\Resources\SuggestionResource;
use App\Models\Profile;
use App\Services\SuggestionService;
use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;
use Illuminate\Support\Facades\Cache;

class SuggestionController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [
            new Middleware('auth:sanctum'),
        ];
    }

    protected SuggestionService $suggestionService;

    public function __construct(SuggestionService $suggestionService)
    {
        $this->suggestionService = $suggestionService;
    }

    /**
     * Get today's suggestions
     *
     * GET /api/v1/suggestions
     */
    public function index(): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->role !== UserRole::USER) {
                return response()->json([
                    'success' => false,
                    'message' => 'Only users can view suggestions',
                ], 403);
            }

            $suggestions = $this->suggestionService->getTodaysSuggestions($user);

            $resources = $suggestions->map(function (Profile $profile) use ($user) {
                $breakdown = $this->suggestionService->getBreakdown($user, $profile);
                $compatibility = $profile->compatibility_score ?? 0;

                return new SuggestionResource($profile, $breakdown, $compatibility);
            });

            return response()->json([
                'success' => true,
                'data' => $resources,
                'total' => $resources->count(),
                'message' => 'Suggestions retrieved successfully',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve suggestions',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Get detailed compatibility breakdown for a suggestion
     *
     * GET /api/v1/suggestions/{profileId}/breakdown
     */
    public function breakdown(string $profileId): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->role !== UserRole::USER) {
                return response()->json([
                    'success' => false,
                    'message' => 'Only users can view breakdowns',
                ], 403);
            }

            $profile = Profile::findOr($profileId, function () {
                return null;
            });

            if (! $profile) {
                return response()->json([
                    'success' => false,
                    'message' => 'Profile not found',
                ], 404);
            }

            $breakdown = $this->suggestionService->getBreakdown($user, $profile);

            // Record view
            $this->suggestionService->recordView($user, $profile);

            return response()->json([
                'success' => true,
                'message' => 'Breakdown retrieved successfully',
                'data' => [
                    'profile_id' => $profile->id,
                    'breakdown' => $breakdown,
                    'total_score' => array_sum(array_column($breakdown, 'weighted_score')),
                ],
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve breakdown',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Refresh suggestions (premium feature, rate limited)
     *
     * POST /api/v1/suggestions/refresh
     */
    public function refresh(RefreshSuggestionsRequest $request): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->role !== UserRole::USER) {
                return response()->json([
                    'success' => false,
                    'message' => 'Only users can refresh suggestions',
                ], 403);
            }

            // Check rate limiting (3 times per day max)
            $cacheKey = "refresh_suggestions_{$user->id}_".today()->format('Y-m-d');
            $refreshCount = Cache::get($cacheKey, 0);

            if ($refreshCount >= 3) {
                return response()->json([
                    'success' => false,
                    'message' => 'You have reached the maximum number of refreshes for today (3 per day)',
                ], 429);
            }

            // Increment refresh count
            Cache::put($cacheKey, $refreshCount + 1, 86400); // 24 hours

            // Refresh suggestions
            $suggestions = $this->suggestionService->refreshSuggestions($user);

            $resources = $suggestions->map(function (Profile $profile) use ($user) {
                $breakdown = $this->suggestionService->getBreakdown($user, $profile);
                $compatibility = $profile->compatibility_score ?? 0;

                return new SuggestionResource($profile, $breakdown, $compatibility);
            });

            return response()->json([
                'success' => true,
                'data' => $resources,
                'total' => $resources->count(),
                'message' => 'Suggestions refreshed successfully',
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to refresh suggestions',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
