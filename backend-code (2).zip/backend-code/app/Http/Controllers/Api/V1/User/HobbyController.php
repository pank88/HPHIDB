<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\Profile\UpdateHobbiesRequest;
use App\Models\Profile;
use App\Support\AuditLogger;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;

class HobbyController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [
            new Middleware('auth:sanctum'),
        ];
    }

    /**
     * Update hobbies
     */
    public function update(UpdateHobbiesRequest $request): JsonResponse
    {
        try {
            $user = $request->user();
            $profile = Profile::where('user_id', $user->id)->firstOrFail();

            // Authorize
            $this->authorize('update', $profile);

            // Sync hobbies
            $hobbyIds = $request->validated()['hobby_ids'] ?? [];
            $profile->hobbies()->sync($hobbyIds);

            AuditLogger::log($user, $profile, 'hobbies.updated', ['hobby_ids' => $hobbyIds]);

            $hobbies = $profile->hobbies()->get();

            return response()->json([
                'success' => true,
                'message' => 'Hobbies updated successfully',
                'data' => $hobbies->map(fn ($h) => [
                    'id' => $h->id,
                    'name' => $h->name,
                ]),
            ]);
        } catch (AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Please create your profile first.',
            ], 409);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update hobbies',
                'error' => $e->getMessage(),
            ], 400);
        }
    }
}
