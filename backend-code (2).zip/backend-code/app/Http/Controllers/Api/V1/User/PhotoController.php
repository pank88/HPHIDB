<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\Profile\StorePhotoRequest;
use App\Http\Resources\PhotoResource;
use App\Models\Photo;
use App\Services\SecurePhotoService;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;

class PhotoController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [
            new Middleware('auth:sanctum'),
            new Middleware('throttle:photo-upload'),
        ];
    }

    protected SecurePhotoService $photoService;

    public function __construct(SecurePhotoService $photoService)
    {
        $this->photoService = $photoService;
    }

    /**
     * Upload photo
     */
    public function store(StorePhotoRequest $request): JsonResponse
    {
        try {
            $user = $request->user();

            // Authorize
            $this->authorize('create', Photo::class);

            $photo = $this->photoService->uploadPhoto(
                $user,
                $request->file('photo'),
                $request->boolean('is_primary', false)
            );

            return response()->json([
                'success' => true,
                'message' => 'Photo uploaded successfully',
                'data' => new PhotoResource($photo),
            ], 201);
        } catch (AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to upload photo',
                'error' => $e->getMessage(),
            ], 400);
        }
    }

    /**
     * Set photo as primary
     */
    public function setPrimary(Photo $photo): JsonResponse
    {
        try {
            $user = auth()->user();

            // Authorize
            $this->authorize('update', $photo);

            $this->photoService->setPrimary($photo);

            return response()->json([
                'success' => true,
                'message' => 'Photo set as primary successfully',
                'data' => new PhotoResource($photo),
            ]);
        } catch (AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to set photo as primary',
                'error' => $e->getMessage(),
            ], 400);
        }
    }

    /**
     * Delete photo
     */
    public function destroy(Photo $photo): JsonResponse
    {
        try {
            $user = auth()->user();

            // Authorize
            $this->authorize('delete', $photo);

            $this->photoService->deletePhoto($photo);

            return response()->json([
                'success' => true,
                'message' => 'Photo deleted successfully',
            ]);
        } catch (AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete photo',
                'error' => $e->getMessage(),
            ], 400);
        }
    }
}
