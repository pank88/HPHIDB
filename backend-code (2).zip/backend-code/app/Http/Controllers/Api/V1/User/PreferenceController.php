<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\Profile\UpdatePreferencesRequest;
use App\Http\Resources\PreferenceResource;
use App\Services\PreferenceService;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;

class PreferenceController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [
            new Middleware('auth:sanctum'),
        ];
    }

    protected PreferenceService $preferenceService;

    public function __construct(PreferenceService $preferenceService)
    {
        $this->preferenceService = $preferenceService;
    }

    /**
     * Get partner preferences
     */
    public function show(): JsonResponse
    {
        try {
            $user = auth()->user();
            $preferences = $this->preferenceService->getPreferencesWithRelations($user);

            return response()->json([
                'success' => true,
                'data' => new PreferenceResource($preferences),
            ]);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Preferences not found',
            ], 404);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch preferences',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Update partner preferences
     */
    public function update(UpdatePreferencesRequest $request): JsonResponse
    {
        try {
            $user = $request->user();
            // No separate authorize() call: preferences are always scoped to
            // the authenticated user's own profile by construction (see
            // PreferenceService::profileId), so there's no cross-user access
            // path to guard — and no PartnerPreferencePolicy exists to check.
            $updated = $this->preferenceService->updatePreferences($user, $request->validated());

            return response()->json([
                'success' => true,
                'message' => 'Preferences updated successfully',
                'data' => new PreferenceResource($updated->load('religion')),
            ]);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Please create your profile first.',
            ], 409);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update preferences',
                'error' => $e->getMessage(),
            ], 400);
        }
    }
}
