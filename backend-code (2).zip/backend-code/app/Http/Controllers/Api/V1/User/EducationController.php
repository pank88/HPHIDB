<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\Profile\StoreEducationRequest;
use App\Http\Resources\EducationResource;
use App\Models\ProfileEducation;
use App\Services\EducationService;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;

class EducationController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [
            new Middleware('auth:sanctum'),
        ];
    }

    protected EducationService $educationService;

    public function __construct(EducationService $educationService)
    {
        $this->educationService = $educationService;
    }

    /**
     * Get all educations for profile
     */
    public function index(): JsonResponse
    {
        try {
            $user = auth()->user();
            $educations = $this->educationService->getEducations($user);

            return response()->json([
                'success' => true,
                'data' => EducationResource::collection($educations),
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch educations',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Store education
     */
    public function store(StoreEducationRequest $request): JsonResponse
    {
        try {
            $user = $request->user();

            // Authorize
            $this->authorize('create', ProfileEducation::class);

            $education = $this->educationService->storeEducation($user, $request->validated());

            return response()->json([
                'success' => true,
                'message' => 'Education added successfully',
                'data' => new EducationResource($education->load('education')),
            ], 201);
        } catch (AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to add education',
                'error' => $e->getMessage(),
            ], 400);
        }
    }

    /**
     * Update education
     */
    public function update(StoreEducationRequest $request, ProfileEducation $education): JsonResponse
    {
        try {
            $user = $request->user();

            // Authorize
            $this->authorize('update', $education);

            $updated = $this->educationService->updateEducation($user, $education, $request->validated());

            return response()->json([
                'success' => true,
                'message' => 'Education updated successfully',
                'data' => new EducationResource($updated->load('education')),
            ]);
        } catch (AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update education',
                'error' => $e->getMessage(),
            ], 400);
        }
    }

    /**
     * Delete education
     */
    public function destroy(ProfileEducation $education): JsonResponse
    {
        try {
            $user = auth()->user();

            // Authorize
            $this->authorize('delete', $education);

            $this->educationService->deleteEducation($user, $education);

            return response()->json([
                'success' => true,
                'message' => 'Education deleted successfully',
            ]);
        } catch (AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete education',
                'error' => $e->getMessage(),
            ], 400);
        }
    }

    /**
     * Set education as highest
     */
    public function setHighest(ProfileEducation $education): JsonResponse
    {
        try {
            $user = auth()->user();

            // Authorize
            $this->authorize('update', $education);

            $updated = $this->educationService->setHighest($user, $education);

            return response()->json([
                'success' => true,
                'message' => 'Education set as highest successfully',
                'data' => new EducationResource($updated->load('education')),
            ]);
        } catch (AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to set education as highest',
                'error' => $e->getMessage(),
            ], 400);
        }
    }
}
