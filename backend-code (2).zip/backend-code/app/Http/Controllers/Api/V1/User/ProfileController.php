<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\Profile\StoreProfileRequest;
use App\Http\Requests\Profile\UpdateProfileRequest;
use App\Http\Resources\ProfileResource;
use App\Models\Profile;
use App\Services\ProfileService;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;

class ProfileController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [
            new Middleware('auth:sanctum'),
        ];
    }

    protected ProfileService $profileService;

    public function __construct(ProfileService $profileService)
    {
        $this->profileService = $profileService;
    }

    /**
     * Store a new profile
     */
    public function store(StoreProfileRequest $request): JsonResponse
    {
        try {
            $user = $request->user();

            // Authorize
            $this->authorize('create', Profile::class);

            $profile = $this->profileService->storeProfile($user, $request->validated());

            return response()->json([
                'success' => true,
                'message' => 'Profile created successfully',
                'data' => new ProfileResource($profile->load([
                    'educations.education',
                    'photos',
                    'hobbies',
                    'partnerPreference',
                    'religion',
                    'caste',
                    'gotra',
                    'occupation',
                    'state',
                    'city',
                ])),
            ], 201);
        } catch (AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to create profile',
                'error' => $e->getMessage(),
            ], 400);
        }
    }

    /**
     * Get user profile
     */
    public function show(): JsonResponse
    {
        try {
            $user = auth()->user();

            $profile = $this->profileService->getProfileWithRelations($user);

            // Authorize
            $this->authorize('view', $profile);

            $completeness = $this->profileService->calculateCompleteness($user);

            return response()->json([
                'success' => true,
                'data' => new ProfileResource($profile),
                'completeness' => $completeness,
            ]);
        } catch (AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        } catch (ModelNotFoundException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Profile not found',
            ], 404);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch profile',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Update profile
     */
    public function update(UpdateProfileRequest $request): JsonResponse
    {
        try {
            $user = $request->user();
            $profile = $this->profileService->getOrCreateProfile($user);

            // Authorize
            $this->authorize('update', $profile);

            $updatedProfile = $this->profileService->updateProfile($user, $request->validated());

            return response()->json([
                'success' => true,
                'message' => 'Profile updated successfully',
                'data' => new ProfileResource($updatedProfile->load([
                    'educations.education',
                    'photos',
                    'hobbies',
                    'partnerPreference',
                    'religion',
                    'caste',
                    'gotra',
                    'occupation',
                    'state',
                    'city',
                ])),
            ]);
        } catch (AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized',
            ], 403);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to update profile',
                'error' => $e->getMessage(),
            ], 400);
        }
    }
}
