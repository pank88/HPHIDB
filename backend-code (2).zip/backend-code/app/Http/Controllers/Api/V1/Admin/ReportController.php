<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Admin;

use App\Constants\InterestStatus;
use App\Http\Controllers\Controller;
use App\Http\Responses\ApiResponse;
use App\Models\Booking;
use App\Models\InterestRequest;
use App\Models\Message;
use App\Models\User;
use App\Models\UserMatch;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Collection;

class ReportController extends Controller
{
    private const DAYS = 30;

    public function users(): JsonResponse
    {
        $rows = User::query()
            ->selectRaw('DATE(created_at) as date, COUNT(*) as count')
            ->where('created_at', '>=', now()->subDays(self::DAYS)->startOfDay())
            ->groupBy('date')
            ->orderBy('date')
            ->pluck('count', 'date');

        return ApiResponse::success([
            'period_days' => self::DAYS,
            'registrations' => $this->fillSeries($rows),
        ], 'User registrations report');
    }

    public function bookings(): JsonResponse
    {
        $rows = Booking::query()
            ->selectRaw('DATE(created_at) as date, COUNT(*) as count, COALESCE(SUM(final_amount), 0) as revenue')
            ->where('created_at', '>=', now()->subDays(self::DAYS)->startOfDay())
            ->groupBy('date')
            ->orderBy('date')
            ->get()
            ->keyBy('date');

        $series = [];
        foreach ($this->dateRange() as $date) {
            $row = $rows->get($date);
            $series[] = [
                'date' => $date,
                'count' => $row !== null ? (int) $row->count : 0,
                'revenue' => $row !== null ? (float) $row->revenue : 0.0,
            ];
        }

        return ApiResponse::success([
            'period_days' => self::DAYS,
            'bookings' => $series,
        ], 'Bookings report');
    }

    public function engagement(): JsonResponse
    {
        $since = now()->subDays(self::DAYS)->startOfDay();

        $interestsSent = InterestRequest::query()
            ->selectRaw('DATE(created_at) as date, COUNT(*) as count')
            ->where('created_at', '>=', $since)
            ->groupBy('date')
            ->pluck('count', 'date');

        $interestsAccepted = InterestRequest::query()
            ->selectRaw('DATE(updated_at) as date, COUNT(*) as count')
            ->where('status', InterestStatus::ACCEPTED)
            ->where('updated_at', '>=', $since)
            ->groupBy('date')
            ->pluck('count', 'date');

        $matches = UserMatch::query()
            ->selectRaw('DATE(created_at) as date, COUNT(*) as count')
            ->where('created_at', '>=', $since)
            ->groupBy('date')
            ->pluck('count', 'date');

        $messages = Message::query()
            ->selectRaw('DATE(created_at) as date, COUNT(*) as count')
            ->where('created_at', '>=', $since)
            ->groupBy('date')
            ->pluck('count', 'date');

        $series = [];
        foreach ($this->dateRange() as $date) {
            $series[] = [
                'date' => $date,
                'interests_sent' => (int) ($interestsSent[$date] ?? 0),
                'interests_accepted' => (int) ($interestsAccepted[$date] ?? 0),
                'matches_created' => (int) ($matches[$date] ?? 0),
                'messages' => (int) ($messages[$date] ?? 0),
            ];
        }

        return ApiResponse::success([
            'period_days' => self::DAYS,
            'engagement' => $series,
        ], 'Engagement report');
    }

    /**
     * @return array<int, string>
     */
    private function dateRange(): array
    {
        $dates = [];

        for ($i = self::DAYS - 1; $i >= 0; $i--) {
            $dates[] = now()->subDays($i)->toDateString();
        }

        return $dates;
    }

    private function fillSeries(Collection $rows): array
    {
        $series = [];

        foreach ($this->dateRange() as $date) {
            $series[] = [
                'date' => $date,
                'count' => (int) ($rows[$date] ?? 0),
            ];
        }

        return $series;
    }
}
