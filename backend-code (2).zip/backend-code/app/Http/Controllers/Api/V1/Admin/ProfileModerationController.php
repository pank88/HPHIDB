<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Admin;

use App\Constants\ModerationStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\RejectProfileRequest;
use App\Http\Resources\Admin\AdminProfileResource;
use App\Http\Responses\ApiResponse;
use App\Models\Profile;
use App\Models\ProfilePhoto;
use App\Services\Admin\AdminDashboardService;
use App\Services\Admin\ModerationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProfileModerationController extends Controller
{
    public function __construct(private readonly ModerationService $moderationService) {}

    public function pending(): JsonResponse
    {
        $profiles = Profile::query()
            ->with(['user:id,name,email,status', 'moderator:id,name'])
            ->withCount('profilePhotos')
            ->where('moderation_status', ModerationStatus::PENDING)
            ->oldest('id')
            ->paginate(25);

        $profiles->setCollection(
            $profiles->getCollection()->map(fn (Profile $profile) => new AdminProfileResource($profile))
        );

        return ApiResponse::paginated($profiles, 'Pending profiles');
    }

    public function approve(Request $request, int $id): JsonResponse
    {
        $profile = Profile::query()->findOrFail($id);

        $this->moderationService->approveProfile($request->user(), $profile);
        AdminDashboardService::clearCache();

        return ApiResponse::success(new AdminProfileResource($profile->refresh()), 'Profile approved');
    }

    public function reject(RejectProfileRequest $request, int $id): JsonResponse
    {
        $profile = Profile::query()->findOrFail($id);

        $this->moderationService->rejectProfile($request->user(), $profile, (string) $request->validated('reason'));
        AdminDashboardService::clearCache();

        return ApiResponse::success(new AdminProfileResource($profile->refresh()), 'Profile rejected');
    }

    public function pendingPhotos(): JsonResponse
    {
        $photos = ProfilePhoto::query()
            ->with('profile:id,user_id,first_name,last_name')
            ->where('is_verified', false)
            ->where('is_active', true)
            ->oldest('id')
            ->paginate(25);

        return ApiResponse::paginated($photos, 'Pending photos');
    }

    public function approvePhoto(Request $request, int $id): JsonResponse
    {
        $photo = ProfilePhoto::query()->findOrFail($id);

        $this->moderationService->approvePhoto($request->user(), $photo);

        return ApiResponse::success($photo->refresh(), 'Photo approved');
    }

    public function rejectPhoto(RejectProfileRequest $request, int $id): JsonResponse
    {
        $photo = ProfilePhoto::query()->findOrFail($id);

        $this->moderationService->rejectPhoto($request->user(), $photo, (string) $request->validated('reason'));

        return ApiResponse::success($photo->refresh(), 'Photo rejected');
    }
}
