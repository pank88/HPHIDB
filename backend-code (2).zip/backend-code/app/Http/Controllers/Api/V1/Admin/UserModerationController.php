<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\SuspendUserRequest;
use App\Http\Resources\Admin\AdminUserResource;
use App\Http\Resources\Admin\AuditLogResource;
use App\Http\Responses\ApiResponse;
use App\Models\AuditLog;
use App\Models\User;
use App\Services\Admin\AdminDashboardService;
use App\Services\Admin\ModerationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class UserModerationController extends Controller
{
    public function __construct(private readonly ModerationService $moderationService) {}

    public function index(Request $request): JsonResponse
    {
        $users = User::query()
            ->with('profiles:id,user_id,first_name,last_name,gender,moderation_status,profile_completion_percentage')
            ->withCount(['sentInterestRequests', 'receivedInterestRequests', 'bookings', 'reviews'])
            ->when($request->filled('role'), fn ($q) => $q->where('role', (int) $request->query('role')))
            ->when($request->filled('status'), fn ($q) => $q->where('status', (int) $request->query('status')))
            ->when($request->filled('search'), function ($q) use ($request) {
                $search = '%'.$request->query('search').'%';
                $q->where(function ($inner) use ($search) {
                    $inner->where('name', 'like', $search)
                        ->orWhere('email', 'like', $search)
                        ->orWhere('phone', 'like', $search);
                });
            })
            ->latest('id')
            ->paginate(25);

        $users->setCollection(
            $users->getCollection()->map(fn (User $user) => new AdminUserResource($user))
        );

        return ApiResponse::paginated($users, 'Users retrieved');
    }

    public function show(int $id): JsonResponse
    {
        $user = User::withTrashed()
            ->with(['profiles.profilePhotos', 'profiles.moderator:id,name'])
            ->withCount(['sentInterestRequests', 'receivedInterestRequests', 'bookings', 'reviews'])
            ->findOrFail($id);

        $auditTrail = AuditLog::query()
            ->with('user:id,name,email')
            ->where(function ($q) use ($user) {
                $q->where(function ($target) use ($user) {
                    $target->where('model_type', User::class)->where('model_id', $user->id);
                })->orWhere('user_id', $user->id);
            })
            ->latest('id')
            ->limit(20)
            ->get();

        return ApiResponse::success([
            'user' => new AdminUserResource($user),
            'photos' => $user->profiles->flatMap->profilePhotos->values(),
            'interests_summary' => [
                'sent' => $user->sent_interest_requests_count,
                'received' => $user->received_interest_requests_count,
            ],
            'audit_trail' => AuditLogResource::collection($auditTrail),
        ], 'User detail');
    }

    public function activate(Request $request, int $id): JsonResponse
    {
        $user = User::query()->findOrFail($id);

        $this->moderationService->activateUser($request->user(), $user);
        AdminDashboardService::clearCache();

        return ApiResponse::success(new AdminUserResource($user->refresh()), 'User activated');
    }

    public function suspend(SuspendUserRequest $request, int $id): JsonResponse
    {
        $user = User::query()->findOrFail($id);

        $this->moderationService->suspendUser($request->user(), $user, (string) $request->validated('reason'));
        AdminDashboardService::clearCache();

        return ApiResponse::success(new AdminUserResource($user->refresh()), 'User suspended');
    }

    public function destroy(Request $request, int $id): JsonResponse
    {
        $user = User::query()->findOrFail($id);

        $this->moderationService->deleteUser($request->user(), $user);
        AdminDashboardService::clearCache();

        return ApiResponse::success(null, 'User deleted');
    }
}
