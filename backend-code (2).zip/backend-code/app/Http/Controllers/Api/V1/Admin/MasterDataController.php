<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreMasterRequest;
use App\Http\Requests\Admin\UpdateMasterRequest;
use App\Http\Responses\ApiResponse;
use App\Services\Admin\AdminDashboardService;
use App\Services\Admin\MasterDataService;
use App\Services\Admin\ModerationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MasterDataController extends Controller
{
    public function __construct(
        private readonly MasterDataService $masterDataService,
        private readonly ModerationService $moderationService
    ) {}

    public function index(Request $request, string $type): JsonResponse
    {
        $this->assertType($type);

        $items = $this->masterDataService->list($type, $request->query('search'));

        return ApiResponse::paginated($items, ucfirst(str_replace('-', ' ', $type)).' retrieved');
    }

    public function store(StoreMasterRequest $request, string $type): JsonResponse
    {
        $this->assertType($type);

        $model = $this->masterDataService->create($type, $request->validated());

        $this->moderationService->audit($request->user(), 'master.create', $model, [], $model->getAttributes());
        AdminDashboardService::clearCache();

        return ApiResponse::created($model);
    }

    public function update(UpdateMasterRequest $request, string $type, int $id): JsonResponse
    {
        $this->assertType($type);

        $modelClass = $this->masterDataService->modelClass($type);
        $old = $modelClass::query()->findOrFail($id)->getAttributes();

        $model = $this->masterDataService->update($type, $id, $request->validated());

        $this->moderationService->audit($request->user(), 'master.update', $model, $old, $model->getChanges());

        return ApiResponse::success($model, 'Updated successfully');
    }

    public function destroy(Request $request, string $type, int $id): JsonResponse
    {
        $this->assertType($type);

        $modelClass = $this->masterDataService->modelClass($type);
        $model = $modelClass::query()->findOrFail($id);

        $references = $this->masterDataService->delete($type, $id);

        if ($references > 0) {
            return ApiResponse::error(
                'Cannot delete: record is referenced by other data',
                ['references' => $references],
                409
            );
        }

        $this->moderationService->audit($request->user(), 'master.delete', $model, $model->getAttributes(), []);

        return ApiResponse::success(null, 'Deleted successfully');
    }

    private function assertType(string $type): void
    {
        if (! $this->masterDataService->isValidType($type)) {
            abort(404, 'Unknown master data type');
        }
    }
}
