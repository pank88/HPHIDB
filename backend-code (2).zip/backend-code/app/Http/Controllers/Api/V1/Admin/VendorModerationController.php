<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\SuspendUserRequest;
use App\Http\Resources\Admin\AdminVendorResource;
use App\Http\Responses\ApiResponse;
use App\Models\Vendor;
use App\Models\VendorTestimonial;
use App\Services\Admin\AdminDashboardService;
use App\Services\Admin\ModerationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class VendorModerationController extends Controller
{
    public function __construct(private readonly ModerationService $moderationService) {}

    public function index(Request $request): JsonResponse
    {
        $vendors = Vendor::query()
            ->with('serviceCategory:id,name')
            ->withCount(['bookings', 'reviews'])
            ->when($request->filled('status'), fn ($q) => $q->where('status', (int) $request->query('status')))
            ->when($request->filled('category'), fn ($q) => $q->where('service_category_id', (int) $request->query('category')))
            ->when($request->filled('verified'), fn ($q) => $q->where('is_verified', $request->boolean('verified')))
            ->when($request->filled('search'), function ($q) use ($request) {
                $search = '%'.$request->query('search').'%';
                $q->where(function ($inner) use ($search) {
                    $inner->where('business_name', 'like', $search)
                        ->orWhere('owner_name', 'like', $search)
                        ->orWhere('email', 'like', $search);
                });
            })
            ->latest('id')
            ->paginate(25);

        $vendors->setCollection(
            $vendors->getCollection()->map(fn (Vendor $vendor) => new AdminVendorResource($vendor))
        );

        return ApiResponse::paginated($vendors, 'Vendors retrieved');
    }

    public function verify(Request $request, int $id): JsonResponse
    {
        $vendor = Vendor::query()->findOrFail($id);

        $this->moderationService->verifyVendor($request->user(), $vendor);
        AdminDashboardService::clearCache();

        return ApiResponse::success(new AdminVendorResource($vendor->refresh()), 'Vendor verified');
    }

    public function suspend(SuspendUserRequest $request, int $id): JsonResponse
    {
        $vendor = Vendor::query()->findOrFail($id);

        $this->moderationService->suspendVendor($request->user(), $vendor, (string) $request->validated('reason'));
        AdminDashboardService::clearCache();

        return ApiResponse::success(new AdminVendorResource($vendor->refresh()), 'Vendor suspended');
    }

    public function pendingTestimonials(): JsonResponse
    {
        $testimonials = VendorTestimonial::query()
            ->with('vendor:id,business_name')
            ->where('is_approved', false)
            ->oldest('id')
            ->paginate(25);

        return ApiResponse::paginated($testimonials, 'Pending testimonials');
    }

    public function approveTestimonial(Request $request, int $id): JsonResponse
    {
        $testimonial = VendorTestimonial::query()->findOrFail($id);

        $this->moderationService->approveTestimonial($request->user(), $testimonial);

        return ApiResponse::success($testimonial->refresh(), 'Testimonial approved');
    }

    public function rejectTestimonial(SuspendUserRequest $request, int $id): JsonResponse
    {
        $testimonial = VendorTestimonial::query()->findOrFail($id);

        $this->moderationService->rejectTestimonial($request->user(), $testimonial, (string) $request->validated('reason'));

        return ApiResponse::success($testimonial->refresh(), 'Testimonial rejected');
    }
}
