<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\Admin\AuditLogResource;
use App\Http\Responses\ApiResponse;
use App\Models\AuditLog;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AuditLogController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $logs = AuditLog::query()
            ->with('user:id,name,email')
            ->when($request->filled('user_id'), fn ($q) => $q->where('user_id', (int) $request->query('user_id')))
            ->when($request->filled('action'), fn ($q) => $q->where('action', $request->query('action')))
            ->when($request->filled('date_from'), fn ($q) => $q->whereDate('created_at', '>=', $request->query('date_from')))
            ->when($request->filled('date_to'), fn ($q) => $q->whereDate('created_at', '<=', $request->query('date_to')))
            ->latest('id')
            ->paginate(50);

        $logs->setCollection(
            $logs->getCollection()->map(fn (AuditLog $log) => new AuditLogResource($log))
        );

        return ApiResponse::paginated($logs, 'Audit logs retrieved');
    }

    public function show(int $id): JsonResponse
    {
        $log = AuditLog::query()->with('user:id,name,email')->findOrFail($id);

        return ApiResponse::success(new AuditLogResource($log), 'Audit log entry');
    }
}
