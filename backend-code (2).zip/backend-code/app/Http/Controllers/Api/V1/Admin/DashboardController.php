<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\Admin\AuditLogResource;
use App\Http\Responses\ApiResponse;
use App\Services\Admin\AdminDashboardService;
use Illuminate\Http\JsonResponse;

class DashboardController extends Controller
{
    public function __construct(private readonly AdminDashboardService $dashboardService) {}

    public function stats(): JsonResponse
    {
        return ApiResponse::success($this->dashboardService->stats(), 'Dashboard statistics');
    }

    public function activity(): JsonResponse
    {
        $activity = $this->dashboardService->recentActivity(20);

        return ApiResponse::success(
            AuditLogResource::collection($activity),
            'Recent admin activity'
        );
    }
}
