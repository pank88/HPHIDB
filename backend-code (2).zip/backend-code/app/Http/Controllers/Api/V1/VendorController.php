<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\VendorResource;
use App\Http\Resources\VendorServiceResource;
use App\Models\Vendor;
use App\Services\VendorService;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class VendorController extends Controller
{
    public function __construct(private VendorService $vendorService) {}

    public function index(Request $request): JsonResponse
    {
        $filters = $request->only(['category_id', 'city_id', 'rating_min', 'price_min', 'price_max', 'search', 'availability_date']);
        $page = (int) $request->query('page', 1);

        $vendors = $this->vendorService->searchVendors($filters, $page);

        return response()->json(VendorResource::collection($vendors)->response()->getData());
    }

    public function show(Vendor $vendor): JsonResponse
    {
        $vendor->load('vendorServices', 'reviews', 'vendorTestimonials');

        return response()->json(new VendorResource($vendor));
    }

    public function getServices(Vendor $vendor): JsonResponse
    {
        $services = $vendor->vendorServices()->active()->get();

        return response()->json(VendorServiceResource::collection($services));
    }

    public function getAvailableSlots(Vendor $vendor, string $date): JsonResponse
    {
        validator(['date' => $date], [
            'date' => 'required|date|after_or_equal:'.Carbon::today()->toDateString(),
        ])->validate();

        $date = Carbon::parse($date);
        $slots = $this->vendorService->getAvailableSlots($vendor, $date);

        return response()->json([
            'vendor_id' => $vendor->id,
            'date' => $date->toDateString(),
            'slots' => $slots,
        ]);
    }
}
