<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\Interest\BlockInterestRequest;
use App\Http\Requests\Interest\RejectInterestRequest;
use App\Http\Requests\Interest\SendInterestRequest;
use App\Http\Resources\InterestResource;
use App\Http\Resources\MatchResource;
use App\Models\InterestRequest;
use App\Models\Profile;
use App\Services\InterestService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;
use Illuminate\Support\Facades\RateLimiter;

class InterestController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [
            new Middleware('auth:sanctum'),
        ];
    }

    protected InterestService $interestService;

    public function __construct(InterestService $interestService)
    {
        $this->interestService = $interestService;
    }

    /**
     * Send interest to another profile
     */
    public function sendInterest(SendInterestRequest $request): JsonResponse
    {
        try {
            $user = $request->user();

            // Rate limiting: 20 per day per user
            $key = "send_interest:{$user->id}";
            if (RateLimiter::tooManyAttempts($key, 20)) {
                return response()->json([
                    'success' => false,
                    'message' => 'You have exceeded the daily interest limit. Try again tomorrow.',
                ], 429);
            }

            RateLimiter::hit($key, 86400); // 24 hours

            $receiverProfile = Profile::findOrFail($request->input('receiver_profile_id'));

            $interest = $this->interestService->sendInterest(
                sender: $user,
                receiverProfile: $receiverProfile,
                message: $request->input('message'),
                channel: $request->input('channel', InterestRequest::CHANNEL_APP)
            );

            return response()->json([
                'success' => true,
                'message' => 'Interest sent successfully',
                'data' => new InterestResource($interest),
            ], 201);
        } catch (\InvalidArgumentException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to send interest',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Get received interests
     */
    public function getReceivedInterests(Request $request): JsonResponse
    {
        try {
            $user = $request->user();
            $status = $request->query('status');
            $page = $request->query('page', 1);

            $interests = $this->interestService->getReceivedInterests(
                user: $user,
                status: $status,
                page: (int) $page
            );

            return response()->json([
                'success' => true,
                'data' => InterestResource::collection($interests),
                'pagination' => [
                    'current_page' => $interests->currentPage(),
                    'per_page' => $interests->perPage(),
                    'total' => $interests->total(),
                    'last_page' => $interests->lastPage(),
                ],
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch received interests',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Get sent interests
     */
    public function getSentInterests(Request $request): JsonResponse
    {
        try {
            $user = $request->user();
            $status = $request->query('status');
            $page = $request->query('page', 1);

            $interests = $this->interestService->getSentInterests(
                user: $user,
                status: $status,
                page: (int) $page
            );

            return response()->json([
                'success' => true,
                'data' => InterestResource::collection($interests),
                'pagination' => [
                    'current_page' => $interests->currentPage(),
                    'per_page' => $interests->perPage(),
                    'total' => $interests->total(),
                    'last_page' => $interests->lastPage(),
                ],
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch sent interests',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Get pending interests (summary)
     */
    public function getPendingInterests(Request $request): JsonResponse
    {
        try {
            $user = $request->user();

            $interests = $this->interestService->getPendingInterests($user);

            return response()->json([
                'success' => true,
                'data' => InterestResource::collection($interests),
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch pending interests',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Accept interest request
     */
    public function acceptInterest(Request $request, InterestRequest $interest): JsonResponse
    {
        try {
            $user = $request->user();

            // Authorize
            $this->authorize('accept', $interest);

            $match = $this->interestService->acceptInterest($user, $interest);

            return response()->json([
                'success' => true,
                'message' => 'Interest accepted successfully',
                'data' => new MatchResource($match->load([
                    'initiator',
                    'matcher',
                    'initiatorProfile',
                    'matcherProfile',
                ])),
            ], 201);
        } catch (\InvalidArgumentException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to accept interest',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Reject interest request
     */
    public function rejectInterest(RejectInterestRequest $request, InterestRequest $interest): JsonResponse
    {
        try {
            $user = $request->user();

            // Authorize
            $this->authorize('reject', $interest);

            $rejectedInterest = $this->interestService->rejectInterest($user, $interest);

            return response()->json([
                'success' => true,
                'message' => 'Interest rejected successfully',
                'data' => new InterestResource($rejectedInterest),
            ]);
        } catch (\InvalidArgumentException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to reject interest',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Block interest request and user
     */
    public function blockInterest(BlockInterestRequest $request, InterestRequest $interest): JsonResponse
    {
        try {
            $user = $request->user();

            // Authorize
            $this->authorize('block', $interest);

            $blockedInterest = $this->interestService->blockInterest($user, $interest);

            return response()->json([
                'success' => true,
                'message' => 'User blocked successfully',
                'data' => new InterestResource($blockedInterest),
            ]);
        } catch (\InvalidArgumentException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to block user',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Delete interest request
     */
    public function deleteInterest(Request $request, InterestRequest $interest): JsonResponse
    {
        try {
            $user = $request->user();

            // Authorize
            $this->authorize('delete', $interest);

            $interest->delete();

            return response()->json([
                'success' => true,
                'message' => 'Interest deleted successfully',
            ], 204);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete interest',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
