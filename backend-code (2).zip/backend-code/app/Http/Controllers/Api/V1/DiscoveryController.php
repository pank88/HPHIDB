<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Constants\UserRole;
use App\Http\Controllers\Controller;
use App\Http\Requests\Discovery\SearchRequest;
use App\Http\Resources\SuggestionResource;
use App\Models\Caste;
use App\Models\City;
use App\Models\Education;
use App\Models\Hobby;
use App\Models\Occupation;
use App\Models\Profile;
use App\Models\Religion;
use App\Models\State;
use App\Services\SearchService;
use App\Services\SuggestionService;
use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;
use Illuminate\Support\Facades\Cache;

class DiscoveryController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [
            new Middleware('auth:sanctum', except: ['filters']),
        ];
    }

    protected SearchService $searchService;

    protected SuggestionService $suggestionService;

    public function __construct(SearchService $searchService, SuggestionService $suggestionService)
    {
        $this->searchService = $searchService;
        $this->suggestionService = $suggestionService;
    }

    /**
     * Advanced profile search with filters
     *
     * POST /api/v1/discover/search
     */
    public function search(SearchRequest $request): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->role !== UserRole::USER) {
                return response()->json([
                    'success' => false,
                    'message' => 'Only users can search profiles',
                ], 403);
            }

            // Rate limiting: 100 requests per hour
            $cacheKey = "search_rate_{$user->id}_".now()->format('YmdH');
            $searchCount = Cache::get($cacheKey, 0);

            if ($searchCount >= 100) {
                return response()->json([
                    'success' => false,
                    'message' => 'Search rate limit exceeded. Maximum 100 searches per hour.',
                ], 429);
            }

            Cache::put($cacheKey, $searchCount + 1, 3600); // 1 hour

            // Perform search
            $paginated = $this->searchService->search($user, $request->validated());

            // Add compatibility scores
            $this->searchService->addCompatibilityScores($paginated->items(), $user);

            // Map to resources
            $resources = array_map(function ($profile) {
                $breakdown = null;
                if (isset($profile->compatibility_breakdown)) {
                    $breakdown = $profile->compatibility_breakdown;
                }

                return new SuggestionResource(
                    $profile,
                    $breakdown,
                    $profile->compatibility_score ?? 0
                );
            }, $paginated->items());

            return response()->json([
                'success' => true,
                'data' => $resources,
                'pagination' => [
                    'total' => $paginated->count(),
                    'per_page' => config('discovery.search_page_size', 20),
                    'current_page' => $paginated->currentPage(),
                    'has_more' => $paginated->hasMorePages(),
                    'next_page_url' => $paginated->nextPageUrl(),
                    'prev_page_url' => $paginated->previousPageUrl(),
                ],
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to search profiles',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Get available filter options
     *
     * GET /api/v1/discover/filters
     */
    public function filters(): JsonResponse
    {
        try {
            $cacheKey = 'discovery_filters';
            $ttl = config('discovery.filters_cache_ttl', 604800); // 7 days

            $filters = Cache::remember($cacheKey, $ttl, function () {
                return [
                    'religions' => Religion::query()->select('id', 'name')->get(),
                    'castes' => Caste::query()->select('id', 'name', 'religion_id')->get(),
                    'education_levels' => Education::query()->select('id', 'level as name')->get(),
                    'occupations' => Occupation::query()->select('id', 'name')->get(),
                    'states' => State::query()->select('id', 'name')->get(),
                    'cities' => City::query()->select('id', 'name', 'state_id')->get(),
                    'hobbies' => Hobby::query()->select('id', 'name')->get(),
                    'complexions' => [
                        ['value' => 'fair', 'label' => 'Fair'],
                        ['value' => 'very_fair', 'label' => 'Very Fair'],
                        ['value' => 'wheatish', 'label' => 'Wheatish'],
                        ['value' => 'wheatish_brown', 'label' => 'Wheatish Brown'],
                        ['value' => 'brown', 'label' => 'Brown'],
                        ['value' => 'dark_brown', 'label' => 'Dark Brown'],
                    ],
                    'food_types' => [
                        ['value' => 'veg', 'label' => 'Vegetarian'],
                        ['value' => 'non_veg', 'label' => 'Non-Vegetarian'],
                        ['value' => 'both', 'label' => 'Both'],
                        ['value' => 'jain', 'label' => 'Jain'],
                    ],
                    'sort_options' => [
                        ['value' => 'compatibility', 'label' => 'Best Match'],
                        ['value' => 'recent', 'label' => 'Most Recent'],
                        ['value' => 'completeness', 'label' => 'Most Complete'],
                        ['value' => 'photos', 'label' => 'Most Photos'],
                    ],
                ];
            });

            return response()->json([
                'success' => true,
                'data' => $filters,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve filters',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Get most viewed/liked profiles (popular)
     *
     * GET /api/v1/discover/popular
     */
    public function popular(): JsonResponse
    {
        try {
            $user = auth()->user();

            if ($user->role !== UserRole::USER) {
                return response()->json([
                    'success' => false,
                    'message' => 'Only users can view popular profiles',
                ], 403);
            }

            $cacheKey = 'popular_profiles';
            $ttl = config('discovery.popular_cache_ttl', 3600); // 1 hour

            $profiles = Cache::remember($cacheKey, $ttl, function () {
                // For now, return recently verified profiles
                // In future, base this on interaction count
                return Profile::searchable()
                    ->withCompatibility()
                    ->orderByDesc('created_at')
                    ->limit(20)
                    ->get();
            });

            // Add compatibility scores
            $this->searchService->addCompatibilityScores($profiles, $user);

            $resources = $profiles->map(function ($profile) {
                $breakdown = null;
                if (isset($profile->compatibility_breakdown)) {
                    $breakdown = $profile->compatibility_breakdown;
                }

                return new SuggestionResource(
                    $profile,
                    $breakdown,
                    $profile->compatibility_score ?? 0
                );
            });

            return response()->json([
                'success' => true,
                'data' => $resources,
                'total' => $resources->count(),
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve popular profiles',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
