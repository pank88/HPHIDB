<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Auth;

use App\Constants\UserRole;
use App\Constants\UserStatus;
use App\Constants\VendorStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\RegisterRequest;
use App\Models\User;
use App\Models\Vendor;
use App\Services\OtpService;
use App\Support\ApiResponse;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    public function __construct(private readonly OtpService $otpService) {}

    public function register(RegisterRequest $request)
    {
        try {
            $validated = $request->validated();

            $otp = $this->otpService->generate($validated['mobile']);

            // Create user
            $user = User::create([
                'name' => $validated['name'],
                'email' => $validated['email'],
                'phone' => $validated['mobile'],
                'password' => Hash::make($validated['password']),
                'role' => $validated['role'],
                'status' => UserStatus::PENDING,
            ]);

            // Create vendor record if role is vendor
            if ($validated['role'] === UserRole::VENDOR) {
                Vendor::create([
                    'user_id' => $user->id,
                    'business_name' => $validated['name'],
                    'owner_name' => $validated['name'],
                    'email' => $validated['email'],
                    'phone' => $validated['mobile'],
                    'service_category_id' => $validated['category_id'] ?? 1,
                    'business_address' => '',
                    'status' => VendorStatus::PENDING,
                    'is_verified' => false,
                ]);
            }

            $this->otpService->deliver($validated['mobile'], $otp, $validated['email']);

            // Generate token
            $token = $user->createToken('auth_token')->plainTextToken;

            $response = [
                'user' => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'mobile' => $user->phone,
                    'role' => $user->role,
                    'role_label' => UserRole::label($user->role),
                    'status' => $user->status,
                    'status_label' => UserStatus::label($user->status),
                ],
                'token' => $token,
            ];

            if ($this->otpService->shouldExposeInResponse()) {
                $response['otp'] = $otp;
            }

            return ApiResponse::success($response, 'Registration successful. Please verify your mobile number with OTP.', 201);
        } catch (\Exception $e) {
            return ApiResponse::error('Registration failed: '.$e->getMessage(), null, 500);
        }
    }
}
