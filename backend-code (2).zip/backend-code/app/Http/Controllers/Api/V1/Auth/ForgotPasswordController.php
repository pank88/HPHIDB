<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\ForgotPasswordRequest;
use App\Support\ApiResponse;
use Illuminate\Support\Facades\Password;

class ForgotPasswordController extends Controller
{
    public function sendResetLink(ForgotPasswordRequest $request)
    {
        try {
            $validated = $request->validated();

            // Send password reset link
            $response = Password::sendResetLink(
                ['email' => $validated['email']]
            );

            // Check if successful
            if ($response === Password::RESET_LINK_SENT) {
                return ApiResponse::success(null, 'Password reset link has been sent to your email.', 200);
            }

            return ApiResponse::error('Unable to send password reset link.', null, 500);
        } catch (\Exception $e) {
            return ApiResponse::error('Error: '.$e->getMessage(), null, 500);
        }
    }
}
