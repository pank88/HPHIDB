<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\ResetPasswordRequest;
use App\Support\ApiResponse;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;

class ResetPasswordController extends Controller
{
    public function reset(ResetPasswordRequest $request)
    {
        try {
            $validated = $request->validated();

            // Verify the password reset token
            $status = Password::reset(
                [
                    'email' => $validated['email'],
                    'password' => $validated['password'],
                    'password_confirmation' => $validated['password_confirmation'],
                    'token' => $validated['token'],
                ],
                function ($user, $password) {
                    $user->forceFill([
                        'password' => Hash::make($password),
                    ])->save();
                }
            );

            // Check if password was successfully reset
            if ($status === Password::PASSWORD_RESET) {
                return ApiResponse::success(null, 'Password has been reset successfully.', 200);
            }

            return ApiResponse::error('Invalid reset token or email.', null, 400);
        } catch (\Exception $e) {
            return ApiResponse::error('Password reset failed: '.$e->getMessage(), null, 500);
        }
    }
}
