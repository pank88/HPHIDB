<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\ResendOTPRequest;
use App\Models\User;
use App\Services\OtpService;
use App\Support\ApiResponse;

class ResendOTPController extends Controller
{
    public function __construct(private readonly OtpService $otpService) {}

    public function resend(ResendOTPRequest $request)
    {
        $validated = $request->validated();

        $user = User::where('phone', $validated['mobile'])->first();

        if ($user->phone_verified_at !== null) {
            return ApiResponse::error('Mobile number is already verified.', null, 409);
        }

        $otp = $this->otpService->generate($validated['mobile']);
        $this->otpService->deliver($validated['mobile'], $otp, $user->email);

        $response = ['mobile' => $validated['mobile']];

        if ($this->otpService->shouldExposeInResponse()) {
            $response['otp'] = $otp;
        }

        return ApiResponse::success($response, 'A new OTP has been sent to your mobile number.');
    }
}
