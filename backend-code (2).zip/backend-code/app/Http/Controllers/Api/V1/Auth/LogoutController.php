<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Auth;

use App\Http\Controllers\Controller;
use App\Support\ApiResponse;
use Illuminate\Http\Request;

class LogoutController extends Controller
{
    public function logout(Request $request)
    {
        try {
            // Revoke the current token
            $request->user()->currentAccessToken()->delete();

            return ApiResponse::success(null, 'Logout successful.', 200);
        } catch (\Exception $e) {
            return ApiResponse::error('Logout failed: '.$e->getMessage(), null, 500);
        }
    }
}
