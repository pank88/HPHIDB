<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Auth;

use App\Constants\UserRole;
use App\Constants\UserStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Models\User;
use App\Support\ApiResponse;
use Illuminate\Support\Facades\Hash;

class LoginController extends Controller
{
    public function login(LoginRequest $request)
    {
        try {
            $validated = $request->validated();

            // Find user by email or mobile
            $user = User::where('email', $validated['login'])
                ->orWhere('phone', $validated['login'])
                ->first();

            if (! $user) {
                return ApiResponse::error('Invalid credentials provided.', null, 401);
            }

            // Check if password is correct
            if (! Hash::check($validated['password'], $user->password)) {
                return ApiResponse::error('Invalid credentials provided.', null, 401);
            }

            // Check if user is suspended
            if ($user->status === UserStatus::SUSPENDED) {
                return ApiResponse::error('Your account has been suspended. Please contact support.', null, 403);
            }

            // Generate token
            $token = $user->createToken('auth_token')->plainTextToken;

            return ApiResponse::success([
                'user' => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'mobile' => $user->phone,
                    'role' => $user->role,
                    'role_label' => UserRole::label($user->role),
                    'status' => $user->status,
                    'status_label' => UserStatus::label($user->status),
                ],
                'token' => $token,
            ], 'Login successful.', 200);
        } catch (\Exception $e) {
            return ApiResponse::error('Login failed: '.$e->getMessage(), null, 500);
        }
    }
}
