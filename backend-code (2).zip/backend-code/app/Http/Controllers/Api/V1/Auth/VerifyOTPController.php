<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Auth;

use App\Constants\UserRole;
use App\Constants\UserStatus;
use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\VerifyOTPRequest;
use App\Models\User;
use App\Services\OtpService;
use App\Support\ApiResponse;

class VerifyOTPController extends Controller
{
    public function __construct(private readonly OtpService $otpService) {}

    public function verify(VerifyOTPRequest $request)
    {
        try {
            $validated = $request->validated();

            $result = $this->otpService->verify($validated['mobile'], $validated['otp']);

            if (! $result['ok']) {
                return ApiResponse::error($result['message'], null, $result['code']);
            }

            $user = User::where('phone', $validated['mobile'])->first();

            if (! $user) {
                return ApiResponse::error('User not found.', null, 404);
            }

            $user->update([
                'phone_verified_at' => now(),
                'status' => UserStatus::ACTIVE,
            ]);

            $token = $user->createToken('auth_token')->plainTextToken;

            return ApiResponse::success([
                'user' => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'mobile' => $user->phone,
                    'role' => $user->role,
                    'role_label' => UserRole::label($user->role),
                    'status' => $user->status,
                    'status_label' => UserStatus::label($user->status),
                ],
                'token' => $token,
            ], 'OTP verified successfully.', 200);
        } catch (\Exception $e) {
            return ApiResponse::error('OTP verification failed: '.$e->getMessage(), null, 500);
        }
    }
}
