<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\Match\SendMessageRequest;
use App\Http\Resources\MatchResource;
use App\Http\Resources\MessageResource;
use App\Http\Resources\ProfileResource;
use App\Models\UserMatch;
use App\Services\MatchService;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;

class MatchController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [
            new Middleware('auth:sanctum'),
        ];
    }

    protected MatchService $matchService;

    public function __construct(MatchService $matchService)
    {
        $this->matchService = $matchService;
    }

    /**
     * Get user's matches
     */
    public function getMatches(Request $request): JsonResponse
    {
        try {
            $user = $request->user();
            $activeOnly = $request->query('active_only', true);
            $page = $request->query('page', 1);

            $matches = $this->matchService->getMatches(
                user: $user,
                activeOnly: filter_var($activeOnly, FILTER_VALIDATE_BOOLEAN),
                page: (int) $page
            );

            return response()->json([
                'success' => true,
                'data' => MatchResource::collection($matches),
                'pagination' => [
                    'current_page' => $matches->currentPage(),
                    'per_page' => $matches->perPage(),
                    'total' => $matches->total(),
                    'last_page' => $matches->lastPage(),
                ],
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch matches',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Get specific match
     */
    public function showMatch(Request $request, UserMatch $match): JsonResponse
    {
        try {
            $user = $request->user();

            // Authorize
            $this->authorize('view', $match);

            $matchWithDetails = $this->matchService->getMatch($user, $match);

            return response()->json([
                'success' => true,
                'data' => new MatchResource($matchWithDetails),
            ]);
        } catch (AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage() !== '' ? $e->getMessage() : 'Forbidden',
            ], 403);
        } catch (\InvalidArgumentException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 403);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch match',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Get matched profile
     */
    public function getMatchedProfile(Request $request, UserMatch $match): JsonResponse
    {
        try {
            $user = $request->user();

            // Authorize
            $this->authorize('view', $match);

            $profile = $this->matchService->getMatchedProfile($match, $user);

            return response()->json([
                'success' => true,
                'data' => new ProfileResource($profile),
            ]);
        } catch (AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage() !== '' ? $e->getMessage() : 'Forbidden',
            ], 403);
        } catch (\InvalidArgumentException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 403);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch profile',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Block match
     */
    public function blockMatch(Request $request, UserMatch $match): JsonResponse
    {
        try {
            $user = $request->user();

            // Authorize
            $this->authorize('block', $match);

            $blockedMatch = $this->matchService->blockMatch($match, $user);

            return response()->json([
                'success' => true,
                'message' => 'Match blocked successfully',
                'data' => new MatchResource($blockedMatch->load([
                    'initiator',
                    'matcher',
                    'blockedByUser',
                ])),
            ]);
        } catch (AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage() !== '' ? $e->getMessage() : 'Forbidden',
            ], 403);
        } catch (\InvalidArgumentException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to block match',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Unblock match
     */
    public function unblockMatch(Request $request, UserMatch $match): JsonResponse
    {
        try {
            $user = $request->user();

            // Authorize
            $this->authorize('unblock', $match);

            $unblockedMatch = $this->matchService->unblockMatch($match, $user);

            return response()->json([
                'success' => true,
                'message' => 'Match unblocked successfully',
                'data' => new MatchResource($unblockedMatch->load([
                    'initiator',
                    'matcher',
                ])),
            ]);
        } catch (AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage() !== '' ? $e->getMessage() : 'Forbidden',
            ], 403);
        } catch (\InvalidArgumentException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to unblock match',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Start conversation / Send first message
     */
    public function startConversation(SendMessageRequest $request, UserMatch $match): JsonResponse
    {
        try {
            $user = $request->user();

            // Authorize
            $this->authorize('view', $match);

            $message = $this->matchService->startConversation(
                match: $match,
                initiator: $user,
                message: $request->input('body')
            );

            return response()->json([
                'success' => true,
                'message' => 'Message sent successfully',
                'data' => new MessageResource($message->load(['sender', 'conversation'])),
            ], 201);
        } catch (AuthorizationException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage() !== '' ? $e->getMessage() : 'Forbidden',
            ], 403);
        } catch (\InvalidArgumentException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 400);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to send message',
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
