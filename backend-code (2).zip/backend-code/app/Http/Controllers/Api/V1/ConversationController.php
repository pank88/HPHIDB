<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\ConversationResource;
use App\Http\Resources\MessageResource;
use App\Models\Conversation;
use App\Services\MessageService;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\Response;

class ConversationController extends Controller
{
    protected MessageService $messageService;

    public function __construct(MessageService $messageService)
    {
        $this->messageService = $messageService;
    }

    /**
     * Get all conversations for authenticated user
     */
    public function getConversations(Request $request): AnonymousResourceCollection
    {
        $user = $request->user();

        $conversations = Conversation::active()
            ->where(function ($query) use ($user) {
                $query->where('initiator_id', $user->id)
                    ->orWhere('participant_id', $user->id);
            })
            ->with(['initiator', 'participant', 'messages.sender', 'match'])
            ->orderByLatest()
            ->paginate(20);

        return ConversationResource::collection($conversations);
    }

    /**
     * Show a specific conversation with messages
     */
    public function showConversation(Request $request, Conversation $conversation): array
    {
        $user = $request->user();

        // Check authorization
        if (! ($conversation->initiator_id === $user->id || $conversation->participant_id === $user->id)) {
            abort(Response::HTTP_FORBIDDEN);
        }

        $messages = $conversation->messages()
            ->visible()
            ->ordered()
            ->with('sender')
            ->paginate(50);

        return [
            'conversation' => new ConversationResource($conversation),
            'messages' => [
                'data' => $messages->items(),
                'pagination' => [
                    'current_page' => $messages->currentPage(),
                    'last_page' => $messages->lastPage(),
                    'per_page' => $messages->perPage(),
                    'total' => $messages->total(),
                ],
            ],
        ];
    }

    /**
     * Get paginated messages for a conversation
     */
    public function getConversationMessages(Request $request, Conversation $conversation)
    {
        $user = $request->user();

        // Check authorization
        if (! ($conversation->initiator_id === $user->id || $conversation->participant_id === $user->id)) {
            abort(Response::HTTP_FORBIDDEN);
        }

        $beforeId = $request->filled('before_id') ? (int) $request->query('before_id') : null;
        $limit = (int) $request->query('limit', 50);

        $messages = $this->messageService->getConversationMessages($conversation, $beforeId, $limit);

        return [
            'data' => MessageResource::collection($messages),
            'count' => $messages->count(),
        ];
    }

    /**
     * Mark conversation as read
     */
    public function markConversationAsRead(Request $request, Conversation $conversation): array
    {
        $user = $request->user();

        // Check authorization
        if (! ($conversation->initiator_id === $user->id || $conversation->participant_id === $user->id)) {
            abort(Response::HTTP_FORBIDDEN);
        }

        $conversation = $this->messageService->markConversationAsRead($user, $conversation);

        return [
            'success' => true,
            'conversation' => new ConversationResource($conversation),
        ];
    }

    /**
     * Delete (soft delete) a conversation
     */
    public function deleteConversation(Request $request, Conversation $conversation): Response
    {
        $user = $request->user();

        // Check authorization
        if (! ($conversation->initiator_id === $user->id || $conversation->participant_id === $user->id)) {
            abort(Response::HTTP_FORBIDDEN);
        }

        $conversation->delete();

        return response()->noContent();
    }
}
