<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Photo;
use App\Services\SecurePhotoService;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;
use Illuminate\Support\Facades\Log;
use Intervention\Image\Drivers\Gd\Driver;
use Intervention\Image\ImageManager;

class PhotoViewController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [
            new Middleware('throttle:photo-download'),
        ];
    }

    protected SecurePhotoService $photoService;

    public function __construct(SecurePhotoService $photoService)
    {
        $this->photoService = $photoService;
    }

    /**
     * View full photo with signed URL. `expires` is appended as a query
     * string by SecurePhotoService::route() since the route URI only
     * declares {photoId}/{token} — it must be read from the query, not
     * bound as a positional argument.
     */
    public function view(Request $request, int $photoId, string $token): Response
    {
        $expires = (int) $request->query('expires');

        try {
            $photo = Photo::findOrFail($photoId);

            if (! $this->photoService->verifySignedUrl($photoId, $token, $expires)) {
                return response('Unauthorized', 401);
            }

            $content = $this->photoService->getPhotoContent($photo);

            return response($content)
                ->header('Content-Type', $photo->mime_type)
                ->header('Cache-Control', 'private, max-age=900'); // 15 minutes
        } catch (ModelNotFoundException $e) {
            return response('Photo not found', 404);
        } catch (\Exception $e) {
            Log::error('Photo view failed', ['photo_id' => $photoId, 'exception' => $e]);

            return response('Failed to retrieve photo', 500);
        }
    }

    /**
     * View photo thumbnail with signed URL. See view() for why `expires`
     * comes from the query string.
     */
    public function thumb(Request $request, int $photoId, string $token): Response
    {
        $expires = (int) $request->query('expires');

        try {
            $photo = Photo::findOrFail($photoId);

            if (! $this->photoService->verifySignedUrl($photoId, $token, $expires)) {
                return response('Unauthorized', 401);
            }

            $content = $this->photoService->getPhotoContent($photo);

            if (config('photo-storage.thumbnails.enabled', true)) {
                try {
                    $width = config('photo-storage.thumbnails.width', 300);
                    $height = config('photo-storage.thumbnails.height', 300);
                    $quality = config('photo-storage.thumbnails.quality', 80);

                    $manager = new ImageManager(new Driver);
                    $image = $manager->read($content)->cover($width, $height);

                    $content = (string) match ($photo->mime_type) {
                        'image/png' => $image->toPng(),
                        default => $image->toJpeg($quality),
                    };
                } catch (\Exception $e) {
                    Log::warning('Thumbnail generation failed, returning original', [
                        'photo_id' => $photoId,
                        'exception' => $e,
                    ]);
                }
            }

            return response($content)
                ->header('Content-Type', $photo->mime_type)
                ->header('Cache-Control', 'private, max-age=900'); // 15 minutes
        } catch (ModelNotFoundException $e) {
            return response('Photo not found', 404);
        } catch (\Exception $e) {
            Log::error('Photo thumb failed', ['photo_id' => $photoId, 'exception' => $e]);

            return response('Failed to retrieve photo', 500);
        }
    }
}
