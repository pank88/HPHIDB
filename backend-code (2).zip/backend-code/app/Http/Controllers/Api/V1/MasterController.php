<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Constants\BookingStatus;
use App\Constants\InterestStatus;
use App\Constants\MaritalStatus;
use App\Constants\UserStatus;
use App\Http\Controllers\Controller;
use App\Models\Caste;
use App\Models\City;
use App\Models\Country;
use App\Models\Education;
use App\Models\Gotra;
use App\Models\Hobby;
use App\Models\IncomeLevel;
use App\Models\Occupation;
use App\Models\Religion;
use App\Models\ServiceCategory;
use App\Models\State;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class MasterController extends Controller
{
    private array $validTypes = [
        'religions',
        'castes',
        'gotras',
        'educations',
        'occupations',
        'hobbies',
        'countries',
        'states',
        'cities',
        'income-levels',
        'service-categories',
    ];

    /**
     * Get specific master data
     */
    public function getMaster(Request $request, string $type): JsonResponse
    {
        if (! in_array($type, $this->validTypes)) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid master type',
            ], 400);
        }

        try {
            $filter = $this->resolveFilter($request, $type);

            if ($filter !== null) {
                // Filtered lookups (cascading dropdowns) are cheap indexed queries; skip caching
                // so admin master-data writes never serve stale filtered results.
                $data = $this->fetchMasterData($type, $filter);
            } else {
                $data = Cache::remember("masters.{$type}", now()->addHours(24), function () use ($type) {
                    return $this->fetchMasterData($type);
                });
            }

            return response()->json([
                'success' => true,
                'data' => $data,
                'type' => $type,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch master data',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Get all masters
     */
    public function getAllMasters(): JsonResponse
    {
        try {
            $cacheKey = 'masters.all';
            $data = Cache::remember($cacheKey, now()->addHours(24), function () {
                $allMasters = [];
                foreach ($this->validTypes as $type) {
                    $allMasters[$type] = $this->fetchMasterData($type);
                }

                return $allMasters;
            });

            return response()->json([
                'success' => true,
                'data' => $data,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch master data',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Get all coded lists (Constants-backed enums) as [{value, label}] arrays.
     */
    public function getCodedLists(): JsonResponse
    {
        try {
            $cacheKey = 'masters.coded-lists';
            $data = Cache::remember($cacheKey, now()->addDays(7), function () {
                return [
                    // These four are string-valued to match profiles' actual
                    // column types (enum/varchar) and the FormRequest `in:`
                    // rules that validate against them — NOT the numeric
                    // Gender/Complexion/FoodType/CreatedFor Constants classes,
                    // which don't correspond to any DB column here.
                    'gender' => [
                        ['value' => 'male', 'label' => 'Male'],
                        ['value' => 'female', 'label' => 'Female'],
                        ['value' => 'other', 'label' => 'Other'],
                    ],
                    'complexion' => [
                        ['value' => 'fair', 'label' => 'Fair'],
                        ['value' => 'very_fair', 'label' => 'Very Fair'],
                        ['value' => 'wheatish', 'label' => 'Wheatish'],
                        ['value' => 'wheatish_brown', 'label' => 'Wheatish Brown'],
                        ['value' => 'brown', 'label' => 'Brown'],
                        ['value' => 'dark_brown', 'label' => 'Dark Brown'],
                    ],
                    'food_type' => [
                        ['value' => 'veg', 'label' => 'Vegetarian'],
                        ['value' => 'non_veg', 'label' => 'Non-Vegetarian'],
                        ['value' => 'both', 'label' => 'Both'],
                        ['value' => 'jain', 'label' => 'Jain'],
                    ],
                    'created_for' => [
                        ['value' => 'self', 'label' => 'Self'],
                        ['value' => 'son', 'label' => 'Son'],
                        ['value' => 'daughter', 'label' => 'Daughter'],
                        ['value' => 'brother', 'label' => 'Brother'],
                        ['value' => 'sister', 'label' => 'Sister'],
                        ['value' => 'friend', 'label' => 'Friend'],
                    ],
                    // Numeric: profiles.marital_status is a real tinyint column.
                    'marital_status' => $this->toValueLabel(MaritalStatus::labels()),
                    'user_status' => $this->toValueLabel(UserStatus::labels()),
                    'interest_status' => $this->toValueLabel(InterestStatus::labels()),
                    'booking_status' => $this->toValueLabel(BookingStatus::labels()),
                    'income' => IncomeLevel::query()
                        ->where('status', 1)
                        ->orderBy('sort_order')
                        ->get()
                        ->map(fn (IncomeLevel $level) => ['value' => $level->id, 'label' => $level->label])
                        ->values()
                        ->toArray(),
                ];
            });

            return response()->json([
                'success' => true,
                'data' => $data,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to fetch coded lists',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Convert a Constants labels() map into a [{value, label}] list.
     */
    private function toValueLabel(array $labels): array
    {
        $list = [];

        foreach ($labels as $value => $label) {
            $list[] = ['value' => $value, 'label' => $label];
        }

        return $list;
    }

    /**
     * Resolve the supported query-param filter for a master type.
     *
     * @return array{0: string, 1: int}|null [column, value]
     */
    private function resolveFilter(Request $request, string $type): ?array
    {
        if ($type === 'states' && $request->filled('country_id')) {
            return ['country_id', (int) $request->query('country_id')];
        }

        if ($type === 'cities' && $request->filled('state_id')) {
            return ['state_id', (int) $request->query('state_id')];
        }

        return null;
    }

    /**
     * Fetch master data from database
     */
    private function fetchMasterData(string $type, ?array $filter = null): array
    {
        $query = match ($type) {
            'religions' => Religion::select('id', 'name')->orderBy('name'),
            'castes' => Caste::select('id', 'name', 'religion_id')->orderBy('name'),
            'gotras' => Gotra::select('id', 'name')->orderBy('name'),
            // educations has no `name` column — `level` ("12th Pass", "MBA", ...)
            // is the display value; aliased so callers get the usual {id,name} shape.
            'educations' => Education::select('id', 'level as name', 'field_of_study')->orderBy('level'),
            'occupations' => Occupation::select('id', 'name')->orderBy('name'),
            'hobbies' => Hobby::select('id', 'name', 'category')->orderBy('name'),
            'countries' => Country::select('id', 'name', 'code')->orderBy('name'),
            'states' => State::select('id', 'name', 'country_id')->orderBy('name'),
            'cities' => City::select('id', 'name', 'state_id')->orderBy('name'),
            'income-levels' => IncomeLevel::select('id', 'label', 'min_amount', 'max_amount', 'sort_order')->orderBy('sort_order'),
            'service-categories' => ServiceCategory::select('id', 'name')->orderBy('name'),
            default => null,
        };

        if ($query === null) {
            return [];
        }

        if ($filter !== null) {
            $query->where($filter[0], $filter[1]);
        }

        return $query->get()->toArray();
    }
}
