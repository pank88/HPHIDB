<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Events\UserStoppedTyping;
use App\Events\UserTyping;
use App\Http\Controllers\Controller;
use App\Http\Requests\Message\SendMessageRequest;
use App\Http\Requests\Message\UploadMediaRequest;
use App\Http\Resources\MessageResource;
use App\Models\Conversation;
use App\Models\Message;
use App\Services\MessageService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class MessageController extends Controller
{
    protected MessageService $messageService;

    public function __construct(MessageService $messageService)
    {
        $this->messageService = $messageService;
    }

    /**
     * Send a message
     */
    public function sendMessage(SendMessageRequest $request): array
    {
        $user = $request->user();
        $validated = $request->validated();

        $conversation = Conversation::findOrFail($validated['conversation_id']);

        // Check authorization
        if (! ($conversation->initiator_id === $user->id || $conversation->participant_id === $user->id)) {
            abort(Response::HTTP_FORBIDDEN);
        }

        $message = $this->messageService->sendMessage(
            $user,
            $conversation,
            $validated['body'] ?? '',
            $validated['type'] ?? 'text',
            $request->file('media')
        );

        return [
            'success' => true,
            'message' => new MessageResource($message),
        ];
    }

    /**
     * Update a message
     */
    public function updateMessage(Request $request, Message $message): array
    {
        $user = $request->user();
        $validated = $request->validate([
            'body' => 'required|string|min:1|max:5000',
        ]);

        // Check authorization
        if ($message->sender_id !== $user->id) {
            abort(Response::HTTP_FORBIDDEN);
        }

        $updatedMessage = $this->messageService->editMessage($user, $message, $validated['body']);

        return [
            'success' => true,
            'message' => new MessageResource($updatedMessage),
        ];
    }

    /**
     * Delete a message
     */
    public function deleteMessage(Request $request, Message $message): Response
    {
        $user = $request->user();

        // Check authorization
        if ($message->sender_id !== $user->id) {
            abort(Response::HTTP_FORBIDDEN);
        }

        $this->messageService->deleteMessage($user, $message);

        return response()->noContent();
    }

    /**
     * Mark a specific message as read
     */
    public function markMessageAsRead(Request $request, Message $message): array
    {
        $user = $request->user();

        // Check authorization (only non-sender can mark as read)
        if ($message->sender_id === $user->id) {
            abort(Response::HTTP_FORBIDDEN);
        }

        $message->markAsRead();

        return [
            'success' => true,
            'message' => new MessageResource($message),
        ];
    }

    /**
     * Broadcast typing indicator
     */
    public function startTyping(Request $request, Conversation $conversation): JsonResponse
    {
        $user = $request->user();

        // Check authorization
        if (! ($conversation->initiator_id === $user->id || $conversation->participant_id === $user->id)) {
            abort(Response::HTTP_FORBIDDEN);
        }

        event(new UserTyping($conversation, $user));

        return response()->json(['status' => 'typing']);
    }

    /**
     * Broadcast stopped typing indicator
     */
    public function stopTyping(Request $request, Conversation $conversation): JsonResponse
    {
        $user = $request->user();

        // Check authorization
        if (! ($conversation->initiator_id === $user->id || $conversation->participant_id === $user->id)) {
            abort(Response::HTTP_FORBIDDEN);
        }

        event(new UserStoppedTyping($conversation, $user));

        return response()->json(['status' => 'stopped']);
    }

    /**
     * Upload media for chat
     */
    public function uploadMedia(UploadMediaRequest $request): array
    {
        $user = $request->user();
        $validated = $request->validated();

        $uploadedMedia = $this->messageService->uploadChatMedia($validated['media'], $user);

        return [
            'success' => true,
            'media' => $uploadedMedia,
        ];
    }
}
