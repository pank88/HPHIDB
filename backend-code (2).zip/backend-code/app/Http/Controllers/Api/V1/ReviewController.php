<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\CreateReviewRequest;
use App\Http\Resources\ReviewResource;
use App\Models\Booking;
use App\Models\Review;
use App\Models\ReviewHelpful;
use App\Models\Vendor;
use App\Services\ReviewService;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Routing\Controllers\HasMiddleware;
use Illuminate\Routing\Controllers\Middleware;

class ReviewController extends Controller implements HasMiddleware
{
    public static function middleware(): array
    {
        return [
            new Middleware('auth:sanctum', only: ['store', 'respondToReview', 'markHelpful']),
            new Middleware('throttle:50,1', only: ['store']),
        ];
    }

    public function __construct(private ReviewService $reviewService) {}

    public function store(CreateReviewRequest $request): JsonResponse
    {
        $booking = Booking::findOrFail($request->validated('booking_id'));

        $review = $this->reviewService->createReview(
            $request->user(),
            $booking,
            $request->validated()
        );

        return (new ReviewResource($review))->response()->setStatusCode(201);
    }

    public function getVendorReviews(Vendor $vendor, Request $request): JsonResponse
    {
        $rating = $request->filled('rating') ? (int) $request->query('rating') : null;
        $page = (int) $request->query('page', 1);

        $reviews = $this->reviewService->getVendorReviews($vendor, $rating, $page);

        return response()->json(ReviewResource::collection($reviews)->response()->getData());
    }

    public function respondToReview(Review $review, Request $request): JsonResponse
    {
        if (! $request->user()->vendor || $request->user()->vendor->id !== $review->vendor_id) {
            throw new AuthorizationException('Unauthorized');
        }

        $request->validate([
            'response' => 'required|string|max:1000',
        ]);

        $updatedReview = $this->reviewService->respondToReview(
            $request->user()->vendor,
            $review,
            $request->string('response')->toString()
        );

        return (new ReviewResource($updatedReview))->response();
    }

    public function markHelpful(Review $review, Request $request): JsonResponse
    {
        $user = $request->user();

        $helpful = ReviewHelpful::where('review_id', $review->id)
            ->where('user_id', $user->id)
            ->first();

        if ($helpful) {
            $helpful->delete();
            $review->decrement('helpful_count');
        } else {
            ReviewHelpful::create([
                'review_id' => $review->id,
                'user_id' => $user->id,
            ]);
            $review->increment('helpful_count');
        }

        return response()->json(null, 204);
    }
}
