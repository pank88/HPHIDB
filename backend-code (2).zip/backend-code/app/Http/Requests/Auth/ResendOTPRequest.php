<?php

declare(strict_types=1);

namespace App\Http\Requests\Auth;

use Illuminate\Foundation\Http\FormRequest;

class ResendOTPRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'mobile' => ['required', 'string', 'max:20', 'exists:users,phone'],
        ];
    }

    public function messages(): array
    {
        return [
            'mobile.required' => 'Mobile number is required',
            'mobile.exists' => 'Mobile number not found',
        ];
    }
}
