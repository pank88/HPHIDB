<?php

declare(strict_types=1);

namespace App\Http\Requests\Auth;

use Illuminate\Foundation\Http\FormRequest;

class VerifyOTPRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'mobile' => ['required', 'string', 'max:20', 'exists:users,phone'],
            'otp' => ['required', 'string', 'digits:6'],
        ];
    }

    public function messages(): array
    {
        return [
            'mobile.required' => 'Mobile number is required',
            'mobile.exists' => 'Mobile number not found',
            'otp.required' => 'OTP is required',
            'otp.digits' => 'OTP must be exactly 6 digits',
        ];
    }
}
