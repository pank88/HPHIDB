<?php

declare(strict_types=1);

namespace App\Http\Requests\Match;

use Illuminate\Foundation\Http\FormRequest;

class SendMessageRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'body' => ['required', 'string', 'min:1', 'max:1000'],
        ];
    }

    public function messages(): array
    {
        return [
            'body.required' => 'Message is required',
            'body.min' => 'Message cannot be empty',
            'body.max' => 'Message cannot exceed 1000 characters',
        ];
    }
}
