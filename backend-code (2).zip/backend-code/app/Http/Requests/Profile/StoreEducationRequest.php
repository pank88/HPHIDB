<?php

declare(strict_types=1);

namespace App\Http\Requests\Profile;

use Illuminate\Foundation\Http\FormRequest;

class StoreEducationRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'education_id' => ['required', 'integer', 'exists:educations,id'],
            'specialization' => ['nullable', 'string', 'max:255'],
            'institute' => ['nullable', 'string', 'max:255'],
            'is_highest' => ['boolean'],
        ];
    }

    public function messages(): array
    {
        return [
            'education_id.required' => 'Education level is required',
            'education_id.exists' => 'Invalid education level',
        ];
    }
}
