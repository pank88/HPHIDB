<?php

declare(strict_types=1);

namespace App\Http\Requests\Profile;

use Illuminate\Foundation\Http\FormRequest;

class UpdateHobbiesRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'hobby_ids' => ['nullable', 'array'],
            'hobby_ids.*' => ['integer', 'exists:hobbies,id'],
        ];
    }

    public function messages(): array
    {
        return [
            'hobby_ids.*.exists' => 'Invalid hobby selected',
        ];
    }

    public function prepareForValidation(): void
    {
        if ($this->has('hobby_ids') && is_string($this->hobby_ids)) {
            $this->merge(['hobby_ids' => json_decode($this->hobby_ids, true) ?? []]);
        }
    }
}
