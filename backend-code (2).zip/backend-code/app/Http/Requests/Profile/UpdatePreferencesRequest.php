<?php

declare(strict_types=1);

namespace App\Http\Requests\Profile;

use Illuminate\Foundation\Http\FormRequest;

class UpdatePreferencesRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'age_min' => ['nullable', 'integer', 'min:18', 'max:100'],
            'age_max' => ['nullable', 'integer', 'min:18', 'max:100'],
            'height_min_cm' => ['nullable', 'integer', 'min:100', 'max:250'],
            'height_max_cm' => ['nullable', 'integer', 'min:100', 'max:250'],
            'religion_id' => ['nullable', 'integer', 'exists:religions,id'],
            'caste_ids' => ['nullable', 'array'],
            'caste_ids.*' => ['integer', 'exists:castes,id'],
            'complexions' => ['nullable', 'array'],
            'complexions.*' => ['in:fair,very_fair,wheatish,wheatish_brown,brown,dark_brown'],
            'food_types' => ['nullable', 'array'],
            'food_types.*' => ['in:veg,non_veg,both,jain'],
            'hobby_ids' => ['nullable', 'array'],
            'hobby_ids.*' => ['integer', 'exists:hobbies,id'],
            'city_ids' => ['nullable', 'array'],
            'city_ids.*' => ['integer', 'exists:cities,id'],
            'state_ids' => ['nullable', 'array'],
            'state_ids.*' => ['integer', 'exists:states,id'],
            'education_ids' => ['nullable', 'array'],
            'education_ids.*' => ['integer', 'exists:educations,id'],
            'occupation_ids' => ['nullable', 'array'],
            'occupation_ids.*' => ['integer', 'exists:occupations,id'],
        ];
    }

    public function messages(): array
    {
        return [
            'age_min.min' => 'Minimum age must be at least 18',
            'age_max.min' => 'Maximum age must be at least 18',
            'age_min.max' => 'Minimum age cannot exceed 100',
            'age_max.max' => 'Maximum age cannot exceed 100',
            'height_min_cm.min' => 'Minimum height must be at least 100cm',
            'height_max_cm.min' => 'Maximum height must be at least 100cm',
        ];
    }

    public function prepareForValidation(): void
    {
        // Ensure arrays are properly formatted
        if ($this->has('caste_ids') && is_string($this->caste_ids)) {
            $this->merge(['caste_ids' => json_decode($this->caste_ids, true) ?? []]);
        }
        if ($this->has('hobby_ids') && is_string($this->hobby_ids)) {
            $this->merge(['hobby_ids' => json_decode($this->hobby_ids, true) ?? []]);
        }
        if ($this->has('city_ids') && is_string($this->city_ids)) {
            $this->merge(['city_ids' => json_decode($this->city_ids, true) ?? []]);
        }
        if ($this->has('state_ids') && is_string($this->state_ids)) {
            $this->merge(['state_ids' => json_decode($this->state_ids, true) ?? []]);
        }
        if ($this->has('education_ids') && is_string($this->education_ids)) {
            $this->merge(['education_ids' => json_decode($this->education_ids, true) ?? []]);
        }
        if ($this->has('occupation_ids') && is_string($this->occupation_ids)) {
            $this->merge(['occupation_ids' => json_decode($this->occupation_ids, true) ?? []]);
        }
    }
}
