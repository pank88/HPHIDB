<?php

declare(strict_types=1);

namespace App\Http\Requests\Profile;

use Illuminate\Foundation\Http\FormRequest;

class StoreProfileRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'full_name' => ['required', 'string', 'max:255'],
            'gender' => ['required', 'in:male,female,other'],
            'dob' => [
                'required',
                'date',
                'before:'.now()->subYears(18)->toDateString(),
                'after:'.now()->subYears(70)->toDateString(),
            ],
            'created_for' => ['required', 'in:self,son,daughter,brother,sister,friend'],
            'religion_id' => ['required', 'integer', 'exists:religions,id'],
            'caste_id' => ['nullable', 'integer', 'exists:castes,id'],
            'gotra_id' => ['nullable', 'integer', 'exists:gotras,id'],
            'occupation_id' => ['nullable', 'integer', 'exists:occupations,id'],
            'state_id' => ['nullable', 'integer', 'exists:states,id'],
            'income_level_id' => ['nullable', 'integer', 'exists:income_levels,id'],
            'city_id' => ['nullable', 'integer', 'exists:cities,id'],
            'marital_status' => ['required', 'integer', 'in:1,2,3'],
            'height_cm' => ['nullable', 'integer', 'min:100', 'max:250'],
            'complexion' => [
                'nullable',
                'in:fair,very_fair,wheatish,wheatish_brown,brown,dark_brown',
            ],
            'food_type' => ['nullable', 'in:veg,non_veg,both,jain'],
            'about' => ['nullable', 'string', 'max:1000'],
        ];
    }

    public function messages(): array
    {
        return [
            'full_name.required' => 'Full name is required',
            'gender.required' => 'Gender is required',
            'dob.required' => 'Date of birth is required',
            'dob.before' => 'You must be at least 18 years old',
            'dob.after' => 'Date of birth cannot be more than 70 years ago',
            'created_for.required' => 'Profile created for is required',
            'religion_id.required' => 'Religion is required',
            'marital_status.required' => 'Marital status is required',
        ];
    }
}
