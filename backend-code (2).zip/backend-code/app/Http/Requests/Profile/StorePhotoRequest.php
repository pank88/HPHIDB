<?php

declare(strict_types=1);

namespace App\Http\Requests\Profile;

use Illuminate\Foundation\Http\FormRequest;

class StorePhotoRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $maxSize = config('photo-storage.upload.max_size_mb', 2);
        $formats = implode(',', config('photo-storage.upload.allowed_formats', ['jpg', 'png']));

        return [
            'photo' => [
                'required',
                'image',
                "mimes:{$formats}",
                'max:'.($maxSize * 1024),
                'dimensions:min_width=200,min_height=200',
            ],
            'is_primary' => ['boolean'],
        ];
    }

    public function messages(): array
    {
        $maxSize = config('photo-storage.upload.max_size_mb', 2);

        return [
            'photo.required' => 'Photo is required',
            'photo.image' => 'File must be an image',
            'photo.mimes' => 'Photo must be JPG or PNG format',
            'photo.max' => "Photo must not exceed {$maxSize}MB",
            'photo.dimensions' => 'Photo must be at least 200x200 pixels',
        ];
    }
}
