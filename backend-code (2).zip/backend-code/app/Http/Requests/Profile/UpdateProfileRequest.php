<?php

declare(strict_types=1);

namespace App\Http\Requests\Profile;

use Illuminate\Foundation\Http\FormRequest;

class UpdateProfileRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'full_name' => ['sometimes', 'string', 'max:255'],
            'gender' => ['sometimes', 'in:male,female,other'],
            'dob' => [
                'sometimes',
                'date',
                'before:'.now()->subYears(18)->toDateString(),
                'after:'.now()->subYears(70)->toDateString(),
            ],
            'created_for' => ['sometimes', 'in:self,son,daughter,brother,sister,friend'],
            'religion_id' => ['sometimes', 'integer', 'exists:religions,id'],
            'caste_id' => ['nullable', 'integer', 'exists:castes,id'],
            'gotra_id' => ['nullable', 'integer', 'exists:gotras,id'],
            'occupation_id' => ['nullable', 'integer', 'exists:occupations,id'],
            'state_id' => ['nullable', 'integer', 'exists:states,id'],
            'income_level_id' => ['nullable', 'integer', 'exists:income_levels,id'],
            'city_id' => ['nullable', 'integer', 'exists:cities,id'],
            'marital_status' => ['sometimes', 'integer', 'in:1,2,3'],
            'height_cm' => ['nullable', 'integer', 'min:100', 'max:250'],
            'complexion' => [
                'nullable',
                'in:fair,very_fair,wheatish,wheatish_brown,brown,dark_brown',
            ],
            'food_type' => ['nullable', 'in:veg,non_veg,both,jain'],
            'about' => ['nullable', 'string', 'max:1000'],
        ];
    }

    public function messages(): array
    {
        return [
            'dob.before' => 'You must be at least 18 years old',
            'dob.after' => 'Date of birth cannot be more than 70 years ago',
        ];
    }
}
