<?php

declare(strict_types=1);

namespace App\Http\Requests\Interest;

use Illuminate\Foundation\Http\FormRequest;

class RejectInterestRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'reason' => ['nullable', 'string', 'max:200'],
        ];
    }

    public function messages(): array
    {
        return [
            'reason.max' => 'Reason cannot exceed 200 characters',
        ];
    }
}
