<?php

declare(strict_types=1);

namespace App\Http\Requests\Interest;

use Illuminate\Foundation\Http\FormRequest;

class AcceptInterestRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'interest_id' => ['required', 'integer', 'exists:interest_requests,id'],
        ];
    }

    public function messages(): array
    {
        return [
            'interest_id.required' => 'Interest ID is required',
            'interest_id.exists' => 'Interest not found',
        ];
    }
}
