<?php

declare(strict_types=1);

namespace App\Http\Requests\Interest;

use Illuminate\Foundation\Http\FormRequest;

class BlockInterestRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [];
    }
}
