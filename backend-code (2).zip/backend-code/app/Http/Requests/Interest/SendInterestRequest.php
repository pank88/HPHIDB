<?php

declare(strict_types=1);

namespace App\Http\Requests\Interest;

use App\Models\InterestRequest;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class SendInterestRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'receiver_profile_id' => ['required', 'integer', 'exists:profiles,id'],
            'message' => ['nullable', 'string', 'max:500'],
            'channel' => ['nullable', Rule::in([
                InterestRequest::CHANNEL_APP,
                InterestRequest::CHANNEL_SMS,
                InterestRequest::CHANNEL_EMAIL,
            ])],
        ];
    }

    public function messages(): array
    {
        return [
            'receiver_profile_id.required' => 'Receiver profile is required',
            'receiver_profile_id.exists' => 'Receiver profile not found',
            'message.max' => 'Message cannot exceed 500 characters',
            'channel.in' => 'Invalid notification channel',
        ];
    }
}
