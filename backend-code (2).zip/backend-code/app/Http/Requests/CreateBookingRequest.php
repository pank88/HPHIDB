<?php

declare(strict_types=1);

namespace App\Http\Requests;

use App\Constants\UserRole;
use Carbon\Carbon;
use Illuminate\Foundation\Http\FormRequest;

class CreateBookingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() && $this->user()->role !== UserRole::VENDOR;
    }

    public function rules(): array
    {
        return [
            'vendor_service_id' => 'required|exists:vendor_services,id',
            'service_date' => 'required|date|after_or_equal:'.Carbon::today()->toDateString(),
            'service_time_from' => 'nullable|date_format:H:i',
            'service_time_to' => 'nullable|date_format:H:i|after:service_time_from',
            'location_address' => 'required|string|max:500',
            'location_city_id' => 'required|exists:cities,id',
            'guests_count' => 'nullable|integer|min:1',
            'special_requirements' => 'nullable|string|max:1000',
        ];
    }

    public function messages(): array
    {
        return [
            'vendor_service_id.required' => 'Service is required',
            'vendor_service_id.exists' => 'Selected service does not exist',
            'service_date.required' => 'Service date is required',
            'service_date.after_or_equal' => 'Service date must be today or later',
            'location_address.required' => 'Location address is required',
            'location_city_id.required' => 'City is required',
        ];
    }
}
