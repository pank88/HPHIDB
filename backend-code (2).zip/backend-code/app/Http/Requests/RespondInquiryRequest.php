<?php

declare(strict_types=1);

namespace App\Http\Requests;

use App\Constants\UserRole;
use Illuminate\Foundation\Http\FormRequest;

class RespondInquiryRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() && $this->user()->role === UserRole::VENDOR;
    }

    public function rules(): array
    {
        return [
            'final_amount' => 'required|numeric|min:1',
            'response_notes' => 'nullable|string|max:500',
        ];
    }

    public function messages(): array
    {
        return [
            'final_amount.required' => 'Amount is required',
            'final_amount.min' => 'Amount must be greater than 0',
        ];
    }
}
