<?php

declare(strict_types=1);

namespace App\Http\Requests\Admin;

use App\Services\Admin\MasterDataService;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreMasterRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        /** @var MasterDataService $service */
        $service = app(MasterDataService::class);

        $type = (string) $this->route('type');
        $valid = $service->isValidType($type);
        $table = $valid ? $service->tableName($type) : null;
        $nameColumn = $valid ? $service->nameColumn($type) : 'name';

        return [
            $nameColumn => array_filter([
                'required',
                'string',
                'max:191',
                $table !== null ? Rule::unique($table, $nameColumn) : null,
            ]),
            'description' => ['nullable', 'string', 'max:500'],
            'status' => ['nullable', 'boolean'],
            'code' => ['nullable', 'string', 'max:10'],
            'country_id' => ['nullable', 'integer', 'exists:countries,id'],
            'min_amount' => ['nullable', 'numeric', 'min:0'],
            'max_amount' => ['nullable', 'numeric', 'min:0'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
        ];
    }
}
