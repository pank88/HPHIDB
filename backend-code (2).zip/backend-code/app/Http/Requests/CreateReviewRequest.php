<?php

declare(strict_types=1);

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CreateReviewRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    public function rules(): array
    {
        return [
            'booking_id' => 'required|exists:bookings,id',
            'rating' => 'required|integer|min:1|max:5',
            'title' => 'required|string|max:255',
            'body' => 'required|string|max:2000',
            'punctuality_rating' => 'required|integer|min:1|max:5',
            'communication_rating' => 'required|integer|min:1|max:5',
            'quality_rating' => 'required|integer|min:1|max:5',
            'value_rating' => 'required|integer|min:1|max:5',
            'photos' => 'nullable|array|max:10',
            'photos.*' => 'nullable|url',
        ];
    }

    public function messages(): array
    {
        return [
            'booking_id.required' => 'Booking is required',
            'booking_id.exists' => 'Booking does not exist',
            'rating.required' => 'Overall rating is required',
            'rating.min' => 'Rating must be at least 1 star',
            'rating.max' => 'Rating cannot exceed 5 stars',
            'title.required' => 'Review title is required',
            'body.required' => 'Review text is required',
        ];
    }
}
