<?php

declare(strict_types=1);

namespace App\Http\Requests\Message;

use Illuminate\Foundation\Http\FormRequest;

class SendMessageRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'conversation_id' => [
                'required',
                'integer',
                'exists:conversations,id',
            ],
            'body' => [
                'required_if:type,text',
                'nullable',
                'string',
                'min:1',
                'max:5000',
            ],
            'type' => [
                'nullable',
                'string',
                'in:text,image,file,system',
            ],
            'media' => [
                'nullable',
                'file',
                'max:10240',
                'mimes:jpg,jpeg,png,gif,pdf,doc,docx,xls,xlsx,zip',
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'conversation_id.required' => 'Conversation ID is required.',
            'conversation_id.exists' => 'The selected conversation does not exist.',
            'body.required_if' => 'Message body is required for text messages.',
            'body.min' => 'Message must be at least 1 character.',
            'body.max' => 'Message must not exceed 5000 characters.',
            'type.in' => 'Invalid message type.',
            'media.max' => 'File size must not exceed 10MB.',
            'media.mimes' => 'Invalid file type.',
        ];
    }

    public function validated($key = null, $default = null)
    {
        $data = parent::validated($key, $default);

        if ($key !== null) {
            return $data;
        }

        // Set default type to 'text' if not provided
        if (! isset($data['type'])) {
            $data['type'] = 'text';
        }

        return $data;
    }
}
