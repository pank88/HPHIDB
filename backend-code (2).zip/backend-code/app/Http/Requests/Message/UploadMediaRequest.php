<?php

declare(strict_types=1);

namespace App\Http\Requests\Message;

use Illuminate\Foundation\Http\FormRequest;

class UploadMediaRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'media' => [
                'required',
                'file',
                'max:10240',
                'mimes:jpg,jpeg,png,gif,pdf,doc,docx,xls,xlsx,zip',
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'media.required' => 'Media file is required.',
            'media.file' => 'Media must be a file.',
            'media.max' => 'File size must not exceed 10MB.',
            'media.mimes' => 'File type must be an image or document.',
        ];
    }
}
