<?php

declare(strict_types=1);

namespace App\Http\Requests\Discovery;

use App\Constants\UserRole;
use Illuminate\Foundation\Http\FormRequest;

class RefreshSuggestionsRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth()->check() && auth()->user()->role === UserRole::USER;
    }

    public function rules(): array
    {
        return [
            // Empty body validation - just auth check
        ];
    }
}
