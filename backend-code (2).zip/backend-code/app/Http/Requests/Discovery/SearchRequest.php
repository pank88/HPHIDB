<?php

declare(strict_types=1);

namespace App\Http\Requests\Discovery;

use App\Constants\UserRole;
use Illuminate\Foundation\Http\FormRequest;

class SearchRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth()->check() && auth()->user()->role === UserRole::USER;
    }

    public function rules(): array
    {
        return [
            'age_min' => 'nullable|integer|min:18|max:70',
            'age_max' => 'nullable|integer|min:18|max:70|gte:age_min',
            'height_min' => 'nullable|integer|min:100|max:250',
            'height_max' => 'nullable|integer|min:100|max:250|gte:height_min',
            'religion_id' => 'nullable|exists:religions,id',
            'caste_ids' => 'nullable|array',
            'caste_ids.*' => 'exists:castes,id',
            'gotra_ids' => 'nullable|array',
            'gotra_ids.*' => 'exists:gotras,id',
            'complexions' => 'nullable|array',
            'complexions.*' => 'string|in:fair,very_fair,wheatish,wheatish_brown,brown,dark_brown',
            'food_types' => 'nullable|array',
            'food_types.*' => 'string|in:veg,non_veg,both,jain',
            'education_ids' => 'nullable|array',
            'education_ids.*' => 'exists:educations,id',
            'occupation_ids' => 'nullable|array',
            'occupation_ids.*' => 'exists:occupations,id',
            'state_id' => 'nullable|exists:states,id',
            'city_id' => 'nullable|exists:cities,id',
            'hobby_ids' => 'nullable|array',
            'hobby_ids.*' => 'exists:hobbies,id',
            'profile_completeness_min' => 'nullable|integer|min:0|max:100',
            'photos_min' => 'nullable|integer|min:0',
            'sort_by' => 'nullable|string|in:compatibility,recent,completeness,photos',
            'page' => 'nullable|integer|min:1',
        ];
    }

    public function messages(): array
    {
        return [
            'age_min.min' => 'Minimum age must be at least 18',
            'age_min.max' => 'Minimum age must not exceed 70',
            'age_max.min' => 'Maximum age must be at least 18',
            'age_max.max' => 'Maximum age must not exceed 70',
            'age_max.gte' => 'Maximum age must be greater than or equal to minimum age',
            'height_min.min' => 'Minimum height must be at least 100 cm',
            'height_min.max' => 'Minimum height must not exceed 250 cm',
            'height_max.min' => 'Maximum height must be at least 100 cm',
            'height_max.max' => 'Maximum height must not exceed 250 cm',
            'height_max.gte' => 'Maximum height must be greater than or equal to minimum height',
            'religion_id.exists' => 'Selected religion does not exist',
            'caste_ids.*.exists' => 'One or more selected castes do not exist',
            'gotra_ids.*.exists' => 'One or more selected gotras do not exist',
            'complexions.*.in' => 'Invalid complexion value',
            'food_types.*.in' => 'Invalid food type value',
            'education_ids.*.exists' => 'One or more selected educations do not exist',
            'occupation_ids.*.exists' => 'One or more selected occupations do not exist',
            'state_id.exists' => 'Selected state does not exist',
            'city_id.exists' => 'Selected city does not exist',
            'hobby_ids.*.exists' => 'One or more selected hobbies do not exist',
            'profile_completeness_min.min' => 'Minimum profile completeness must be at least 0%',
            'profile_completeness_min.max' => 'Minimum profile completeness must not exceed 100%',
            'sort_by.in' => 'Invalid sort option',
            'page.min' => 'Page number must be at least 1',
        ];
    }

    public function validated($key = null, $default = null)
    {
        $validated = parent::validated($key, $default);

        // Remove null values to simplify filter application
        if (is_array($validated)) {
            return array_filter($validated, fn ($value) => $value !== null);
        }

        return $validated;
    }
}
