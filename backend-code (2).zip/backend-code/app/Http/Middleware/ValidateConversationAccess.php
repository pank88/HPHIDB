<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ValidateConversationAccess
{
    public function handle(Request $request, Closure $next): Response
    {
        $conversation = $request->route('conversation');
        $user = $request->user();

        if (! $conversation || ! $user) {
            return response()->json(['error' => 'Unauthorized'], Response::HTTP_UNAUTHORIZED);
        }

        // Check if user is a participant in the conversation
        if ($conversation->initiator_id !== $user->id && $conversation->participant_id !== $user->id) {
            return response()->json(['error' => 'Forbidden'], Response::HTTP_FORBIDDEN);
        }

        return $next($request);
    }
}
