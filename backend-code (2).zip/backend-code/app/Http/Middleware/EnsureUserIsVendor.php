<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Constants\UserRole;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureUserIsVendor
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if ($user === null || (int) $user->role !== UserRole::VENDOR) {
            abort(403, 'Forbidden. Vendor access required.');
        }

        if ($user->vendor === null) {
            abort(404, 'Vendor profile not found.');
        }

        return $next($request);
    }
}
