<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Constants\UserRole;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureUserIsAdmin
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if ($user === null || (int) $user->role !== UserRole::ADMIN) {
            abort(403, 'Forbidden. Admin access required.');
        }

        return $next($request);
    }
}
