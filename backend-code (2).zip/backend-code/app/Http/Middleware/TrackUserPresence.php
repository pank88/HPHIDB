<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Bumps the authenticated user's last_seen_at on activity, throttled to once
 * a minute per user to avoid a write on every single API request. Nothing
 * previously called PresenceService::updatePresence()/set last_seen_at, so
 * User::isOnline() was permanently false for every user.
 */
class TrackUserPresence
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if ($user && (! $user->last_seen_at || $user->last_seen_at->lt(now()->subMinute()))) {
            $user->timestamps = false;
            $user->update(['last_seen_at' => now()]);
        }

        return $next($request);
    }
}
