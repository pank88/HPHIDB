<?php

declare(strict_types=1);

namespace App\Policies;

use App\Models\Conversation;
use App\Models\User;

class ConversationPolicy
{
    /**
     * Determine if the user can view the conversation
     */
    public function view(User $user, Conversation $conversation): bool
    {
        return $conversation->initiator_id === $user->id || $conversation->participant_id === $user->id;
    }

    /**
     * Determine if the user can delete the conversation
     */
    public function delete(User $user, Conversation $conversation): bool
    {
        return $conversation->initiator_id === $user->id || $conversation->participant_id === $user->id;
    }
}
