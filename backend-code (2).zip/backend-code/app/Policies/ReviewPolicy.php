<?php

declare(strict_types=1);

namespace App\Policies;

use App\Models\Review;
use App\Models\User;

class ReviewPolicy
{
    public function create(User $user, Review $review): bool
    {
        return $review->booking && $review->booking->user_id === $user->id;
    }

    public function respond(User $user, Review $review): bool
    {
        return $user->vendor && $user->vendor->id === $review->vendor_id;
    }
}
