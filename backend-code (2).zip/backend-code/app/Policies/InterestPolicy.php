<?php

declare(strict_types=1);

namespace App\Policies;

use App\Models\InterestRequest;
use App\Models\User;

class InterestPolicy
{
    /**
     * Determine if the user can view the interest
     */
    public function view(User $user, InterestRequest $interest): bool
    {
        return $user->id === $interest->sender_id || $user->id === $interest->receiver_id;
    }

    /**
     * Determine if the user can accept the interest
     */
    public function accept(User $user, InterestRequest $interest): bool
    {
        return $user->id === $interest->receiver_id
            && $interest->status === InterestRequest::STATUS_PENDING
            && $interest->expires_at > now();
    }

    /**
     * Determine if the user can reject the interest
     */
    public function reject(User $user, InterestRequest $interest): bool
    {
        return $user->id === $interest->receiver_id
            && $interest->status === InterestRequest::STATUS_PENDING
            && $interest->expires_at > now();
    }

    /**
     * Determine if the user can block the interest
     */
    public function block(User $user, InterestRequest $interest): bool
    {
        return $user->id === $interest->receiver_id
            && $interest->status === InterestRequest::STATUS_PENDING
            && $interest->expires_at > now();
    }

    /**
     * Determine if the user can delete the interest
     */
    public function delete(User $user, InterestRequest $interest): bool
    {
        return $user->id === $interest->sender_id;
    }
}
