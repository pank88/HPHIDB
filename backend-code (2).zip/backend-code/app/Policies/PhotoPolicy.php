<?php

declare(strict_types=1);

namespace App\Policies;

use App\Models\Photo;
use App\Models\User;

class PhotoPolicy
{
    /**
     * Determine if user can view the photo
     */
    public function view(User $user, Photo $photo): bool
    {
        return $user->id === $photo->user_id;
    }

    /**
     * Determine if user can create a photo
     */
    public function create(User $user): bool
    {
        // Users can upload their own photos
        return true;
    }

    /**
     * Determine if user can update the photo
     */
    public function update(User $user, Photo $photo): bool
    {
        return $user->id === $photo->user_id;
    }

    /**
     * Determine if user can delete the photo
     */
    public function delete(User $user, Photo $photo): bool
    {
        return $user->id === $photo->user_id;
    }
}
