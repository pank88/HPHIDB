<?php

declare(strict_types=1);

namespace App\Policies;

use App\Models\Profile;
use App\Models\User;

class ProfilePolicy
{
    /**
     * Determine if user can view the profile
     */
    public function view(User $user, Profile $profile): bool
    {
        return $user->id === $profile->user_id;
    }

    /**
     * Determine if user can create a profile
     */
    public function create(User $user): bool
    {
        // Users can create their own profile
        return true;
    }

    /**
     * Determine if user can update the profile
     */
    public function update(User $user, Profile $profile): bool
    {
        return $user->id === $profile->user_id;
    }

    /**
     * Determine if user can delete the profile
     */
    public function delete(User $user, Profile $profile): bool
    {
        return $user->id === $profile->user_id;
    }
}
