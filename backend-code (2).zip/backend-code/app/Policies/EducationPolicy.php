<?php

declare(strict_types=1);

namespace App\Policies;

use App\Models\ProfileEducation;
use App\Models\User;

class EducationPolicy
{
    /**
     * Determine if user can view the education
     */
    public function view(User $user, ProfileEducation $education): bool
    {
        return $user->id === $education->user_id;
    }

    /**
     * Determine if user can create an education
     */
    public function create(User $user): bool
    {
        // Users can add their own educations
        return true;
    }

    /**
     * Determine if user can update the education
     */
    public function update(User $user, ProfileEducation $education): bool
    {
        return $user->id === $education->user_id;
    }

    /**
     * Determine if user can delete the education
     */
    public function delete(User $user, ProfileEducation $education): bool
    {
        return $user->id === $education->user_id;
    }
}
