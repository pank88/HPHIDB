<?php

declare(strict_types=1);

namespace App\Policies;

use App\Models\User;
use App\Models\UserMatch;

class MatchPolicy
{
    /**
     * Determine if the user can view the match
     */
    public function view(User $user, UserMatch $match): bool
    {
        return $user->id === $match->initiator_id || $user->id === $match->matcher_id;
    }

    /**
     * Determine if the user can block the match
     */
    public function block(User $user, UserMatch $match): bool
    {
        return ($user->id === $match->initiator_id || $user->id === $match->matcher_id)
            && $match->is_active;
    }

    /**
     * Determine if the user can unblock the match
     */
    public function unblock(User $user, UserMatch $match): bool
    {
        return $user->id === $match->blocked_by_id;
    }
}
