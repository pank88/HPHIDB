<?php

declare(strict_types=1);

namespace App\Policies;

use App\Models\Message;
use App\Models\User;

class MessagePolicy
{
    /**
     * Determine if the user can view the message
     */
    public function view(User $user, Message $message): bool
    {
        // User can view if they are sender, receiver, or admin
        $conversation = $message->conversation;

        return $conversation->initiator_id === $user->id || $conversation->participant_id === $user->id;
    }

    /**
     * Determine if the user can update the message
     */
    public function update(User $user, Message $message): bool
    {
        // Only sender can edit, and only within edit window
        if ($message->sender_id !== $user->id) {
            return false;
        }

        $editWindowMinutes = config('chat.edit_window_minutes', 60);

        return $message->created_at->addMinutes($editWindowMinutes)->isFuture();
    }

    /**
     * Determine if the user can delete the message
     */
    public function delete(User $user, Message $message): bool
    {
        // Only sender can delete, and only within delete window
        if ($message->sender_id !== $user->id) {
            return false;
        }

        $deleteWindowMinutes = config('chat.delete_window_minutes', 1440);

        return $message->created_at->addMinutes($deleteWindowMinutes)->isFuture();
    }
}
