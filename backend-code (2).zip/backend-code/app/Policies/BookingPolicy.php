<?php

declare(strict_types=1);

namespace App\Policies;

use App\Constants\UserRole;
use App\Models\Booking;
use App\Models\User;

class BookingPolicy
{
    public function view(User $user, Booking $booking): bool
    {
        return $user->id === $booking->user_id || ($user->vendor && $user->vendor->id === $booking->vendor_id);
    }

    public function create(User $user): bool
    {
        return $user->role !== UserRole::VENDOR;
    }

    public function respond(User $user, Booking $booking): bool
    {
        return $user->vendor && $user->vendor->id === $booking->vendor_id;
    }

    public function complete(User $user, Booking $booking): bool
    {
        return $user->vendor && $user->vendor->id === $booking->vendor_id;
    }

    public function cancel(User $user, Booking $booking): bool
    {
        return $user->id === $booking->user_id || ($user->vendor && $user->vendor->id === $booking->vendor_id);
    }
}
