<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Constants\UserRole;
use App\Constants\UserStatus;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminUserSeeder extends Seeder
{
    public function run(): void
    {
        User::firstOrCreate(
            ['email' => 'admin@matrimony.test'],
            [
                'name' => 'Platform Admin',
                'password' => Hash::make('Admin@12345'),
                'phone' => '9999999999',
                'role' => UserRole::ADMIN,
                'status' => UserStatus::ACTIVE,
                'email_verified_at' => now(),
            ]
        );
    }
}
