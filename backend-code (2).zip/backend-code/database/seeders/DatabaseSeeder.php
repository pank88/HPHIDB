<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Constants\BookingStatus;
use App\Constants\MatchStatus;
use App\Constants\UserRole;
use App\Models\Booking;
use App\Models\Caste;
use App\Models\City;
use App\Models\Conversation;
use App\Models\Country;
use App\Models\Education;
use App\Models\Gotra;
use App\Models\Hobby;
use App\Models\IncomeLevel;
use App\Models\InterestRequest;
use App\Models\Message;
use App\Models\Occupation;
use App\Models\PartnerPreference;
use App\Models\Profile;
use App\Models\ProfileEducation;
use App\Models\ProfilePhoto;
use App\Models\Religion;
use App\Models\Review;
use App\Models\ServiceCategory;
use App\Models\State;
use App\Models\SuggestedMatch;
use App\Models\User;
use App\Models\UserMatch;
use App\Models\Vendor;
use App\Models\VendorAvailability;
use App\Models\VendorImage;
use App\Models\VendorPackage;
use App\Models\VendorTestimonial;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    public function run(): void
    {
        // Seed Masters First
        $this->seedMasters();

        // Create Admin User
        $this->createAdminUser();

        // Create Demo Users & Profiles
        $this->createDemoProfiles();

        // Create Demo Vendors
        $this->createDemoVendors();

        // Create Demo Interactions
        $this->createDemoInteractions();
    }

    private function seedMasters(): void
    {
        // Seed Religions (5 total)
        $religions = [
            ['name' => 'Hindu', 'description' => 'Hindu religion'],
            ['name' => 'Muslim', 'description' => 'Islamic religion'],
            ['name' => 'Sikh', 'description' => 'Sikh religion'],
            ['name' => 'Christian', 'description' => 'Christian religion'],
            ['name' => 'Jain', 'description' => 'Jain religion'],
        ];

        foreach ($religions as $religion) {
            Religion::create($religion);
        }

        // Seed Castes (Hindu castes)
        $hinduReligion = Religion::where('name', 'Hindu')->first();
        $castes = [
            ['religion_id' => $hinduReligion->id, 'name' => 'Brahmin', 'description' => 'Brahmin caste'],
            ['religion_id' => $hinduReligion->id, 'name' => 'Rajput', 'description' => 'Rajput caste'],
            ['religion_id' => $hinduReligion->id, 'name' => 'Agarwal', 'description' => 'Agarwal caste'],
            ['religion_id' => $hinduReligion->id, 'name' => 'Kayastha', 'description' => 'Kayastha caste'],
            ['religion_id' => $hinduReligion->id, 'name' => 'Jat', 'description' => 'Jat caste'],
            ['religion_id' => $hinduReligion->id, 'name' => 'Yadav', 'description' => 'Yadav caste'],
            ['religion_id' => $hinduReligion->id, 'name' => 'Kurmi', 'description' => 'Kurmi caste'],
            ['religion_id' => $hinduReligion->id, 'name' => 'Maratha', 'description' => 'Maratha caste'],
        ];

        foreach ($castes as $caste) {
            Caste::create($caste);
        }

        // Add few castes for other religions
        $muslimReligion = Religion::where('name', 'Muslim')->first();
        Caste::create(['religion_id' => $muslimReligion->id, 'name' => 'Ansari', 'description' => 'Ansari caste']);
        Caste::create(['religion_id' => $muslimReligion->id, 'name' => 'Syed', 'description' => 'Syed caste']);

        // Seed Gotras (10 total)
        $gotras = [
            ['name' => 'Bharadwaj', 'description' => 'Bharadwaj Gotra'],
            ['name' => 'Kashyap', 'description' => 'Kashyap Gotra'],
            ['name' => 'Vashishtha', 'description' => 'Vashishtha Gotra'],
            ['name' => 'Gautam', 'description' => 'Gautam Gotra'],
            ['name' => 'Atri', 'description' => 'Atri Gotra'],
            ['name' => 'Vatsa', 'description' => 'Vatsa Gotra'],
            ['name' => 'Shandilya', 'description' => 'Shandilya Gotra'],
            ['name' => 'Kaushik', 'description' => 'Kaushik Gotra'],
            ['name' => 'Garg', 'description' => 'Garg Gotra'],
            ['name' => 'Parashar', 'description' => 'Parashar Gotra'],
        ];

        foreach ($gotras as $gotra) {
            Gotra::create($gotra);
        }

        // Seed Educations (10 levels)
        $educations = [
            ['level' => '12th Pass', 'field_of_study' => null, 'description' => 'High School', 'status' => 1],
            ['level' => 'Diploma', 'field_of_study' => null, 'description' => 'Diploma', 'status' => 1],
            ['level' => 'Bachelor\'s', 'field_of_study' => null, 'description' => 'Bachelor\'s Degree', 'status' => 1],
            ['level' => 'Master\'s', 'field_of_study' => null, 'description' => 'Master\'s Degree', 'status' => 1],
            ['level' => 'PhD', 'field_of_study' => null, 'description' => 'Doctor of Philosophy', 'status' => 1],
            ['level' => 'B.Tech', 'field_of_study' => 'Technology', 'description' => 'Bachelor of Technology', 'status' => 1],
            ['level' => 'M.Tech', 'field_of_study' => 'Technology', 'description' => 'Master of Technology', 'status' => 1],
            ['level' => 'MBA', 'field_of_study' => 'Business', 'description' => 'Master of Business Administration', 'status' => 1],
            ['level' => 'BCA', 'field_of_study' => 'Computer Applications', 'description' => 'Bachelor of Computer Applications', 'status' => 1],
            ['level' => 'MCA', 'field_of_study' => 'Computer Applications', 'description' => 'Master of Computer Applications', 'status' => 1],
        ];

        foreach ($educations as $education) {
            Education::create($education);
        }

        // Seed Occupations (15 total)
        $occupations = [
            ['name' => 'Software Engineer', 'category' => 'IT', 'description' => 'Software development professional'],
            ['name' => 'Doctor', 'category' => 'Healthcare', 'description' => 'Medical professional'],
            ['name' => 'Teacher', 'category' => 'Education', 'description' => 'Educational professional'],
            ['name' => 'Accountant', 'category' => 'Finance', 'description' => 'Finance professional'],
            ['name' => 'Lawyer', 'category' => 'Legal', 'description' => 'Legal professional'],
            ['name' => 'Engineer', 'category' => 'Engineering', 'description' => 'Engineering professional'],
            ['name' => 'Businessman', 'category' => 'Business', 'description' => 'Business owner/entrepreneur'],
            ['name' => 'Bank Manager', 'category' => 'Finance', 'description' => 'Banking professional'],
            ['name' => 'Sales Executive', 'category' => 'Sales', 'description' => 'Sales professional'],
            ['name' => 'Government Official', 'category' => 'Government', 'description' => 'Government sector professional'],
            ['name' => 'Architect', 'category' => 'Architecture', 'description' => 'Architecture professional'],
            ['name' => 'Fashion Designer', 'category' => 'Design', 'description' => 'Design professional'],
            ['name' => 'Journalist', 'category' => 'Media', 'description' => 'Media professional'],
            ['name' => 'Chef', 'category' => 'Food & Beverage', 'description' => 'Culinary professional'],
            ['name' => 'Pilot', 'category' => 'Aviation', 'description' => 'Aviation professional'],
        ];

        foreach ($occupations as $occupation) {
            Occupation::create($occupation);
        }

        // Seed Hobbies (15 total)
        $hobbies = [
            ['name' => 'Reading', 'description' => 'Love reading books'],
            ['name' => 'Traveling', 'description' => 'Passionate about traveling'],
            ['name' => 'Cooking', 'description' => 'Enjoy cooking'],
            ['name' => 'Photography', 'description' => 'Photography enthusiast'],
            ['name' => 'Painting', 'description' => 'Art and painting'],
            ['name' => 'Music', 'description' => 'Music lover'],
            ['name' => 'Dancing', 'description' => 'Dance enthusiast'],
            ['name' => 'Sports', 'description' => 'Sports activities'],
            ['name' => 'Yoga', 'description' => 'Yoga and meditation'],
            ['name' => 'Gardening', 'description' => 'Gardening and plants'],
            ['name' => 'Gaming', 'description' => 'Video games'],
            ['name' => 'Movies', 'description' => 'Movie buff'],
            ['name' => 'Hiking', 'description' => 'Hiking and adventure'],
            ['name' => 'Writing', 'description' => 'Writing and blogging'],
            ['name' => 'Volunteering', 'description' => 'Social work and volunteering'],
        ];

        foreach ($hobbies as $hobby) {
            Hobby::create($hobby);
        }

        // Seed Countries (India first)
        $countries = [
            ['name' => 'India', 'code' => 'IN'],
            ['name' => 'United States', 'code' => 'USA'],
            ['name' => 'United Kingdom', 'code' => 'UK'],
            ['name' => 'Canada', 'code' => 'CA'],
            ['name' => 'Australia', 'code' => 'AU'],
        ];

        $indiaId = null;
        foreach ($countries as $country) {
            $created = Country::create($country);
            if ($country['code'] === 'IN') {
                $indiaId = $created->id;
            }
        }

        // Seed Income Levels (annual, INR)
        $incomeLevels = [
            ['label' => 'Lower', 'min_amount' => null, 'max_amount' => 300000, 'sort_order' => 1],
            ['label' => 'Middle', 'min_amount' => 300000, 'max_amount' => 1000000, 'sort_order' => 2],
            ['label' => 'Upper Middle', 'min_amount' => 1000000, 'max_amount' => 2500000, 'sort_order' => 3],
            ['label' => 'High', 'min_amount' => 2500000, 'max_amount' => 10000000, 'sort_order' => 4],
            ['label' => 'Affluent', 'min_amount' => 10000000, 'max_amount' => null, 'sort_order' => 5],
        ];

        foreach ($incomeLevels as $incomeLevel) {
            IncomeLevel::create($incomeLevel);
        }

        // Seed States (Major Indian states)
        $states = [
            ['name' => 'Madhya Pradesh', 'code' => 'MP'],
            ['name' => 'Maharashtra', 'code' => 'MH'],
            ['name' => 'Uttar Pradesh', 'code' => 'UP'],
            ['name' => 'Delhi', 'code' => 'DL'],
            ['name' => 'Rajasthan', 'code' => 'RJ'],
            ['name' => 'Gujarat', 'code' => 'GJ'],
            ['name' => 'Karnataka', 'code' => 'KA'],
            ['name' => 'Tamil Nadu', 'code' => 'TN'],
            ['name' => 'West Bengal', 'code' => 'WB'],
            ['name' => 'Punjab', 'code' => 'PB'],
        ];

        $stateMap = [];
        foreach ($states as $state) {
            $state['country_id'] = $indiaId;
            $stateMap[$state['name']] = State::create($state)->id;
        }

        // Seed Cities for each state
        $citiesData = [
            'Madhya Pradesh' => ['Bhopal', 'Indore', 'Gwalior', 'Jabalpur', 'Ujjain', 'Sagar', 'Rewa', 'Satna'],
            'Maharashtra' => ['Mumbai', 'Pune', 'Nagpur', 'Aurangabad', 'Nashik', 'Thane', 'Kolhapur', 'Amravati'],
            'Uttar Pradesh' => ['Lucknow', 'Kanpur', 'Agra', 'Varanasi', 'Allahabad', 'Meerut', 'Ghaziabad', 'Noida'],
            'Delhi' => ['New Delhi', 'North Delhi', 'South Delhi', 'East Delhi', 'West Delhi', 'Central Delhi'],
            'Rajasthan' => ['Jaipur', 'Jodhpur', 'Udaipur', 'Pushkar', 'Ajmer', 'Bikaner', 'Kota', 'Bhilwara'],
            'Gujarat' => ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot', 'Gandhinagar', 'Bhavnagar', 'Jamnagar', 'Anand'],
        ];

        foreach ($citiesData as $stateName => $cities) {
            $stateId = $stateMap[$stateName];
            foreach ($cities as $cityName) {
                City::create([
                    'state_id' => $stateId,
                    'name' => $cityName,
                    'code' => strtoupper(substr($cityName, 0, 3)),
                ]);
            }
        }

        // Seed Service Categories (8 total)
        $serviceCategories = [
            ['name' => 'Shaadi Halls', 'description' => 'Wedding halls and venues'],
            ['name' => 'Caterers', 'description' => 'Catering services'],
            ['name' => 'Makeup Artists', 'description' => 'Makeup and beauty services'],
            ['name' => 'Decorators', 'description' => 'Wedding decoration services'],
            ['name' => 'Wedding Planners', 'description' => 'Wedding planning services'],
            ['name' => 'Photographers', 'description' => 'Photography services'],
            ['name' => 'Transportation', 'description' => 'Transportation services'],
            ['name' => 'Pooja/Pandit Booking', 'description' => 'Pandit and religious services'],
        ];

        foreach ($serviceCategories as $category) {
            ServiceCategory::create($category);
        }
    }

    private function createAdminUser(): void
    {
        User::factory()->admin()->create([
            'phone' => '9999999999',
        ]);
    }

    private function createDemoProfiles(): void
    {
        $religions = Religion::all();
        $castes = Caste::all();
        $gotras = Gotra::all();
        $educations = Education::all();
        $occupations = Occupation::all();
        $states = State::all();
        $cities = City::all();
        $hobbies = Hobby::all();

        // Create 40 verified profiles (20 male, 20 female)
        for ($i = 1; $i <= 20; $i++) {
            // Male profiles
            $maleUser = User::factory()->create();
            $maleProfile = Profile::factory()
                ->male()
                ->create([
                    'user_id' => $maleUser->id,
                    'religion_id' => $religions->random()->id,
                    'caste_id' => $castes->random()->id,
                    'gotra_id' => $gotras->random()->id,
                    'education_id' => $educations->random()->id,
                    'occupation_id' => $occupations->random()->id,
                    'state_id' => $states->random()->id,
                    'city_id' => $cities->random()->id,
                ]);

            // Add profile photos
            ProfilePhoto::factory()->create([
                'profile_id' => $maleProfile->id,
                'is_primary' => true,
            ]);
            ProfilePhoto::factory(2)->create([
                'profile_id' => $maleProfile->id,
                'is_primary' => false,
            ]);

            // Add profile educations
            ProfileEducation::factory(2)->create([
                'profile_id' => $maleProfile->id,
            ]);

            // Attach hobbies
            $maleProfile->hobbies()->attach($hobbies->random(3)->pluck('id')->toArray());

            // Create partner preference
            PartnerPreference::factory()->create([
                'profile_id' => $maleProfile->id,
                'age_from' => 18,
                'age_to' => 35,
            ]);

            // Female profiles
            $femaleUser = User::factory()->create();
            $femaleProfile = Profile::factory()
                ->female()
                ->create([
                    'user_id' => $femaleUser->id,
                    'religion_id' => $religions->random()->id,
                    'caste_id' => $castes->random()->id,
                    'gotra_id' => $gotras->random()->id,
                    'education_id' => $educations->random()->id,
                    'occupation_id' => $occupations->random()->id,
                    'state_id' => $states->random()->id,
                    'city_id' => $cities->random()->id,
                ]);

            // Add profile photos
            ProfilePhoto::factory()->create([
                'profile_id' => $femaleProfile->id,
                'is_primary' => true,
            ]);
            ProfilePhoto::factory(2)->create([
                'profile_id' => $femaleProfile->id,
                'is_primary' => false,
            ]);

            // Add profile educations
            ProfileEducation::factory(2)->create([
                'profile_id' => $femaleProfile->id,
            ]);

            // Attach hobbies
            $femaleProfile->hobbies()->attach($hobbies->random(3)->pluck('id')->toArray());

            // Create partner preference
            PartnerPreference::factory()->create([
                'profile_id' => $femaleProfile->id,
                'age_from' => 18,
                'age_to' => 35,
            ]);
        }

        // Create 2 users with PENDING status
        for ($i = 0; $i < 2; $i++) {
            $pendingUser = User::factory()->unverified()->create();
            Profile::factory()
                ->pending()
                ->create([
                    'user_id' => $pendingUser->id,
                    'religion_id' => $religions->random()->id,
                    'caste_id' => $castes->random()->id,
                    'education_id' => $educations->random()->id,
                    'occupation_id' => $occupations->random()->id,
                    'state_id' => $states->random()->id,
                    'city_id' => $cities->random()->id,
                ]);
        }
    }

    private function createDemoVendors(): void
    {
        $serviceCategories = ServiceCategory::all();
        $cities = City::all();

        // Create 2 approved vendors per category (16 total)
        foreach ($serviceCategories as $category) {
            for ($i = 0; $i < 2; $i++) {
                $vendor = Vendor::factory()->create([
                    'city_id' => $cities->random()->id,
                ]);

                // Create vendor packages
                $package = VendorPackage::factory(2)->create([
                    'vendor_id' => $vendor->id,
                    'service_category_id' => $category->id,
                ]);

                // Create vendor images
                VendorImage::factory(3)->create([
                    'vendor_id' => $vendor->id,
                ]);

                // Create vendor testimonials (2 approved each)
                VendorTestimonial::factory(2)->create([
                    'vendor_id' => $vendor->id,
                ]);

                // Create vendor availability for each day of the week
                for ($day = 0; $day <= 6; $day++) {
                    VendorAvailability::factory()->create([
                        'vendor_id' => $vendor->id,
                        'day_of_week' => $day,
                    ]);
                }
            }
        }

        // Create 2 vendors with PENDING status
        for ($i = 0; $i < 2; $i++) {
            $vendor = Vendor::factory()
                ->pending()
                ->create([
                    'city_id' => $cities->random()->id,
                ]);

            VendorPackage::factory()->create([
                'vendor_id' => $vendor->id,
                'service_category_id' => $serviceCategories->random()->id,
            ]);
        }
    }

    private function createDemoInteractions(): void
    {
        $users = User::where('role', UserRole::USER)->get();
        $profiles = Profile::all();

        if ($users->count() < 2 || $profiles->count() < 2) {
            return;
        }

        // Create interest requests in each status
        $statuses = ['PENDING', 'ACCEPTED', 'REJECTED', 'WITHDRAWN', 'EXPIRED'];

        foreach ($statuses as $status) {
            if ($users->count() >= 2 && $profiles->count() >= 2) {
                InterestRequest::create([
                    'sender_id' => $users->random()->id,
                    'receiver_id' => $users->random()->id,
                    'receiver_profile_id' => $profiles->random()->id,
                    'message' => 'Interested in getting to know you.',
                    'status' => $status,
                    'responded_at' => in_array($status, ['ACCEPTED', 'REJECTED', 'WITHDRAWN', 'EXPIRED']) ? now() : null,
                ]);
            }
        }

        // Create 3 confirmed matches with conversation + messages
        for ($i = 0; $i < 3; $i++) {
            if ($users->count() >= 2 && $profiles->count() >= 2) {
                $user1 = $users->random();
                $user2 = $users->random();

                $match = UserMatch::create([
                    'initiator_id' => $user1->id,
                    'matcher_id' => $user2->id,
                    'initiator_profile_id' => $profiles->where('user_id', $user1->id)->first()->id,
                    'matcher_profile_id' => $profiles->where('user_id', $user2->id)->first()->id,
                    'status' => MatchStatus::CONFIRMED,
                    'connected_at' => now(),
                    'is_active' => true,
                ]);

                // Create conversation
                $conversation = Conversation::create([
                    'initiator_id' => $user1->id,
                    'participant_id' => $user2->id,
                    'subject' => 'Getting to know each other',
                    'is_active' => true,
                ]);

                // Create messages
                Message::factory(5)->create([
                    'conversation_id' => $conversation->id,
                    'match_id' => $match->id,
                    'sender_id' => rand(0, 1) ? $user1->id : $user2->id,
                ]);
            }
        }

        // Create 4 bookings across different statuses
        $vendorPackages = VendorPackage::all();
        $bookingStatuses = [
            BookingStatus::INQUIRY,
            BookingStatus::CONFIRMED,
            BookingStatus::CANCELLED,
            BookingStatus::COMPLETED,
        ];

        foreach ($bookingStatuses as $status) {
            if ($users->count() >= 1 && $vendorPackages->count() >= 1) {
                $package = $vendorPackages->random();

                $booking = Booking::create([
                    'user_id' => $users->random()->id,
                    'vendor_id' => $package->vendor_id,
                    'vendor_package_id' => $package->id,
                    'booking_date' => now(),
                    'service_date' => now()->addDays(rand(5, 90)),
                    'guests_count' => rand(50, 500),
                    'estimated_amount' => rand(50000, 500000),
                    'final_amount' => rand(50000, 500000),
                    'payment_status' => 1,
                    'booking_status' => $status,
                    'confirmed_at' => in_array($status, [BookingStatus::CONFIRMED, BookingStatus::COMPLETED], true) ? now() : null,
                    'completed_at' => $status === BookingStatus::COMPLETED ? now() : null,
                    'cancelled_at' => $status === BookingStatus::CANCELLED ? now() : null,
                ]);

                // Create review for completed bookings
                if ($status === BookingStatus::COMPLETED) {
                    Review::create([
                        'user_id' => $booking->user_id,
                        'reviewer_id' => $booking->user_id,
                        'vendor_id' => $booking->vendor_id,
                        'booking_id' => $booking->id,
                        'rating' => rand(4, 5),
                        'review_text' => 'Great service and excellent coordination!',
                        'body' => 'Great service and excellent coordination!',
                        'punctuality_rating' => rand(4, 5),
                        'communication_rating' => rand(4, 5),
                        'quality_rating' => rand(4, 5),
                        'value_rating' => rand(4, 5),
                        'verified_purchase' => true,
                        'is_published' => true,
                    ]);
                }
            }
        }

        // Create suggested matches
        if ($users->count() >= 1 && $profiles->count() >= 2) {
            for ($i = 0; $i < 5; $i++) {
                $user = $users->random();
                $profile = $profiles->whereNotIn('user_id', [$user->id])->random();

                SuggestedMatch::create([
                    'user_id' => $user->id,
                    'suggested_profile_id' => $profile->id,
                    'compatibility_score' => rand(65, 95),
                    'match_reasons' => [
                        'Similar interests',
                        'Compatible age range',
                        'Same location preference',
                    ],
                    'is_interested' => rand(0, 1) ? true : false,
                    'interest_expressed_at' => rand(0, 1) ? now() : null,
                    'is_rejected' => false,
                ]);
            }
        }
    }
}
