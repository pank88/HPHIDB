<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\Conversation;
use App\Models\Message;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class MessageFactory extends Factory
{
    protected $model = Message::class;

    public function definition(): array
    {
        return [
            'conversation_id' => Conversation::factory(),
            'sender_id' => User::factory(),
            'body' => $this->faker->sentence(),
            'type' => $this->faker->randomElement(['text', 'image', 'file', 'system']),
            'media_url' => null,
            'file_name' => null,
            'file_size' => null,
            'is_edited' => false,
            'edited_at' => null,
            'read_at' => $this->faker->boolean(50) ? $this->faker->dateTime() : null,
        ];
    }
}
