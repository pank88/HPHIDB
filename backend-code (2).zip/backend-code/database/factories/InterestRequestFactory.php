<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\InterestRequest;
use App\Models\Profile;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class InterestRequestFactory extends Factory
{
    protected $model = InterestRequest::class;

    public function definition(): array
    {
        return [
            'sender_id' => User::factory(),
            'receiver_id' => User::factory(),
            'receiver_profile_id' => Profile::factory(),
            'message' => $this->faker->sentence(),
            'status' => $this->faker->randomElement(['PENDING', 'ACCEPTED', 'REJECTED', 'WITHDRAWN', 'EXPIRED']),
            'responded_at' => $this->faker->boolean(60) ? now() : null,
            'sent_at' => now(),
            'expires_at' => now()->addDays(30),
        ];
    }

    public function pending(): static
    {
        return $this->state(fn () => [
            'status' => 'PENDING',
            'responded_at' => null,
        ]);
    }

    public function accepted(): static
    {
        return $this->state(fn () => [
            'status' => 'ACCEPTED',
            'responded_at' => now(),
        ]);
    }

    public function rejected(): static
    {
        return $this->state(fn () => [
            'status' => 'REJECTED',
            'responded_at' => now(),
        ]);
    }
}
