<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\Profile;
use App\Models\User;
use App\Models\UserMatch;
use Illuminate\Database\Eloquent\Factories\Factory;

class UserMatchFactory extends Factory
{
    protected $model = UserMatch::class;

    public function definition(): array
    {
        return [
            'initiator_id' => User::factory(),
            'matcher_id' => User::factory(),
            'initiator_profile_id' => Profile::factory(),
            'matcher_profile_id' => Profile::factory(),
            'connected_at' => now(),
            'last_interaction_at' => now(),
            'is_active' => true,
        ];
    }

    public function confirmed(): static
    {
        return $this->state(fn () => [
            'connected_at' => now(),
        ]);
    }
}
