<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\Vendor;
use App\Models\VendorImage;
use Illuminate\Database\Eloquent\Factories\Factory;

class VendorImageFactory extends Factory
{
    protected $model = VendorImage::class;

    public function definition(): array
    {
        return [
            'vendor_id' => Vendor::factory(),
            'image_path' => 'vendor-images/'.$this->faker->uuid().'.jpg',
            'alt_text' => $this->faker->sentence(),
            'is_primary' => $this->faker->boolean(20),
            'display_order' => $this->faker->numberBetween(1, 10),
        ];
    }
}
