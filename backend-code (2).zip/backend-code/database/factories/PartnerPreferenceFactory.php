<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\Caste;
use App\Models\City;
use App\Models\Education;
use App\Models\Occupation;
use App\Models\PartnerPreference;
use App\Models\Profile;
use App\Models\Religion;
use App\Models\State;
use Illuminate\Database\Eloquent\Factories\Factory;

class PartnerPreferenceFactory extends Factory
{
    protected $model = PartnerPreference::class;

    public function definition(): array
    {
        return [
            'profile_id' => Profile::factory(),
            'age_from' => $this->faker->numberBetween(18, 30),
            'age_to' => $this->faker->numberBetween(31, 45),
            'height_from' => $this->faker->numberBetween(150, 165),
            'height_to' => $this->faker->numberBetween(166, 185),
            'religion_id' => Religion::inRandomOrder()->first()->id,
            'caste_id' => Caste::inRandomOrder()->first()->id,
            'education_id' => Education::inRandomOrder()->first()->id,
            'occupation_id' => Occupation::inRandomOrder()->first()->id,
            'annual_income_from' => $this->faker->numberBetween(250000, 1000000),
            'annual_income_to' => $this->faker->numberBetween(1000001, 5000000),
            'state_id' => State::inRandomOrder()->first()->id,
            'city_id' => City::inRandomOrder()->first()->id,
            'marital_status' => 'any',
            'body_type' => $this->faker->randomElement(['SLIM', 'AVERAGE', 'ATHLETIC']),
            'skin_tone' => $this->faker->randomElement(['FAIR', 'WHEATISH', 'DARK']),
            'mother_tongue' => $this->faker->randomElement(['Hindi', 'Marathi', 'Gujarati', 'Bengali', 'Tamil']),
            'manglik' => $this->faker->boolean(10),
            'smoke' => $this->faker->boolean(20),
            'drink' => $this->faker->boolean(20),
            'dietary_preference' => $this->faker->randomElement(['VEG', 'NON_VEG', 'BOTH']),
            'personality_type' => $this->faker->word(),
            'interests' => ['reading', 'traveling', 'cooking'],
        ];
    }
}
