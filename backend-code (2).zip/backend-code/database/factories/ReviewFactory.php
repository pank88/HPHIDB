<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\Booking;
use App\Models\Review;
use App\Models\User;
use App\Models\Vendor;
use Illuminate\Database\Eloquent\Factories\Factory;

class ReviewFactory extends Factory
{
    protected $model = Review::class;

    public function definition(): array
    {
        return [
            'booking_id' => Booking::factory(),
            'reviewer_id' => User::factory(),
            'vendor_id' => Vendor::factory(),
            'rating' => $this->faker->numberBetween(3, 5),
            'title' => $this->faker->sentence(4),
            'body' => $this->faker->text(200),
            'punctuality_rating' => $this->faker->numberBetween(3, 5),
            'communication_rating' => $this->faker->numberBetween(3, 5),
            'quality_rating' => $this->faker->numberBetween(3, 5),
            'value_rating' => $this->faker->numberBetween(3, 5),
            'verified_purchase' => true,
            'is_published' => true,
        ];
    }
}
