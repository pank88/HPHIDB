<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\Vendor;
use App\Models\VendorTestimonial;
use Illuminate\Database\Eloquent\Factories\Factory;

class VendorTestimonialFactory extends Factory
{
    protected $model = VendorTestimonial::class;

    public function definition(): array
    {
        return [
            'vendor_id' => Vendor::factory(),
            'reviewer_name' => $this->faker->name(),
            'client_name' => $this->faker->name(),
            'client_email' => $this->faker->safeEmail(),
            'client_location' => $this->faker->city(),
            'rating' => $this->faker->numberBetween(3, 5),
            'testimonial' => $this->faker->text(200),
            'body' => $this->faker->text(200),
            'is_approved' => true,
            'approved_at' => now(),
            'status' => 1,
        ];
    }
}
