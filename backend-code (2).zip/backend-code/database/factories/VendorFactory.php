<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\City;
use App\Models\ServiceCategory;
use App\Models\User;
use App\Models\Vendor;
use Illuminate\Database\Eloquent\Factories\Factory;

class VendorFactory extends Factory
{
    protected $model = Vendor::class;

    public function definition(): array
    {
        return [
            'user_id' => User::factory()->vendor(),
            'business_name' => $this->faker->unique()->company().' Services',
            'owner_name' => $this->faker->name(),
            'email' => $this->faker->unique()->companyEmail(),
            'phone' => $this->faker->unique()->numerify('9#########'),
            'description' => $this->faker->text(200),
            'bio' => $this->faker->sentence(),
            'business_address' => $this->faker->address(),
            'city_id' => City::inRandomOrder()->first()->id ?? City::factory(),
            'postal_code' => $this->faker->numerify('######'),
            'service_category_id' => ServiceCategory::inRandomOrder()->first()->id ?? ServiceCategory::factory(),
            'website' => $this->faker->url(),
            'logo_path' => 'logos/'.$this->faker->uuid().'.jpg',
            'rating' => $this->faker->randomFloat(2, 3.5, 5),
            'total_reviews' => $this->faker->numberBetween(0, 50),
            'response_time_hours' => $this->faker->numberBetween(1, 48),
            'status' => 1,
            'is_verified' => true,
            'verified_at' => now(),
        ];
    }

    public function pending(): static
    {
        return $this->state(fn () => [
            'is_verified' => false,
            'verified_at' => null,
        ]);
    }
}
