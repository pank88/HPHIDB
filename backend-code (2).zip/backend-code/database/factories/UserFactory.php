<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Constants\UserRole;
use App\Constants\UserStatus;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;

class UserFactory extends Factory
{
    protected $model = User::class;

    public function definition(): array
    {
        return [
            'name' => $this->faker->name(),
            'email' => $this->faker->unique()->safeEmail(),
            'password' => Hash::make('Password@123'),
            'phone' => $this->faker->unique()->numerify('9#########'),
            'role' => UserRole::USER,
            'email_verified_at' => now(),
            'phone_verified_at' => now(),
            'status' => UserStatus::ACTIVE,
        ];
    }

    public function admin(): static
    {
        return $this->state(fn () => [
            'email' => 'admin@matrimony.test',
            'password' => Hash::make('Admin@123'),
            'role' => UserRole::ADMIN,
            'status' => UserStatus::ACTIVE,
        ]);
    }

    public function unverified(): static
    {
        return $this->state(fn () => [
            'email_verified_at' => null,
            'phone_verified_at' => null,
            'status' => UserStatus::PENDING,
        ]);
    }

    public function vendor(): static
    {
        return $this->state(fn () => [
            'role' => UserRole::VENDOR,
        ]);
    }
}
