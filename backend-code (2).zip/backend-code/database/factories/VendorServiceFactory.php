<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\ServiceCategory;
use App\Models\Vendor;
use App\Models\VendorService;
use Illuminate\Database\Eloquent\Factories\Factory;

class VendorServiceFactory extends Factory
{
    protected $model = VendorService::class;

    public function definition(): array
    {
        return [
            'vendor_id' => Vendor::factory(),
            'service_category_id' => ServiceCategory::inRandomOrder()->first()->id ?? ServiceCategory::factory(),
            'name' => $this->faker->words(3, true).' Service',
            'description' => $this->faker->text(150),
            'base_price' => $this->faker->randomFloat(2, 5000, 100000),
            'price_unit' => $this->faker->randomElement(['per_event', 'per_hour', 'per_package']),
            'duration_hours' => $this->faker->numberBetween(1, 12),
            'max_guests_count' => $this->faker->numberBetween(50, 1000),
            'is_active' => true,
        ];
    }
}
