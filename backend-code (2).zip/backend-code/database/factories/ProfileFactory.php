<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Constants\MaritalStatus;
use App\Models\Caste;
use App\Models\City;
use App\Models\Education;
use App\Models\Gotra;
use App\Models\Occupation;
use App\Models\Profile;
use App\Models\Religion;
use App\Models\State;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProfileFactory extends Factory
{
    protected $model = Profile::class;

    public function definition(): array
    {
        $gender = $this->faker->randomElement(['male', 'female']);
        $firstName = $this->faker->firstName($gender);
        $lastName = $this->faker->lastName();

        return [
            'user_id' => User::factory(),
            'first_name' => $firstName,
            'last_name' => $lastName,
            'full_name' => $firstName.' '.$lastName,
            'date_of_birth' => $this->faker->dateTimeBetween('-35 years', '-18 years'),
            'gender' => $gender,
            'height' => $this->faker->randomFloat(2, 4.50, 6.50),
            'weight' => $this->faker->numberBetween(45, 85),
            'body_type' => $this->faker->randomElement(['SLIM', 'AVERAGE', 'ATHLETIC', 'HEAVY']),
            'skin_tone' => $this->faker->randomElement(['FAIR', 'WHEATISH', 'DARK']),
            'marital_status' => MaritalStatus::NEVER_MARRIED,
            'religion_id' => Religion::inRandomOrder()->first()->id ?? Religion::factory(),
            'caste_id' => Caste::inRandomOrder()->first()->id ?? Caste::factory(),
            'gotra_id' => Gotra::inRandomOrder()->first()->id ?? Gotra::factory(),
            'mother_tongue' => $this->faker->randomElement(['Hindi', 'Marathi', 'Gujarati', 'Bengali', 'Tamil', 'Telugu', 'Kannada', 'Malayalam', 'Punjabi']),
            'education_id' => Education::inRandomOrder()->first()->id ?? Education::factory(),
            'occupation_id' => Occupation::inRandomOrder()->first()->id ?? Occupation::factory(),
            'annual_income' => $this->faker->numberBetween(300000, 5000000),
            'occupation_detail' => $this->faker->sentence(),
            'city_id' => City::inRandomOrder()->first()->id ?? City::factory(),
            'state_id' => State::inRandomOrder()->first()->id ?? State::factory(),
            'country' => 'India',
            'bio' => $this->faker->text(200),
            'looking_for' => $this->faker->text(100),
            'profile_completion_percentage' => $this->faker->numberBetween(70, 100),
            'is_verified' => true,
            'verification_date' => now(),
            'is_active' => true,
            'is_featured' => $this->faker->boolean(20),
        ];
    }

    public function male(): static
    {
        return $this->state(fn () => [
            'gender' => 'MALE',
            'height' => $this->faker->randomFloat(2, 5.40, 6.50),
            'weight' => $this->faker->numberBetween(60, 85),
        ]);
    }

    public function female(): static
    {
        return $this->state(fn () => [
            'gender' => 'FEMALE',
            'height' => $this->faker->randomFloat(2, 4.50, 5.60),
            'weight' => $this->faker->numberBetween(45, 70),
        ]);
    }

    public function pending(): static
    {
        return $this->state(fn () => [
            'is_verified' => false,
            'verification_date' => null,
        ]);
    }
}
