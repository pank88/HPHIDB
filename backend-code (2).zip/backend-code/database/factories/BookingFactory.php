<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\Booking;
use App\Models\User;
use App\Models\Vendor;
use App\Models\VendorService;
use Illuminate\Database\Eloquent\Factories\Factory;

class BookingFactory extends Factory
{
    protected $model = Booking::class;

    public function definition(): array
    {
        return [
            'booking_code' => 'BK-'.$this->faker->unique()->numerify('########'),
            'user_id' => User::factory(),
            'vendor_id' => Vendor::factory(),
            'vendor_service_id' => VendorService::factory(),
            'booking_date' => now(),
            'service_date' => $this->faker->dateTimeBetween('+5 days', '+90 days')->format('Y-m-d'),
            'service_time_from' => '10:00',
            'service_time_to' => '18:00',
            'location_address' => $this->faker->address(),
            'guests_count' => $this->faker->numberBetween(50, 500),
            'special_requirements' => $this->faker->text(100),
            'estimated_amount' => $this->faker->randomFloat(2, 10000, 500000),
            'status' => 'INQUIRY',
            'payment_status' => 'PENDING',
        ];
    }

    public function confirmed(): static
    {
        return $this->state(fn () => [
            'status' => 'CONFIRMED',
            'confirmed_at' => now(),
        ]);
    }
}
