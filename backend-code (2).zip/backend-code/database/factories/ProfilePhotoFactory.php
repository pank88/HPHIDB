<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\Profile;
use App\Models\ProfilePhoto;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProfilePhotoFactory extends Factory
{
    protected $model = ProfilePhoto::class;

    public function definition(): array
    {
        return [
            'profile_id' => Profile::factory(),
            'photo_path' => 'photos/'.$this->faker->uuid().'.jpg',
            'is_primary' => $this->faker->boolean(30),
            'is_verified' => $this->faker->boolean(70),
            'status' => 1,

        ];
    }
}
