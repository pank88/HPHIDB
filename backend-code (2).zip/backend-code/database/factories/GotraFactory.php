<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\Gotra;
use Illuminate\Database\Eloquent\Factories\Factory;

class GotraFactory extends Factory
{
    protected $model = Gotra::class;

    public function definition(): array
    {
        return [
            'name' => $this->faker->unique()->word(),
            'description' => $this->faker->sentence(),
        ];
    }
}
