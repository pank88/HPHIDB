<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\AuditLog;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class AuditLogFactory extends Factory
{
    protected $model = AuditLog::class;

    public function definition(): array
    {
        return [
            'user_id' => User::factory(),
            'action' => $this->faker->randomElement(['CREATE', 'UPDATE', 'DELETE', 'VIEW', 'EXPORT']),
            'model_type' => $this->faker->randomElement(['Profile', 'Booking', 'Vendor', 'User']),
            'model_id' => $this->faker->numberBetween(1, 1000),
            'old_values' => ['field' => 'old_value'],
            'new_values' => ['field' => 'new_value'],
            'ip_address' => $this->faker->ipv4(),
            'user_agent' => $this->faker->userAgent(),
            'description' => $this->faker->sentence(),
        ];
    }
}
