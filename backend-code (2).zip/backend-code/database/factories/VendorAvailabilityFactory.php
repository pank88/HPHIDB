<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\Vendor;
use App\Models\VendorAvailability;
use Illuminate\Database\Eloquent\Factories\Factory;

class VendorAvailabilityFactory extends Factory
{
    protected $model = VendorAvailability::class;

    public function definition(): array
    {
        return [
            'vendor_id' => Vendor::factory(),
            'day_of_week' => $this->faker->numberBetween(0, 6),
            'start_time' => '10:00:00',
            'end_time' => '22:00:00',
            'is_available' => true,
            'notes' => $this->faker->sentence(),
            'status' => 1,
        ];
    }
}
