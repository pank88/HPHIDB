<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\Conversation;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class ConversationFactory extends Factory
{
    protected $model = Conversation::class;

    public function definition(): array
    {
        return [
            'initiator_id' => User::factory(),
            'participant_id' => User::factory(),
            'subject' => $this->faker->sentence(),
            'last_message_at' => $this->faker->dateTimeBetween('-30 days'),
            'initiator_read_at' => $this->faker->dateTimeBetween('-7 days'),
            'participant_read_at' => $this->faker->dateTimeBetween('-7 days'),
            'initiator_is_typing' => false,
            'participant_is_typing' => false,
            'is_active' => true,
        ];
    }
}
