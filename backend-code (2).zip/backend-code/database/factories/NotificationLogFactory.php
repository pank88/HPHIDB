<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\NotificationLog;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class NotificationLogFactory extends Factory
{
    protected $model = NotificationLog::class;

    public function definition(): array
    {
        return [
            'user_id' => User::factory(),
            'notification_type' => $this->faker->randomElement(['INTEREST_REQUEST', 'MATCH', 'MESSAGE', 'BOOKING', 'REVIEW']),
            'subject' => $this->faker->sentence(),
            'message' => $this->faker->text(150),
            'data' => [
                'reference_id' => $this->faker->numberBetween(1, 1000),
                'type' => 'event',
            ],
            'channel' => $this->faker->randomElement(['EMAIL', 'SMS', 'PUSH']),
            'sent_at' => now(),
            'read_at' => $this->faker->boolean(60) ? now() : null,
            'is_read' => $this->faker->boolean(60),
        ];
    }
}
