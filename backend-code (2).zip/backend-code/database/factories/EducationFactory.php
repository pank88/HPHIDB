<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\Education;
use Illuminate\Database\Eloquent\Factories\Factory;

class EducationFactory extends Factory
{
    protected $model = Education::class;

    public function definition(): array
    {
        return [
            'level' => $this->faker->unique()->word(),
            'field_of_study' => $this->faker->word(),
            'description' => $this->faker->sentence(),
            'status' => 1,
        ];
    }
}
