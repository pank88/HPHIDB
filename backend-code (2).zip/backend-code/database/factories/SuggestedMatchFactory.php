<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\Profile;
use App\Models\SuggestedMatch;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

class SuggestedMatchFactory extends Factory
{
    protected $model = SuggestedMatch::class;

    public function definition(): array
    {
        return [
            'user_id' => User::factory(),
            'suggested_profile_id' => Profile::factory(),
            'compatibility_score' => $this->faker->randomFloat(2, 60, 95),
            'match_reasons' => [
                'Similar interests',
                'Compatible background',
                'Location preference match',
            ],
            'is_interested' => $this->faker->boolean(40),
            'interest_expressed_at' => $this->faker->boolean(40) ? now() : null,
            'is_rejected' => $this->faker->boolean(20),
            'rejection_reason' => $this->faker->boolean(20) ? $this->faker->sentence() : null,
            'rejected_at' => $this->faker->boolean(20) ? now() : null,
        ];
    }
}
