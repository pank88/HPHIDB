<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\ServiceCategory;
use App\Models\Vendor;
use App\Models\VendorPackage;
use Illuminate\Database\Eloquent\Factories\Factory;

class VendorPackageFactory extends Factory
{
    protected $model = VendorPackage::class;

    public function definition(): array
    {
        return [
            'vendor_id' => Vendor::factory(),
            'service_category_id' => ServiceCategory::inRandomOrder()->first()->id ?? ServiceCategory::factory(),
            'name' => $this->faker->word().' Package',
            'description' => $this->faker->text(200),
            'price' => $this->faker->randomFloat(2, 5000, 100000),
            'currency' => 'INR',
            'duration' => $this->faker->numberBetween(1, 10),
            'duration_unit' => $this->faker->randomElement(['HOUR', 'DAY', 'MONTH']),
            'inclusions' => ['Setup', 'Decoration', 'Service'],
            'exclusions' => ['Travel', 'Extra staff'],
            'max_guests' => $this->faker->numberBetween(50, 1000),
            'is_available' => true,
            'is_featured' => $this->faker->boolean(30),
            'booking_count' => $this->faker->numberBetween(0, 20),
            'average_rating' => $this->faker->randomFloat(2, 3.5, 5),
            'total_reviews' => $this->faker->numberBetween(0, 15),
        ];
    }
}
