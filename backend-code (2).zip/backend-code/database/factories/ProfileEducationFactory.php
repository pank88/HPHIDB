<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\Education;
use App\Models\Profile;
use App\Models\ProfileEducation;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProfileEducationFactory extends Factory
{
    protected $model = ProfileEducation::class;

    public function definition(): array
    {
        return [
            'profile_id' => Profile::factory(),
            'education_id' => Education::inRandomOrder()->first()->id ?? Education::factory(),
            'institution_name' => $this->faker->company().' University',
            'board_or_university' => $this->faker->company(),
            'graduation_year' => $this->faker->numberBetween(2000, 2024),
            'specialization' => $this->faker->word(),
            'status' => 1,
        ];
    }
}
