<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\Caste;
use App\Models\Religion;
use Illuminate\Database\Eloquent\Factories\Factory;

class CasteFactory extends Factory
{
    protected $model = Caste::class;

    public function definition(): array
    {
        return [
            'religion_id' => Religion::factory(),
            'name' => $this->faker->unique()->word(),
            'description' => $this->faker->sentence(),
        ];
    }
}
