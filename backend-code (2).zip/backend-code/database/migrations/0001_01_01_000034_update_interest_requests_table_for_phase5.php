<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('interest_requests', function (Blueprint $table) {
            // Add missing columns if they don't exist
            if (! Schema::hasColumn('interest_requests', 'sender_id')) {
                $table->renameColumn('from_user_id', 'sender_id');
            }

            if (! Schema::hasColumn('interest_requests', 'receiver_id')) {
                $table->renameColumn('to_user_id', 'receiver_id');
            }

            if (! Schema::hasColumn('interest_requests', 'sender_profile_id')) {
                $table->foreignId('sender_profile_id')->nullable()->constrained('profiles')->cascadeOnDelete();
            }

            if (! Schema::hasColumn('interest_requests', 'receiver_profile_id')) {
                $table->foreignId('receiver_profile_id')->nullable()->constrained('profiles')->cascadeOnDelete();
            }

            if (! Schema::hasColumn('interest_requests', 'channel')) {
                $table->enum('channel', ['app', 'sms', 'email'])->default('app');
            }

            if (! Schema::hasColumn('interest_requests', 'sent_at')) {
                $table->timestamp('sent_at')->useCurrent();
            }

            if (! Schema::hasColumn('interest_requests', 'expires_at')) {
                $table->timestamp('expires_at')->nullable();
            }

            // Update status column to use text enum instead of tinyInteger (MySQL-specific syntax)
            if (Schema::hasColumn('interest_requests', 'status') && DB::getDriverName() === 'mysql') {
                DB::statement("ALTER TABLE interest_requests MODIFY status VARCHAR(255) DEFAULT 'PENDING'");
            }
        });
    }

    public function down(): void
    {
        Schema::table('interest_requests', function (Blueprint $table) {
            // Reverse the changes
        });
    }
};
