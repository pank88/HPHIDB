<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('notification_logs', function (Blueprint $table) {
            if (! Schema::hasColumn('notification_logs', 'notification_type')) {
                $table->string('notification_type', 100)->nullable()->index();
            }
            if (! Schema::hasColumn('notification_logs', 'subject')) {
                $table->string('subject', 255)->nullable();
            }
            if (! Schema::hasColumn('notification_logs', 'data')) {
                $table->text('data')->nullable();
            }
            if (! Schema::hasColumn('notification_logs', 'channel')) {
                $table->string('channel', 50)->nullable();
            }
            if (! Schema::hasColumn('notification_logs', 'sent_at')) {
                $table->timestamp('sent_at')->nullable();
            }
        });

        if (Schema::hasColumn('notification_logs', 'type')) {
            Schema::table('notification_logs', function (Blueprint $table) {
                $table->string('type', 100)->nullable()->change();
            });
        }

        if (Schema::hasColumn('notification_logs', 'title')) {
            Schema::table('notification_logs', function (Blueprint $table) {
                $table->text('title')->nullable()->change();
            });
        }

        if (Schema::hasColumn('notification_logs', 'message')) {
            Schema::table('notification_logs', function (Blueprint $table) {
                $table->longText('message')->nullable()->change();
            });
        }
    }

    public function down(): void
    {
        Schema::table('notification_logs', function (Blueprint $table) {
            foreach (['notification_type', 'subject', 'data', 'channel', 'sent_at'] as $column) {
                if (Schema::hasColumn('notification_logs', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
