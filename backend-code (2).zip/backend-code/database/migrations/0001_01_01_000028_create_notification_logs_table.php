<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('notification_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('type', 100)->comment('interest_received, match, message, booking_confirmation, review, etc.');
            $table->text('title');
            $table->longText('message');
            $table->string('entity_type', 100)->nullable()->comment('user, booking, vendor, review, etc.');
            $table->bigInteger('entity_id')->nullable();
            $table->string('action_url', 255)->nullable();
            $table->tinyInteger('notification_channel')->default(1)->comment('1=In-App, 2=Email, 3=SMS, 4=Push');
            $table->tinyInteger('is_read')->default(0)->comment('0=Unread, 1=Read');
            $table->timestamp('read_at')->nullable();
            $table->tinyInteger('status')->default(1)->comment('1=Active, 2=Archived');
            $table->timestamps();

            $table->engine = 'InnoDB';
            $table->collation = 'utf8mb4_unicode_ci';
            $table->index('user_id');
            $table->index('type');
            $table->index('is_read');
            $table->index('status');
            $table->index('created_at');
            $table->index(['entity_type', 'entity_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('notification_logs');
    }
};
