<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('profiles', function (Blueprint $table) {
            if (! Schema::hasColumn('profiles', 'first_name')) {
                $table->string('first_name', 100)->nullable();
            }
            if (! Schema::hasColumn('profiles', 'last_name')) {
                $table->string('last_name', 100)->nullable();
            }
            if (! Schema::hasColumn('profiles', 'weight')) {
                $table->unsignedSmallInteger('weight')->nullable()->comment('Weight in kg');
            }
            if (! Schema::hasColumn('profiles', 'body_type')) {
                $table->string('body_type', 50)->nullable();
            }
            if (! Schema::hasColumn('profiles', 'skin_tone')) {
                $table->string('skin_tone', 50)->nullable();
            }
            if (! Schema::hasColumn('profiles', 'occupation_detail')) {
                $table->string('occupation_detail', 255)->nullable();
            }
            if (! Schema::hasColumn('profiles', 'city_id')) {
                $table->foreignId('city_id')->nullable()->constrained('cities')->nullOnDelete();
            }
            if (! Schema::hasColumn('profiles', 'state_id')) {
                $table->foreignId('state_id')->nullable()->constrained('states')->nullOnDelete();
            }
            if (! Schema::hasColumn('profiles', 'country')) {
                $table->string('country', 100)->nullable();
            }
            if (! Schema::hasColumn('profiles', 'looking_for')) {
                $table->text('looking_for')->nullable();
            }
            if (! Schema::hasColumn('profiles', 'profile_completion_percentage')) {
                $table->unsignedTinyInteger('profile_completion_percentage')->default(0);
            }
            if (! Schema::hasColumn('profiles', 'is_verified')) {
                $table->boolean('is_verified')->default(false);
            }
            if (! Schema::hasColumn('profiles', 'verification_date')) {
                $table->timestamp('verification_date')->nullable();
            }
            if (! Schema::hasColumn('profiles', 'is_active')) {
                $table->boolean('is_active')->default(true);
            }
            if (! Schema::hasColumn('profiles', 'is_featured')) {
                $table->boolean('is_featured')->default(false);
            }
        });

        if (Schema::hasColumn('profiles', 'full_name')) {
            Schema::table('profiles', function (Blueprint $table) {
                $table->string('full_name', 255)->nullable()->change();
            });
        }
    }

    public function down(): void
    {
        Schema::table('profiles', function (Blueprint $table) {
            if (Schema::hasColumn('profiles', 'city_id')) {
                $table->dropConstrainedForeignId('city_id');
            }
            if (Schema::hasColumn('profiles', 'state_id')) {
                $table->dropConstrainedForeignId('state_id');
            }

            foreach ([
                'first_name', 'last_name', 'weight', 'body_type', 'skin_tone',
                'occupation_detail', 'country', 'looking_for',
                'profile_completion_percentage', 'is_verified', 'verification_date',
                'is_active', 'is_featured',
            ] as $column) {
                if (Schema::hasColumn('profiles', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
