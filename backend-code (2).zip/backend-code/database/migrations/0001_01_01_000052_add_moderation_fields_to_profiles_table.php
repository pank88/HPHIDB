<?php

declare(strict_types=1);

use App\Constants\ModerationStatus;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('profiles', function (Blueprint $table) {
            if (! Schema::hasColumn('profiles', 'moderation_status')) {
                $table->tinyInteger('moderation_status')->default(ModerationStatus::PENDING)->index();
            }

            if (! Schema::hasColumn('profiles', 'moderated_at')) {
                $table->timestamp('moderated_at')->nullable();
            }

            if (! Schema::hasColumn('profiles', 'moderated_by')) {
                $table->foreignId('moderated_by')->nullable()->constrained('users')->nullOnDelete();
            }

            if (! Schema::hasColumn('profiles', 'rejection_reason')) {
                $table->text('rejection_reason')->nullable();
            }
        });
    }

    public function down(): void
    {
        Schema::table('profiles', function (Blueprint $table) {
            if (Schema::hasColumn('profiles', 'moderated_by')) {
                $table->dropConstrainedForeignId('moderated_by');
            }

            foreach (['moderation_status', 'moderated_at', 'rejection_reason'] as $column) {
                if (Schema::hasColumn('profiles', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
