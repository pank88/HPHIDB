<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('reviews', function (Blueprint $table) {
            // Add reviewer_id if not exists
            if (! Schema::hasColumn('reviews', 'reviewer_id')) {
                $table->foreignId('reviewer_id')->nullable()->after('booking_id')->constrained('users')->cascadeOnDelete();
            }

            // Add Phase 7 columns
            if (! Schema::hasColumn('reviews', 'body')) {
                $table->longText('body')->nullable()->after('review_text');
            }
            if (! Schema::hasColumn('reviews', 'punctuality_rating')) {
                $table->integer('punctuality_rating')->nullable()->after('rating');
            }
            if (! Schema::hasColumn('reviews', 'communication_rating')) {
                $table->integer('communication_rating')->nullable()->after('punctuality_rating');
            }
            if (! Schema::hasColumn('reviews', 'quality_rating')) {
                $table->integer('quality_rating')->nullable()->after('communication_rating');
            }
            if (! Schema::hasColumn('reviews', 'value_rating')) {
                $table->integer('value_rating')->nullable()->after('quality_rating');
            }
            if (! Schema::hasColumn('reviews', 'photos_count')) {
                $table->integer('photos_count')->default(0)->after('value_rating');
            }
            if (! Schema::hasColumn('reviews', 'verified_purchase')) {
                $table->boolean('verified_purchase')->default(true)->after('photos_count');
            }
            if (! Schema::hasColumn('reviews', 'is_published')) {
                $table->boolean('is_published')->default(true)->after('verified_purchase');
            }
            if (! Schema::hasColumn('reviews', 'response')) {
                $table->longText('response')->nullable()->after('is_published');
            }
            if (! Schema::hasColumn('reviews', 'response_at')) {
                $table->timestamp('response_at')->nullable()->after('response');
            }
        });
    }

    public function down(): void
    {
        Schema::table('reviews', function (Blueprint $table) {
            $columnsToDropIfExists = [
                'reviewer_id',
                'body',
                'punctuality_rating',
                'communication_rating',
                'quality_rating',
                'value_rating',
                'photos_count',
                'verified_purchase',
                'is_published',
                'response',
                'response_at',
            ];

            foreach ($columnsToDropIfExists as $column) {
                if (Schema::hasColumn('reviews', $column)) {
                    if ($column === 'reviewer_id') {
                        $table->dropForeignIdFor($column);
                    } else {
                        $table->dropColumn($column);
                    }
                }
            }
        });
    }
};
