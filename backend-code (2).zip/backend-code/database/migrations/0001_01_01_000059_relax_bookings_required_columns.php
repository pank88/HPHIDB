<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasColumn('bookings', 'booking_code')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->string('booking_code', 50)->nullable()->change();
            });
        }

        if (Schema::hasColumn('bookings', 'vendor_package_id')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->unsignedBigInteger('vendor_package_id')->nullable()->change();
            });
        }

        if (Schema::hasColumn('bookings', 'booking_date')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->dateTime('booking_date')->nullable()->change();
            });
        }

        if (Schema::hasColumn('bookings', 'package_price')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->decimal('package_price', 12, 2)->nullable()->change();
            });
        }

        if (Schema::hasColumn('bookings', 'total_amount')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->decimal('total_amount', 12, 2)->nullable()->change();
            });
        }
    }

    public function down(): void
    {
        // Intentionally left non-reversible: relaxing NOT NULL constraints only.
    }
};
