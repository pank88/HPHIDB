<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('partner_preferences', function (Blueprint $table) {
            $table->id();
            $table->foreignId('profile_id')->unique()->constrained('profiles')->cascadeOnDelete();
            $table->enum('preferred_gender', ['male', 'female', 'both'])->default('both');
            $table->integer('age_from')->nullable();
            $table->integer('age_to')->nullable();
            $table->integer('height_from')->nullable()->comment('Height in cm');
            $table->integer('height_to')->nullable()->comment('Height in cm');
            $table->text('preferred_religions')->nullable()->comment('JSON array of religion IDs');
            $table->text('preferred_castes')->nullable()->comment('JSON array of caste IDs');
            $table->text('preferred_educations')->nullable()->comment('JSON array of education IDs');
            $table->text('preferred_occupations')->nullable()->comment('JSON array of occupation IDs');
            $table->text('preferred_locations')->nullable()->comment('JSON array of location/city IDs');
            $table->text('preferred_qualities')->nullable()->comment('JSON array of qualities/hobbies');
            $table->enum('marital_status', ['single', 'divorced', 'widowed', 'any'])->default('any');
            $table->enum('children_preference', ['no', 'yes', 'any'])->default('any');
            $table->decimal('salary_range_from', 12, 2)->nullable();
            $table->decimal('salary_range_to', 12, 2)->nullable();
            $table->text('additional_preferences')->nullable();
            $table->tinyInteger('status')->default(1)->comment('1=Active, 0=Inactive');
            $table->timestamps();

            $table->engine = 'InnoDB';
            $table->collation = 'utf8mb4_unicode_ci';
            $table->index('profile_id');
            $table->index('status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('partner_preferences');
    }
};
