<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('suggested_matches', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('suggested_user_id')->constrained('users')->cascadeOnDelete();
            $table->decimal('match_score', 5, 2)->comment('UserMatch score in percentage');
            $table->text('match_reasons')->nullable()->comment('JSON array of reasons for match');
            $table->string('algorithm_version', 50)->nullable();
            $table->tinyInteger('user_action')->default(0)->comment('0=Not Viewed, 1=Interested, 2=Not Interested, 3=Shortlisted');
            $table->timestamp('viewed_at')->nullable();
            $table->timestamp('action_taken_at')->nullable();
            $table->tinyInteger('status')->default(1)->comment('1=Active, 2=Expired');
            $table->timestamp('expired_at')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->engine = 'InnoDB';
            $table->collation = 'utf8mb4_unicode_ci';
            $table->index('user_id');
            $table->index('suggested_user_id');
            $table->index('match_score');
            $table->index('status');
            $table->index('user_action');
            $table->index('created_at');
            $table->unique(['user_id', 'suggested_user_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('suggested_matches');
    }
};
