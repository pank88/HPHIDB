<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Update conversations table for Phase 6
        Schema::table('conversations', function (Blueprint $table) {
            // Add read tracking columns
            if (! Schema::hasColumn('conversations', 'initiator_read_at')) {
                $table->timestamp('initiator_read_at')->nullable()->after('last_message_at');
            }
            if (! Schema::hasColumn('conversations', 'participant_read_at')) {
                $table->timestamp('participant_read_at')->nullable()->after('initiator_read_at');
            }

            // Add typing indicator columns
            if (! Schema::hasColumn('conversations', 'initiator_is_typing')) {
                $table->boolean('initiator_is_typing')->default(false)->after('participant_read_at');
            }
            if (! Schema::hasColumn('conversations', 'participant_is_typing')) {
                $table->boolean('participant_is_typing')->default(false)->after('initiator_is_typing');
            }

            // Add indexes
            $table->index('initiator_read_at');
            $table->index('participant_read_at');
        });

        // Update messages table for Phase 6
        Schema::table('messages', function (Blueprint $table) {
            // Add type column if not exists
            if (! Schema::hasColumn('messages', 'type')) {
                $table->string('type')->default('text')->comment('text, image, file, system')->after('message');
            }

            // Add media-related columns
            if (! Schema::hasColumn('messages', 'media_url')) {
                $table->text('media_url')->nullable()->after('type');
            }
            if (! Schema::hasColumn('messages', 'file_name')) {
                $table->string('file_name')->nullable()->after('media_url');
            }
            if (! Schema::hasColumn('messages', 'file_size')) {
                $table->bigInteger('file_size')->nullable()->after('file_name');
            }

            // Add editing tracking columns
            if (! Schema::hasColumn('messages', 'is_edited')) {
                $table->boolean('is_edited')->default(false)->after('file_size');
            }
            if (! Schema::hasColumn('messages', 'edited_at')) {
                $table->timestamp('edited_at')->nullable()->after('is_edited');
            }

            // Rename or add message column to body if needed
            if (Schema::hasColumn('messages', 'message') && ! Schema::hasColumn('messages', 'body')) {
                $table->renameColumn('message', 'body');
            }

            // Add indexes for performance
            $table->index(['conversation_id', 'created_at']);
            $table->index('is_edited');
        });
    }

    public function down(): void
    {
        Schema::table('conversations', function (Blueprint $table) {
            if (Schema::hasColumn('conversations', 'initiator_read_at')) {
                $table->dropColumn('initiator_read_at');
            }
            if (Schema::hasColumn('conversations', 'participant_read_at')) {
                $table->dropColumn('participant_read_at');
            }
            if (Schema::hasColumn('conversations', 'initiator_is_typing')) {
                $table->dropColumn('initiator_is_typing');
            }
            if (Schema::hasColumn('conversations', 'participant_is_typing')) {
                $table->dropColumn('participant_is_typing');
            }
        });

        Schema::table('messages', function (Blueprint $table) {
            if (Schema::hasColumn('messages', 'type')) {
                $table->dropColumn('type');
            }
            if (Schema::hasColumn('messages', 'media_url')) {
                $table->dropColumn('media_url');
            }
            if (Schema::hasColumn('messages', 'file_name')) {
                $table->dropColumn('file_name');
            }
            if (Schema::hasColumn('messages', 'file_size')) {
                $table->dropColumn('file_size');
            }
            if (Schema::hasColumn('messages', 'is_edited')) {
                $table->dropColumn('is_edited');
            }
            if (Schema::hasColumn('messages', 'edited_at')) {
                $table->dropColumn('edited_at');
            }
        });
    }
};
