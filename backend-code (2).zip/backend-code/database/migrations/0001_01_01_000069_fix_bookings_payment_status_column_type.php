<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * The original create_bookings_table migration defined payment_status as a
     * tinyInteger (1=Pending, 2=Completed, 3=Failed, 4=Refunded). A later migration
     * tried to redefine it as a string enum but was skipped by its hasColumn guard
     * since the column already existed, so the app has been inserting strings like
     * 'PENDING' into an integer column ever since.
     */
    public function up(): void
    {
        if (Schema::hasColumn('bookings', 'payment_status')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->dropColumn('payment_status');
            });
        }

        Schema::table('bookings', function (Blueprint $table) {
            $table->enum('payment_status', ['PENDING', 'PARTIAL', 'PAID', 'REFUNDED'])
                ->default('PENDING')
                ->after('status');
        });
    }

    public function down(): void
    {
        if (Schema::hasColumn('bookings', 'payment_status')) {
            Schema::table('bookings', function (Blueprint $table) {
                $table->dropColumn('payment_status');
            });
        }

        Schema::table('bookings', function (Blueprint $table) {
            $table->tinyInteger('payment_status')->default(1)->comment('1=Pending, 2=Completed, 3=Failed, 4=Refunded');
        });
    }
};
