<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('vendors', function (Blueprint $table) {
            $table->id();
            $table->string('business_name', 255)->unique();
            $table->string('owner_name', 255);
            $table->string('email', 255)->unique();
            $table->string('phone', 20);
            $table->string('alt_phone', 20)->nullable();
            $table->text('description')->nullable();
            $table->string('logo_path', 255)->nullable();
            $table->text('business_address');
            $table->foreignId('city_id')->nullable()->constrained('cities')->nullOnDelete();
            $table->string('postal_code', 10)->nullable();
            $table->foreignId('service_category_id')->constrained('service_categories')->cascadeOnDelete();
            $table->string('website', 255)->nullable();
            $table->decimal('rating', 3, 2)->default(0)->comment('Average rating from 0 to 5');
            $table->integer('total_reviews')->default(0);
            $table->text('years_of_experience')->nullable();
            $table->text('certifications')->nullable();
            $table->text('social_media')->nullable()->comment('JSON object of social media links');
            $table->tinyInteger('status')->default(1)->comment('1=Active, 2=Inactive, 3=Suspended');
            $table->tinyInteger('is_verified')->default(0)->comment('0=No, 1=Yes');
            $table->timestamp('verified_at')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->engine = 'InnoDB';
            $table->collation = 'utf8mb4_unicode_ci';
            $table->index('service_category_id');
            $table->index('city_id');
            $table->index('status');
            $table->index('is_verified');
            $table->index('rating');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('vendors');
    }
};
