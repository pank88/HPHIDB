<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('conversations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id_1')->constrained('users')->cascadeOnDelete();
            $table->foreignId('user_id_2')->constrained('users')->cascadeOnDelete();
            $table->text('subject')->nullable();
            $table->tinyInteger('status')->default(1)->comment('1=Active, 2=Archived, 3=Blocked');
            $table->timestamp('last_message_at')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->engine = 'InnoDB';
            $table->collation = 'utf8mb4_unicode_ci';
            $table->index('user_id_1');
            $table->index('user_id_2');
            $table->index('status');
            $table->index('last_message_at');
            $table->unique(['user_id_1', 'user_id_2']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('conversations');
    }
};
