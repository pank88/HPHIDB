<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('conversations', function (Blueprint $table) {
            if (! Schema::hasColumn('conversations', 'match_id')) {
                $table->foreignId('match_id')->nullable()->constrained('matches')->cascadeOnDelete();
            }
        });
    }

    public function down(): void
    {
        Schema::table('conversations', function (Blueprint $table) {
            if (Schema::hasColumn('conversations', 'match_id')) {
                $table->dropForeignKeyIfExists(['match_id']);
                $table->dropColumn('match_id');
            }
        });
    }
};
