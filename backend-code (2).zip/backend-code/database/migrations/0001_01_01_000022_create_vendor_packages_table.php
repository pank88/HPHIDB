<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('vendor_packages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vendor_id')->constrained('vendors')->cascadeOnDelete();
            $table->string('name', 255);
            $table->text('description')->nullable();
            $table->decimal('price', 12, 2);
            $table->string('currency', 3)->default('USD');
            $table->integer('duration_days')->nullable()->comment('Package duration in days');
            $table->text('features')->nullable()->comment('JSON array of features');
            $table->tinyInteger('is_popular')->default(0)->comment('0=No, 1=Yes');
            $table->text('inclusions')->nullable();
            $table->text('exclusions')->nullable();
            $table->integer('max_capacity')->nullable();
            $table->integer('current_bookings')->default(0);
            $table->tinyInteger('status')->default(1)->comment('1=Active, 0=Inactive');
            $table->timestamps();
            $table->softDeletes();

            $table->engine = 'InnoDB';
            $table->collation = 'utf8mb4_unicode_ci';
            $table->index('vendor_id');
            $table->index('status');
            $table->index('price');
            $table->index('is_popular');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('vendor_packages');
    }
};
