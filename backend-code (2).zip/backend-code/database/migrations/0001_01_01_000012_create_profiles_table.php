<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('profiles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->unique()->constrained('users')->cascadeOnDelete();
            $table->foreignId('religion_id')->nullable()->constrained('religions')->nullOnDelete();
            $table->foreignId('caste_id')->nullable()->constrained('castes')->nullOnDelete();
            $table->foreignId('gotra_id')->nullable()->constrained('gotras')->nullOnDelete();
            $table->foreignId('education_id')->nullable()->constrained('educations')->nullOnDelete();
            $table->foreignId('occupation_id')->nullable()->constrained('occupations')->nullOnDelete();
            $table->string('full_name', 255);
            $table->enum('gender', ['male', 'female', 'other']);
            $table->date('date_of_birth')->nullable();
            $table->decimal('height', 3, 2)->nullable()->comment('Height in meters');
            $table->string('complexion', 50)->nullable();
            $table->text('bio')->nullable();
            $table->text('about_family')->nullable();
            $table->text('expectations')->nullable();
            $table->tinyInteger('marital_status')->default(1)->comment('1=Single, 2=Divorced, 3=Widowed');
            $table->tinyInteger('has_children')->default(0)->comment('0=No, 1=Yes');
            $table->string('mother_tongue', 100)->nullable();
            $table->decimal('annual_income', 12, 2)->nullable();
            $table->tinyInteger('profile_status')->default(1)->comment('1=Incomplete, 2=Complete, 3=Verified');
            $table->tinyInteger('status')->default(1)->comment('1=Active, 0=Inactive');
            $table->timestamps();
            $table->softDeletes();

            $table->engine = 'InnoDB';
            $table->collation = 'utf8mb4_unicode_ci';
            $table->index('user_id');
            $table->index('religion_id');
            $table->index('gender');
            $table->index('profile_status');
            $table->index('status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('profiles');
    }
};
