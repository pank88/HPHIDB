<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasColumn('audit_logs', 'entity_type')) {
            Schema::table('audit_logs', function (Blueprint $table) {
                $table->string('entity_type', 100)->nullable()->change();
            });
        }

        if (Schema::hasColumn('reviews', 'user_id')) {
            Schema::table('reviews', function (Blueprint $table) {
                $table->unsignedBigInteger('user_id')->nullable()->change();
            });
        }

        if (Schema::hasColumn('reviews', 'review_text')) {
            Schema::table('reviews', function (Blueprint $table) {
                $table->longText('review_text')->nullable()->change();
            });
        }

        if (Schema::hasColumn('reviews', 'title')) {
            Schema::table('reviews', function (Blueprint $table) {
                $table->string('title', 255)->nullable()->change();
            });
        }
    }

    public function down(): void
    {
        // Intentionally left non-reversible: relaxing NOT NULL constraints only.
    }
};
