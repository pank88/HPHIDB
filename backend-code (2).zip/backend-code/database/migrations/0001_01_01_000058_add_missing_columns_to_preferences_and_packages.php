<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('partner_preferences', function (Blueprint $table) {
            if (! Schema::hasColumn('partner_preferences', 'religion_id')) {
                $table->foreignId('religion_id')->nullable()->constrained('religions')->nullOnDelete();
            }
            if (! Schema::hasColumn('partner_preferences', 'caste_id')) {
                $table->foreignId('caste_id')->nullable()->constrained('castes')->nullOnDelete();
            }
            if (! Schema::hasColumn('partner_preferences', 'education_id')) {
                $table->foreignId('education_id')->nullable()->constrained('educations')->nullOnDelete();
            }
            if (! Schema::hasColumn('partner_preferences', 'occupation_id')) {
                $table->foreignId('occupation_id')->nullable()->constrained('occupations')->nullOnDelete();
            }
            if (! Schema::hasColumn('partner_preferences', 'state_id')) {
                $table->foreignId('state_id')->nullable()->constrained('states')->nullOnDelete();
            }
            if (! Schema::hasColumn('partner_preferences', 'city_id')) {
                $table->foreignId('city_id')->nullable()->constrained('cities')->nullOnDelete();
            }
            if (! Schema::hasColumn('partner_preferences', 'annual_income_from')) {
                $table->decimal('annual_income_from', 12, 2)->nullable();
            }
            if (! Schema::hasColumn('partner_preferences', 'annual_income_to')) {
                $table->decimal('annual_income_to', 12, 2)->nullable();
            }
            if (! Schema::hasColumn('partner_preferences', 'body_type')) {
                $table->string('body_type', 50)->nullable();
            }
            if (! Schema::hasColumn('partner_preferences', 'skin_tone')) {
                $table->string('skin_tone', 50)->nullable();
            }
            if (! Schema::hasColumn('partner_preferences', 'mother_tongue')) {
                $table->string('mother_tongue', 100)->nullable();
            }
            if (! Schema::hasColumn('partner_preferences', 'manglik')) {
                $table->boolean('manglik')->default(false);
            }
            if (! Schema::hasColumn('partner_preferences', 'smoke')) {
                $table->boolean('smoke')->default(false);
            }
            if (! Schema::hasColumn('partner_preferences', 'drink')) {
                $table->boolean('drink')->default(false);
            }
            if (! Schema::hasColumn('partner_preferences', 'dietary_preference')) {
                $table->string('dietary_preference', 50)->nullable();
            }
            if (! Schema::hasColumn('partner_preferences', 'personality_type')) {
                $table->string('personality_type', 100)->nullable();
            }
            if (! Schema::hasColumn('partner_preferences', 'interests')) {
                $table->text('interests')->nullable();
            }
        });

        Schema::table('vendor_packages', function (Blueprint $table) {
            if (! Schema::hasColumn('vendor_packages', 'service_category_id')) {
                $table->foreignId('service_category_id')->nullable()->constrained('service_categories')->nullOnDelete();
            }
            if (! Schema::hasColumn('vendor_packages', 'duration')) {
                $table->integer('duration')->nullable();
            }
            if (! Schema::hasColumn('vendor_packages', 'duration_unit')) {
                $table->string('duration_unit', 20)->nullable();
            }
            if (! Schema::hasColumn('vendor_packages', 'max_guests')) {
                $table->integer('max_guests')->nullable();
            }
            if (! Schema::hasColumn('vendor_packages', 'is_available')) {
                $table->boolean('is_available')->default(true);
            }
            if (! Schema::hasColumn('vendor_packages', 'is_featured')) {
                $table->boolean('is_featured')->default(false);
            }
            if (! Schema::hasColumn('vendor_packages', 'booking_count')) {
                $table->integer('booking_count')->default(0);
            }
            if (! Schema::hasColumn('vendor_packages', 'average_rating')) {
                $table->decimal('average_rating', 3, 2)->default(0);
            }
            if (! Schema::hasColumn('vendor_packages', 'total_reviews')) {
                $table->integer('total_reviews')->default(0);
            }
        });
    }

    public function down(): void
    {
        Schema::table('partner_preferences', function (Blueprint $table) {
            foreach (['religion_id', 'caste_id', 'education_id', 'occupation_id', 'state_id', 'city_id'] as $column) {
                if (Schema::hasColumn('partner_preferences', $column)) {
                    $table->dropConstrainedForeignId($column);
                }
            }

            foreach ([
                'annual_income_from', 'annual_income_to', 'body_type', 'skin_tone',
                'mother_tongue', 'manglik', 'smoke', 'drink', 'dietary_preference',
                'personality_type', 'interests',
            ] as $column) {
                if (Schema::hasColumn('partner_preferences', $column)) {
                    $table->dropColumn($column);
                }
            }
        });

        Schema::table('vendor_packages', function (Blueprint $table) {
            if (Schema::hasColumn('vendor_packages', 'service_category_id')) {
                $table->dropConstrainedForeignId('service_category_id');
            }

            foreach ([
                'duration', 'duration_unit', 'max_guests', 'is_available',
                'is_featured', 'booking_count', 'average_rating', 'total_reviews',
            ] as $column) {
                if (Schema::hasColumn('vendor_packages', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
