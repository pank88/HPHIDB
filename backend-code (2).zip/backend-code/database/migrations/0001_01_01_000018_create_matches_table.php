<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('matches', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('matched_user_id')->constrained('users')->cascadeOnDelete();
            $table->decimal('match_score', 5, 2)->nullable()->comment('UserMatch score in percentage');
            $table->tinyInteger('match_type')->default(1)->comment('1=Interest, 2=Premium, 3=System Generated');
            $table->text('match_criteria')->nullable()->comment('JSON object of matched criteria');
            $table->tinyInteger('status')->default(1)->comment('1=Active, 2=Declined, 3=Blocked');
            $table->timestamp('last_viewed_at')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->engine = 'InnoDB';
            $table->collation = 'utf8mb4_unicode_ci';
            $table->index('user_id');
            $table->index('matched_user_id');
            $table->index('status');
            $table->index('match_score');
            $table->index('created_at');
            $table->unique(['user_id', 'matched_user_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('matches');
    }
};
