<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('profile_photos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('profile_id')->constrained('profiles')->cascadeOnDelete();
            $table->string('photo_path', 255);
            $table->string('thumbnail_path', 255)->nullable();
            $table->tinyInteger('is_primary')->default(0)->comment('0=No, 1=Yes');
            $table->tinyInteger('is_verified')->default(0)->comment('0=No, 1=Yes');
            $table->text('description')->nullable();
            $table->tinyInteger('status')->default(1)->comment('1=Active, 0=Inactive');
            $table->timestamps();
            $table->softDeletes();

            $table->engine = 'InnoDB';
            $table->collation = 'utf8mb4_unicode_ci';
            $table->index('profile_id');
            $table->index('is_primary');
            $table->index('is_verified');
            $table->index('status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('profile_photos');
    }
};
