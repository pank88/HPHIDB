<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasColumn('conversations', 'user_id_1') && ! Schema::hasColumn('conversations', 'initiator_id')) {
            Schema::table('conversations', function (Blueprint $table) {
                $table->renameColumn('user_id_1', 'initiator_id');
            });
        }

        if (Schema::hasColumn('conversations', 'user_id_2') && ! Schema::hasColumn('conversations', 'participant_id')) {
            Schema::table('conversations', function (Blueprint $table) {
                $table->renameColumn('user_id_2', 'participant_id');
            });
        }

        if (! Schema::hasColumn('conversations', 'is_active')) {
            Schema::table('conversations', function (Blueprint $table) {
                $table->boolean('is_active')->default(true);
            });
        }

        if (! Schema::hasColumn('messages', 'match_id')) {
            Schema::table('messages', function (Blueprint $table) {
                $table->foreignId('match_id')->nullable()->constrained('matches')->cascadeOnDelete();
            });
        }

        if (Schema::hasColumn('messages', 'receiver_id')) {
            Schema::table('messages', function (Blueprint $table) {
                $table->unsignedBigInteger('receiver_id')->nullable()->change();
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('messages', 'match_id')) {
            Schema::table('messages', function (Blueprint $table) {
                $table->dropConstrainedForeignId('match_id');
            });
        }

        if (Schema::hasColumn('conversations', 'is_active')) {
            Schema::table('conversations', function (Blueprint $table) {
                $table->dropColumn('is_active');
            });
        }

        if (Schema::hasColumn('conversations', 'participant_id') && ! Schema::hasColumn('conversations', 'user_id_2')) {
            Schema::table('conversations', function (Blueprint $table) {
                $table->renameColumn('participant_id', 'user_id_2');
            });
        }

        if (Schema::hasColumn('conversations', 'initiator_id') && ! Schema::hasColumn('conversations', 'user_id_1')) {
            Schema::table('conversations', function (Blueprint $table) {
                $table->renameColumn('initiator_id', 'user_id_1');
            });
        }
    }
};
