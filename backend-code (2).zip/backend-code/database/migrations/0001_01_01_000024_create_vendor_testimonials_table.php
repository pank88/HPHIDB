<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('vendor_testimonials', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vendor_id')->constrained('vendors')->cascadeOnDelete();
            $table->foreignId('user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('client_name', 255);
            $table->string('client_email', 255)->nullable();
            $table->decimal('rating', 3, 2);
            $table->text('testimonial');
            $table->string('photo_path', 255)->nullable();
            $table->tinyInteger('is_featured')->default(0)->comment('0=No, 1=Yes');
            $table->tinyInteger('status')->default(1)->comment('1=Active, 0=Inactive, 2=Pending');
            $table->timestamp('verified_at')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->engine = 'InnoDB';
            $table->collation = 'utf8mb4_unicode_ci';
            $table->index('vendor_id');
            $table->index('user_id');
            $table->index('rating');
            $table->index('is_featured');
            $table->index('status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('vendor_testimonials');
    }
};
