<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('vendor_images', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vendor_id')->constrained('vendors')->cascadeOnDelete();
            $table->string('image_path', 255);
            $table->string('thumbnail_path', 255)->nullable();
            $table->tinyInteger('is_primary')->default(0)->comment('0=No, 1=Yes');
            $table->text('caption')->nullable();
            $table->text('alt_text')->nullable();
            $table->integer('display_order')->default(0);
            $table->tinyInteger('status')->default(1)->comment('1=Active, 0=Inactive');
            $table->timestamps();
            $table->softDeletes();

            $table->engine = 'InnoDB';
            $table->collation = 'utf8mb4_unicode_ci';
            $table->index('vendor_id');
            $table->index('is_primary');
            $table->index('status');
            $table->index('display_order');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('vendor_images');
    }
};
