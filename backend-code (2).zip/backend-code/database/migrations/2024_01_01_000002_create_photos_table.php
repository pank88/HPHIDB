<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('photos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->string('filename');
            $table->string('storage_path');
            $table->string('original_name');
            $table->string('mime_type');
            $table->integer('file_size');
            $table->boolean('is_primary')->default(false);
            $table->boolean('is_verified')->default(false);
            $table->enum('status', ['pending', 'approved', 'rejected', 'private'])->default('pending');
            $table->boolean('encrypted')->default(true);
            $table->timestamp('verified_at')->nullable();
            $table->text('rejected_reason')->nullable();
            $table->timestamps();
            $table->index('user_id');
            $table->index('is_primary');
            $table->index('is_verified');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('photos');
    }
};
