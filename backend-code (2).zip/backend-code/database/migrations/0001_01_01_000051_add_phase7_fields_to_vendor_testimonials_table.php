<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('vendor_testimonials', function (Blueprint $table) {
            // Add reviewer_id if not exists
            if (! Schema::hasColumn('vendor_testimonials', 'reviewer_id')) {
                $table->foreignId('reviewer_id')->nullable()->after('vendor_id')->constrained('users')->cascadeOnDelete();
            }

            // Add Phase 7 columns
            if (! Schema::hasColumn('vendor_testimonials', 'reviewer_name')) {
                $table->string('reviewer_name')->nullable()->after('reviewer_id');
            }
            if (! Schema::hasColumn('vendor_testimonials', 'reviewer_title')) {
                $table->string('reviewer_title')->nullable()->after('reviewer_name');
            }
            if (! Schema::hasColumn('vendor_testimonials', 'body')) {
                $table->longText('body')->nullable()->after('testimonial');
            }
            if (! Schema::hasColumn('vendor_testimonials', 'image_url')) {
                $table->string('image_url')->nullable()->after('photo_path');
            }
            if (! Schema::hasColumn('vendor_testimonials', 'is_approved')) {
                $table->boolean('is_approved')->default(false)->after('is_featured');
            }
            if (! Schema::hasColumn('vendor_testimonials', 'approved_at')) {
                $table->timestamp('approved_at')->nullable()->after('is_approved');
            }
        });
    }

    public function down(): void
    {
        Schema::table('vendor_testimonials', function (Blueprint $table) {
            $columnsToDropIfExists = [
                'reviewer_id',
                'reviewer_name',
                'reviewer_title',
                'body',
                'image_url',
                'is_approved',
                'approved_at',
            ];

            foreach ($columnsToDropIfExists as $column) {
                if (Schema::hasColumn('vendor_testimonials', $column)) {
                    if ($column === 'reviewer_id') {
                        $table->dropForeignIdFor($column);
                    } else {
                        $table->dropColumn($column);
                    }
                }
            }
        });
    }
};
