<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('vendor_services', function (Blueprint $table) {
            $table->id();
            $table->foreignId('vendor_id')->constrained('vendors')->cascadeOnDelete();
            $table->foreignId('service_category_id')->constrained('service_categories')->cascadeOnDelete();
            $table->string('name', 255);
            $table->text('description')->nullable();
            $table->decimal('base_price', 12, 2);
            $table->enum('price_unit', ['per_event', 'per_hour', 'per_package', 'custom'])->default('per_event');
            $table->integer('duration_hours')->nullable();
            $table->integer('max_guests_count')->nullable();
            $table->boolean('includes_travel')->default(false);
            $table->boolean('includes_decoration')->default(false);
            $table->boolean('includes_makeup')->default(false);
            $table->boolean('includes_videography')->default(false);
            $table->boolean('includes_album')->default(false);
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->engine = 'InnoDB';
            $table->collation = 'utf8mb4_unicode_ci';
            $table->index('vendor_id');
            $table->index('service_category_id');
            $table->index('is_active');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('vendor_services');
    }
};
