<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('messages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('conversation_id')->constrained('conversations')->cascadeOnDelete();
            $table->foreignId('sender_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('receiver_id')->constrained('users')->cascadeOnDelete();
            $table->longText('message');
            $table->string('message_type', 50)->default('text')->comment('text, image, video, document');
            $table->string('attachment_path', 255)->nullable();
            $table->tinyInteger('is_read')->default(0)->comment('0=Unread, 1=Read');
            $table->timestamp('read_at')->nullable();
            $table->tinyInteger('status')->default(1)->comment('1=Active, 2=Deleted');
            $table->timestamps();
            $table->softDeletes();

            $table->engine = 'InnoDB';
            $table->collation = 'utf8mb4_unicode_ci';
            $table->index('conversation_id');
            $table->index('sender_id');
            $table->index('receiver_id');
            $table->index('is_read');
            $table->index('created_at');
            $table->index('status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('messages');
    }
};
