<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('vendor_testimonials', function (Blueprint $table) {
            if (! Schema::hasColumn('vendor_testimonials', 'client_location')) {
                $table->string('client_location', 255)->nullable()->after('reviewer_title');
            }
        });
    }

    public function down(): void
    {
        Schema::table('vendor_testimonials', function (Blueprint $table) {
            if (Schema::hasColumn('vendor_testimonials', 'client_location')) {
                $table->dropColumn('client_location');
            }
        });
    }
};
