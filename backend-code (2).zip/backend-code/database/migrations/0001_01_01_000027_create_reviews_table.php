<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('reviews', function (Blueprint $table) {
            $table->id();
            $table->foreignId('booking_id')->constrained('bookings')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('vendor_id')->constrained('vendors')->cascadeOnDelete();
            $table->enum('review_type', ['service', 'vendor', 'both'])->default('service');
            $table->decimal('rating', 3, 2);
            $table->string('title', 255);
            $table->longText('review_text');
            $table->integer('helpful_count')->default(0);
            $table->integer('unhelpful_count')->default(0);
            $table->tinyInteger('status')->default(1)->comment('1=Published, 2=Pending, 3=Rejected');
            $table->tinyInteger('is_featured')->default(0)->comment('0=No, 1=Yes');
            $table->text('tags')->nullable()->comment('JSON array of review tags');
            $table->timestamp('verified_purchase_at')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->engine = 'InnoDB';
            $table->collation = 'utf8mb4_unicode_ci';
            $table->index('vendor_id');
            $table->index('user_id');
            $table->index('booking_id');
            $table->index('rating');
            $table->index('status');
            $table->index('is_featured');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('reviews');
    }
};
