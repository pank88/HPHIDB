<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasColumn('occupations', 'title') && ! Schema::hasColumn('occupations', 'name')) {
            Schema::table('occupations', function (Blueprint $table) {
                $table->renameColumn('title', 'name');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('occupations', 'name') && ! Schema::hasColumn('occupations', 'title')) {
            Schema::table('occupations', function (Blueprint $table) {
                $table->renameColumn('name', 'title');
            });
        }
    }
};
