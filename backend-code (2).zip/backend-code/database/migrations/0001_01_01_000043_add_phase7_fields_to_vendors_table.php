<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('vendors', function (Blueprint $table) {
            if (! Schema::hasColumn('vendors', 'bio')) {
                $table->text('bio')->nullable()->after('description');
            }
            if (! Schema::hasColumn('vendors', 'response_time_hours')) {
                $table->integer('response_time_hours')->default(24)->after('total_reviews');
            }
            if (! Schema::hasColumn('vendors', 'verification_document_url')) {
                $table->string('verification_document_url')->nullable()->after('is_verified');
            }
            if (! Schema::hasColumn('vendors', 'rating_updated_at')) {
                $table->timestamp('rating_updated_at')->nullable()->after('verified_at');
            }
        });
    }

    public function down(): void
    {
        Schema::table('vendors', function (Blueprint $table) {
            if (Schema::hasColumn('vendors', 'bio')) {
                $table->dropColumn('bio');
            }
            if (Schema::hasColumn('vendors', 'response_time_hours')) {
                $table->dropColumn('response_time_hours');
            }
            if (Schema::hasColumn('vendors', 'verification_document_url')) {
                $table->dropColumn('verification_document_url');
            }
            if (Schema::hasColumn('vendors', 'rating_updated_at')) {
                $table->dropColumn('rating_updated_at');
            }
        });
    }
};
