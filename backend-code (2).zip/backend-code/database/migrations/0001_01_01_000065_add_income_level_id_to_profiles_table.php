<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('profiles') || Schema::hasColumn('profiles', 'income_level_id')) {
            return;
        }

        Schema::table('profiles', function (Blueprint $table) {
            $table->foreignId('income_level_id')->nullable()->constrained('income_levels')->nullOnDelete();
        });
    }

    public function down(): void
    {
        if (! Schema::hasColumn('profiles', 'income_level_id')) {
            return;
        }

        Schema::table('profiles', function (Blueprint $table) {
            $table->dropConstrainedForeignId('income_level_id');
        });
    }
};
