<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            // Add vendor_service_id if not exists
            if (! Schema::hasColumn('bookings', 'vendor_service_id')) {
                $table->foreignId('vendor_service_id')->nullable()->after('vendor_package_id')->constrained('vendor_services')->nullOnDelete();
            }

            // Add Phase 7 columns
            if (! Schema::hasColumn('bookings', 'service_date')) {
                $table->date('service_date')->nullable()->after('booking_date');
            }
            if (! Schema::hasColumn('bookings', 'service_time_from')) {
                $table->time('service_time_from')->nullable()->after('service_date');
            }
            if (! Schema::hasColumn('bookings', 'service_time_to')) {
                $table->time('service_time_to')->nullable()->after('service_time_from');
            }
            if (! Schema::hasColumn('bookings', 'location_address')) {
                $table->text('location_address')->nullable()->after('service_time_to');
            }
            if (! Schema::hasColumn('bookings', 'location_city_id')) {
                $table->foreignId('location_city_id')->nullable()->after('location_address')->constrained('cities')->nullOnDelete();
            }
            if (! Schema::hasColumn('bookings', 'guests_count')) {
                $table->integer('guests_count')->nullable()->after('location_city_id');
            }
            if (! Schema::hasColumn('bookings', 'special_requirements')) {
                $table->text('special_requirements')->nullable()->after('guests_count');
            }
            if (! Schema::hasColumn('bookings', 'estimated_amount')) {
                $table->decimal('estimated_amount', 12, 2)->nullable()->after('package_price');
            }
            if (! Schema::hasColumn('bookings', 'final_amount')) {
                $table->decimal('final_amount', 12, 2)->nullable()->after('estimated_amount');
            }
            if (! Schema::hasColumn('bookings', 'status')) {
                $table->enum('status', ['INQUIRY', 'QUOTED', 'CONFIRMED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'])->default('INQUIRY')->after('booking_status');
            }
            if (! Schema::hasColumn('bookings', 'payment_status')) {
                $table->enum('payment_status', ['PENDING', 'PARTIAL', 'PAID', 'REFUNDED'])->default('PENDING')->after('status');
            }
            if (! Schema::hasColumn('bookings', 'inquiry_responded_at')) {
                $table->timestamp('inquiry_responded_at')->nullable()->after('payment_status');
            }
            if (! Schema::hasColumn('bookings', 'inquiry_response_time_minutes')) {
                $table->integer('inquiry_response_time_minutes')->nullable()->after('inquiry_responded_at');
            }
            if (! Schema::hasColumn('bookings', 'completed_at')) {
                $table->timestamp('completed_at')->nullable()->after('cancelled_at');
            }
            if (! Schema::hasColumn('bookings', 'cancellation_reason')) {
                $table->text('cancellation_reason')->nullable()->after('completed_at');
            }
            if (! Schema::hasColumn('bookings', 'review_id')) {
                $table->foreignId('review_id')->nullable()->after('cancellation_reason')->constrained('reviews')->nullOnDelete();
            }
        });
    }

    public function down(): void
    {
        Schema::table('bookings', function (Blueprint $table) {
            $columnsToDropIfExists = [
                'vendor_service_id',
                'service_date',
                'service_time_from',
                'service_time_to',
                'location_address',
                'location_city_id',
                'guests_count',
                'special_requirements',
                'estimated_amount',
                'final_amount',
                'status',
                'inquiry_responded_at',
                'inquiry_response_time_minutes',
                'completed_at',
                'cancellation_reason',
                'review_id',
            ];

            foreach ($columnsToDropIfExists as $column) {
                if (Schema::hasColumn('bookings', $column)) {
                    if ($column === 'vendor_service_id' || $column === 'location_city_id' || $column === 'review_id') {
                        $table->dropForeignIdFor($column);
                    } else {
                        $table->dropColumn($column);
                    }
                }
            }
        });
    }
};
