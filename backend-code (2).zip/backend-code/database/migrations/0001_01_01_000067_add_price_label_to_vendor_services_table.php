<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('vendor_services', function (Blueprint $table) {
            if (! Schema::hasColumn('vendor_services', 'price_label')) {
                // Free-text pricing unit the vendor types themselves, e.g.
                // "100 plates", "per couple", "half day" — base_price stays
                // the numeric amount (e.g. 10000) this label describes.
                $table->string('price_label', 100)->nullable()->after('base_price');
            }
        });
    }

    public function down(): void
    {
        Schema::table('vendor_services', function (Blueprint $table) {
            if (Schema::hasColumn('vendor_services', 'price_label')) {
                $table->dropColumn('price_label');
            }
        });
    }
};
