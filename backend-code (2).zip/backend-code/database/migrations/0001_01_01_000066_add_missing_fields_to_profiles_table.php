<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('profiles', function (Blueprint $table) {
            if (! Schema::hasColumn('profiles', 'created_for')) {
                $table->string('created_for', 20)->nullable()->after('gender');
            }
            if (! Schema::hasColumn('profiles', 'height_cm')) {
                $table->unsignedSmallInteger('height_cm')->nullable()->after('height');
            }
            if (! Schema::hasColumn('profiles', 'food_type')) {
                $table->string('food_type', 20)->nullable()->after('complexion');
            }
            if (! Schema::hasColumn('profiles', 'about')) {
                $table->text('about')->nullable()->after('bio');
            }
        });
    }

    public function down(): void
    {
        Schema::table('profiles', function (Blueprint $table) {
            foreach (['created_for', 'height_cm', 'food_type', 'about'] as $column) {
                if (Schema::hasColumn('profiles', $column)) {
                    $table->dropColumn($column);
                }
            }
        });
    }
};
