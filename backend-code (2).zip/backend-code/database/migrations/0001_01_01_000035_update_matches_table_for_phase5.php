<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Rename columns in separate calls (SQLite rebuilds the table per rename;
        // batching both renames corrupts foreign key definitions)
        if (Schema::hasColumn('matches', 'matched_user_id')) {
            Schema::table('matches', function (Blueprint $table) {
                $table->renameColumn('matched_user_id', 'matcher_id');
            });
        }

        if (Schema::hasColumn('matches', 'user_id')) {
            Schema::table('matches', function (Blueprint $table) {
                $table->renameColumn('user_id', 'initiator_id');
            });
        }

        Schema::table('matches', function (Blueprint $table) {
            // Add Phase 5 columns
            if (! Schema::hasColumn('matches', 'interest_id')) {
                $table->foreignId('interest_id')->nullable()->constrained('interest_requests')->cascadeOnDelete();
            }

            if (! Schema::hasColumn('matches', 'initiator_profile_id')) {
                $table->foreignId('initiator_profile_id')->nullable()->constrained('profiles')->cascadeOnDelete();
            }

            if (! Schema::hasColumn('matches', 'matcher_profile_id')) {
                $table->foreignId('matcher_profile_id')->nullable()->constrained('profiles')->cascadeOnDelete();
            }

            if (! Schema::hasColumn('matches', 'connected_at')) {
                $table->timestamp('connected_at')->nullable();
            }

            if (! Schema::hasColumn('matches', 'last_interaction_at')) {
                $table->timestamp('last_interaction_at')->nullable();
            }

            if (! Schema::hasColumn('matches', 'is_active')) {
                $table->boolean('is_active')->default(true);
            }

            if (! Schema::hasColumn('matches', 'blocked_by_id')) {
                $table->foreignId('blocked_by_id')->nullable()->constrained('users')->cascadeOnDelete();
            }

            // Add indexes
            if (! Schema::hasColumn('matches', 'initiator_id')) {
                // Will be renamed from user_id
            } else {
                // Ensure indexes exist
                $table->index('initiator_id');
                $table->index('matcher_id');
            }

            $table->index('is_active');
            $table->index('connected_at');
        });
    }

    public function down(): void
    {
        Schema::table('matches', function (Blueprint $table) {
            // Reverse the changes
        });
    }
};
