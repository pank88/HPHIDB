<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('castes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('religion_id')->constrained('religions')->cascadeOnDelete();
            $table->string('name', 100);
            $table->text('description')->nullable();
            $table->tinyInteger('status')->default(1)->comment('1=Active, 0=Inactive');
            $table->timestamps();

            $table->engine = 'InnoDB';
            $table->collation = 'utf8mb4_unicode_ci';
            $table->index('religion_id');
            $table->index('status');
            $table->unique(['religion_id', 'name']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('castes');
    }
};
