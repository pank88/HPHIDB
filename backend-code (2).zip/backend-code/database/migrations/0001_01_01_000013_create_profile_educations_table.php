<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('profile_educations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('profile_id')->constrained('profiles')->cascadeOnDelete();
            $table->foreignId('education_id')->constrained('educations')->cascadeOnDelete();
            $table->string('institution_name', 255);
            $table->string('board_or_university', 255)->nullable();
            $table->year('graduation_year')->nullable();
            $table->string('specialization', 255)->nullable();
            $table->text('description')->nullable();
            $table->tinyInteger('status')->default(1)->comment('1=Active, 0=Inactive');
            $table->timestamps();

            $table->engine = 'InnoDB';
            $table->collation = 'utf8mb4_unicode_ci';
            $table->index('profile_id');
            $table->index('education_id');
            $table->index('status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('profile_educations');
    }
};
