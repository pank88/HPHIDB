<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('states') || Schema::hasColumn('states', 'country_id')) {
            return;
        }

        Schema::table('states', function (Blueprint $table) {
            $table->foreignId('country_id')->nullable()->after('id')->constrained('countries')->nullOnDelete();
        });
    }

    public function down(): void
    {
        if (! Schema::hasColumn('states', 'country_id')) {
            return;
        }

        Schema::table('states', function (Blueprint $table) {
            $table->dropConstrainedForeignId('country_id');
        });
    }
};
