<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('suggested_matches', function (Blueprint $table) {
            // Rename suggested_user_id to suggested_profile_id if it exists
            if (Schema::hasColumn('suggested_matches', 'suggested_user_id')) {
                $table->renameColumn('suggested_user_id', 'suggested_profile_id');
            }

            // Rename match_score to compatibility_score if it exists
            if (Schema::hasColumn('suggested_matches', 'match_score')) {
                $table->renameColumn('match_score', 'compatibility_score');
            }

            // Add new columns if they don't exist
            if (! Schema::hasColumn('suggested_matches', 'breakdown')) {
                $table->json('breakdown')->nullable()->after('compatibility_score');
            }

            if (! Schema::hasColumn('suggested_matches', 'is_interested')) {
                $table->boolean('is_interested')->default(false)->after('breakdown');
            }

            if (! Schema::hasColumn('suggested_matches', 'interest_expressed_at')) {
                $table->timestamp('interest_expressed_at')->nullable()->after('is_interested');
            }

            if (! Schema::hasColumn('suggested_matches', 'is_rejected')) {
                $table->boolean('is_rejected')->default(false)->after('interest_expressed_at');
            }

            if (! Schema::hasColumn('suggested_matches', 'rejection_reason')) {
                $table->string('rejection_reason')->nullable()->after('is_rejected');
            }

            if (! Schema::hasColumn('suggested_matches', 'rejected_at')) {
                $table->timestamp('rejected_at')->nullable()->after('rejection_reason');
            }

            if (! Schema::hasColumn('suggested_matches', 'interacted_at')) {
                $table->timestamp('interacted_at')->nullable()->after('viewed_at');
            }

            // Add composite index for user and created_at for daily queries
            $table->index(['user_id', 'created_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('suggested_matches', function (Blueprint $table) {
            // Remove the new columns
            $columns = [
                'breakdown',
                'is_interested',
                'interest_expressed_at',
                'is_rejected',
                'rejection_reason',
                'rejected_at',
                'interacted_at',
            ];

            foreach ($columns as $column) {
                if (Schema::hasColumn('suggested_matches', $column)) {
                    $table->dropColumn($column);
                }
            }

            // Drop composite index
            $table->dropIndex(['user_id', 'created_at']);

            // Reverse renames
            if (Schema::hasColumn('suggested_matches', 'suggested_profile_id')) {
                $table->renameColumn('suggested_profile_id', 'suggested_user_id');
            }

            if (Schema::hasColumn('suggested_matches', 'compatibility_score')) {
                $table->renameColumn('compatibility_score', 'match_score');
            }
        });
    }
};
